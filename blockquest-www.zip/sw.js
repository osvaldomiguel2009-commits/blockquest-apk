/* BlockQuest — Service Worker: cache offline */
const CACHE = 'blockquest-v4';
const FILES = [
  './', './index.html', './style.css', './manifest.webmanifest',
  './assets/ui/icon-192.png', './assets/ui/icon-512.png', './assets/ui/icon-maskable-192.png', './assets/ui/icon-maskable-512.png', './assets/ui/gogames-logo.jpg',
  './js/bundle.js'
];
self.addEventListener('install', e => {
  // Ficheiro a ficheiro (não addAll): numa ligação instável, uma falha isolada
  // já não impede o Service Worker inteiro de instalar e assumir controlo.
  e.waitUntil(
    caches.open(CACHE).then(c => Promise.all(FILES.map(f => fetch(f).then(r => r.ok && c.put(f, r)).catch(() => {})))).then(() => self.skipWaiting())
  );
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  e.respondWith(
    caches.match(e.request).then(cached => {
      const fetchPromise = fetch(e.request).then(net => {
        if (net && net.ok) { const clone = net.clone(); caches.open(CACHE).then(c => c.put(e.request, clone)); }
        return net;
      }).catch(() => cached || caches.match('./index.html'));
      return cached || fetchPromise;
    })
  );
});
