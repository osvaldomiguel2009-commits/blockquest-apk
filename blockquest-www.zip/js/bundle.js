/* BlockQuest — poderes, elementos e fusões */
var BQD = window.BQD = window.BQD || {};

/* Seis elementos base. Cada um é também um poder utilizável com X. */
BQD.POWERS = {
  fire:   { id:'fire',   name:'Fogo',    icon:'🔥', color:'#ff7a2b', color2:'#ffd23f', ammo:7, cd:16,
            desc:'Bola de fogo que salta e queima.',
            kind:'bolt', speed:3.4, gravity:0.05, dmg:2, life:100, r:4, bounce:true, status:{burn:180}, trail:'fire' },
  ice:    { id:'ice',    name:'Gelo',    icon:'❄️', color:'#7fd6ff', color2:'#ffffff', ammo:7, cd:14,
            desc:'Projétil que congela inimigos.',
            kind:'bolt', speed:3.9, gravity:0, dmg:1, life:90, r:4, status:{freeze:150}, trail:'ice' },
  glass:  { id:'glass',  name:'Vidro',   icon:'🪟', color:'#bfe9ff', color2:'#5aa8d8', ammo:7, cd:18,
            desc:'Leque de três estilhaços.',
            kind:'fan', count:3, spread:0.2, speed:3.9, dmg:1, life:60, r:3, trail:'glass' },
  potion: { id:'potion', name:'Poção',   icon:'🧪', color:'#9be24a', color2:'#4c8a1a', ammo:6, cd:24,
            desc:'Frasco que cria uma nuvem tóxica.',
            kind:'lob', vx:2.3, vy:-3.7, gravity:0.16, dmg:0, r:4,
            land:{ zone:'poison', w:60, h:22, life:210, tick:24, dmg:1, status:{poison:150} } },
  sound:  { id:'sound',  name:'Som',     icon:'🔊', color:'#ffd84a', color2:'#ff9b1f', ammo:7, cd:20,
            desc:'Onda sonora que empurra e atordoa.',
            kind:'wave', speed:2.6, dmg:1, w:10, h:30, life:55, pierce:true, knock:2.6, status:{stun:40}, trail:'sound' },
  energy: { id:'energy', name:'Energia', icon:'⚡', color:'#b58cff', color2:'#f2e6ff', ammo:6, cd:22,
            desc:'Raio instantâneo que atravessa tudo.',
            kind:'beam', len:140, h:8, dur:10, dmg:2, angles:[0], trail:'energy' }
};

/* Fusões: chave = ids ordenados alfabeticamente, unidos por "+". known=true aparece logo no menu. */
BQD.FUSIONS = {
  'fire+ice':      { id:'steam',    name:'Chuva de Vapor Cego', icon:'🌫️', known:true, color:'#dfe8ee', color2:'#9fb7c6', ammo:5, cd:26,
                     desc:'Nuvem de vapor que cega e queima levemente.',
                     kind:'cloud', ahead:56, w:88, h:42, life:260, tick:40, dmg:1, status:{blind:200}, style:'steam' },
  'fire+glass':    { id:'magma',    name:'Vidro Fundido',       icon:'🌋', known:true, color:'#ff5a1f', color2:'#ffb347', ammo:5, cd:26,
                     desc:'Bolha de magma que deixa uma poça a arder.',
                     kind:'lob', vx:2.4, vy:-3.2, gravity:0.16, dmg:2, r:5, trail:'fire',
                     land:{ zone:'fire', w:52, h:12, life:230, tick:20, dmg:1, status:{burn:120} } },
  'potion+sound':  { id:'toxsonic', name:'Onda Tóxica Sónica',  icon:'☣️', known:true, color:'#b6ff4a', color2:'#ffd84a', ammo:5, cd:26,
                     desc:'Onda que atravessa inimigos e envenena.',
                     kind:'wave', speed:2.8, dmg:1, w:12, h:32, life:70, pierce:true, knock:1.5, status:{poison:220}, trail:'sound' },
  'energy+fire':   { id:'plasma',   name:'Plasma',              icon:'☄️', known:true, color:'#ff6bd6', color2:'#fff2a8', ammo:5, cd:30,
                     desc:'Esfera enorme que atravessa tudo.',
                     kind:'bolt', speed:3.0, gravity:0, dmg:4, life:110, r:8, pierce:true, status:{burn:120}, trail:'plasma' },
  'glass+ice':     { id:'crystal',  name:'Cristal',             icon:'💎', known:true, color:'#9ff3ff', color2:'#ffffff', ammo:5, cd:30,
                     desc:'Espigões de cristal que rebentam do chão.',
                     kind:'spikes', count:5, gap:16, dmg:2, delay:6, h:32, status:{freeze:90} },
  'energy+ice':    { id:'frayray',  name:'Raio Gélido',         icon:'🧊', color:'#8fe8ff', color2:'#ffffff', ammo:5, cd:26,
                     desc:'Feixe que congela tudo no caminho.',
                     kind:'beam', len:150, h:8, dur:14, dmg:1, angles:[0], status:{freeze:180}, trail:'ice' },
  'fire+sound':    { id:'sonicblast', name:'Explosão Sónica',   icon:'💥', color:'#ffb347', color2:'#fff2a8', ammo:5, cd:30,
                     desc:'Explosão à volta que empurra e atordoa.',
                     kind:'nova', r:54, dmg:2, knock:3.6, status:{stun:60} },
  'fire+potion':   { id:'acidbomb', name:'Bomba Ácida',         icon:'🧨', color:'#c8ff3a', color2:'#ff7a2b', ammo:4, cd:30,
                     desc:'Rebenta ao cair e deixa ácido.',
                     kind:'lob', vx:2.2, vy:-3.7, gravity:0.16, dmg:0, r:5,
                     land:{ burst:36, burstDmg:3, zone:'poison', w:56, h:20, life:180, tick:24, dmg:1, status:{poison:150} } },
  'energy+sound':  { id:'thunder',  name:'Trovão',              icon:'🌩️', color:'#ffe14a', color2:'#ffffff', ammo:5, cd:34,
                     desc:'Raio longo que atordoa quem apanha.',
                     kind:'beam', len:210, h:14, dur:12, dmg:3, angles:[0], status:{stun:90}, trail:'energy' },
  'glass+sound':   { id:'shardsonic', name:'Estilhaço Sónico',  icon:'🎇', color:'#c9f1ff', color2:'#ffd84a', ammo:5, cd:26,
                     desc:'Cinco estilhaços que atravessam inimigos.',
                     kind:'fan', count:5, spread:0.16, speed:4.0, dmg:1, life:65, r:3, pierce:true, trail:'glass' },
  'ice+potion':    { id:'toxsnow',  name:'Neve Tóxica',         icon:'☠️', color:'#b9f7d6', color2:'#7fd6ff', ammo:5, cd:28,
                     desc:'Nuvem gelada e venenosa.',
                     kind:'cloud', ahead:52, w:84, h:44, life:280, tick:34, dmg:1, status:{poison:160, freeze:70}, style:'snow' },
  'energy+glass':  { id:'prism',    name:'Prisma Laser',        icon:'🔱', color:'#ffb3f0', color2:'#9ff3ff', ammo:5, cd:30,
                     desc:'Três raios em leque.',
                     kind:'beam', len:130, h:8, dur:12, dmg:2, angles:[-0.38,0,0.38], trail:'energy' },
  'glass+potion':  { id:'shardpot', name:'Poção Estilhaçada',   icon:'🍶', color:'#a8f0ff', color2:'#9be24a', ammo:5, cd:28,
                     desc:'Frasco que rebenta em estilhaços.',
                     kind:'lob', vx:2.3, vy:-3.7, gravity:0.16, dmg:0, r:4,
                     land:{ shards:8, shardDmg:1, zone:'poison', w:40, h:16, life:120, tick:24, dmg:1, status:{poison:100} } },
  'energy+potion': { id:'radio',    name:'Rajada Radioativa',   icon:'☢️', color:'#7dff5a', color2:'#b58cff', ammo:5, cd:28,
                     desc:'Bola que atravessa tudo e envenena.',
                     kind:'bolt', speed:3.4, gravity:0, dmg:3, life:100, r:6, pierce:true, status:{poison:240}, trail:'energy' },
  'ice+sound':     { id:'glacialscream', name:'Grito Glacial', icon:'🥶', color:'#bfe9ff', color2:'#ffd84a', ammo:5, cd:30,
                     desc:'Onda de choque gelada à volta.',
                     kind:'nova', r:48, dmg:1, knock:2.6, status:{freeze:120} }
};

BQD.fusionKey = function (a, b) { return [a, b].sort().join('+'); };
/* BlockQuest — personagens */
var BQD = window.BQD = window.BQD || {};
BQD.CHARACTERS = [
  { id:'bob', name:'Bob, o Estagiário', price:0, ability:'Sem habilidade especial',
    desc:'Um soldado recém-chegado que ainda não sabe bem o que anda a fazer. Equilibrado em tudo.',
    stats:{ vel:3, salto:3, poder:3 }, flags:{},
    look:{ skin:'#e8b48a', hair:'#5a3a1e', top:'#5f7a3a', top2:'#3f5626', bottom:'#3b3f2a', shoe:'#2a2118', style:'bob' } },
  { id:'karen', name:'Princesa Karen', price:500, ability:'Salto duplo · Moedas x2',
    desc:'Não pede licença. Salta duas vezes e cobra o dobro por cada moeda.',
    stats:{ vel:3, salto:5, poder:3 }, flags:{ doubleJump:true, coinMult:2 },
    look:{ skin:'#f5cfa0', hair:'#f2c94c', top:'#ff6fb1', top2:'#c2417f', bottom:'#ff6fb1', shoe:'#8a2b5c', style:'karen' } },
  { id:'ze', name:'Mestre Zé', price:1000, ability:'Começa cada fase com escudo',
    desc:'Velho mestre de obras e de magia. O escudo absorve o primeiro dano de cada fase.',
    stats:{ vel:2, salto:3, poder:4 }, flags:{ startShield:true },
    look:{ skin:'#d9a273', hair:'#f1f1f1', top:'#7d4fd0', top2:'#4d2a94', bottom:'#4d2a94', shoe:'#2b1a4f', style:'ze' } },
  { id:'r26', name:'Robô R-26', price:2000, ability:'Íman automático de moedas',
    desc:'Modelo de 2026 com um íman de série. As moedas próximas voam para ele.',
    stats:{ vel:3, salto:3, poder:3 }, flags:{ magnet:70 },
    look:{ skin:'#b8c2cc', hair:'#8a97a3', top:'#8a97a3', top2:'#56626e', bottom:'#56626e', shoe:'#2c343b', style:'r26' } },
  { id:'funny', name:'Funny Boy', price:3000, ability:'Invisibilidade recarregável (tecla V / botão ★)',
    desc:'Ninguém o leva a sério, nem os inimigos, que deixam de o ver durante uns segundos.',
    stats:{ vel:4, salto:4, poder:2 }, flags:{ invis:{ dur:240, cd:720 } },
    look:{ skin:'#f5d0b0', hair:'#42d17a', top:'#ff4a4a', top2:'#ffd23f', bottom:'#ffd23f', shoe:'#ff4a4a', style:'funny' } },
  { id:'dj', name:'DJ Vibes', price:4000, ability:'Rádio: feixe sonoro automático a cada 10 s',
    desc:'Traz a sua aparelhagem para todo o lado. De 10 em 10 segundos o rádio dispara sozinho.',
    stats:{ vel:3, salto:3, poder:5 }, flags:{ radio:{ every:600 } },
    look:{ skin:'#a8703f', hair:'#1a1a1a', top:'#2fd0e0', top2:'#1b8a96', bottom:'#2b2b45', shoe:'#f2f2f2', style:'dj' } }
];
/* BlockQuest — inimigos (Mundo 1 nesta versão) */
var BQD = window.BQD = window.BQD || {};
BQD.ENEMIES = {
  zombie: { name:'Morto-vivo', w:12, h:15, hp:2, speed:0.45, chase:0.9, sight:115, stomp:true, score:100, drop:0.14, ai:'walker' },
  zombie_glass: { name:'Zumbi Vidraceiro', w:12, h:15, hp:2, speed:0.4, chase:0.7, sight:130, stomp:true, score:150, drop:0.22, ai:'walker',
                  shoot:{ range:125, cd:120, windup:22, type:'shard' } },
  crow: { name:'Corvo Morto-vivo', w:12, h:10, hp:2, speed:0.7, chase:1.5, sight:130, stomp:false, score:200, drop:0.2, ai:'flyer' },
  fire_demon: { name:'Demónio de Fogo', w:13, h:15, hp:3, speed:0.4, chase:0.8, sight:110, stomp:false, score:180, drop:0.24, ai:'walker' },
  witch: { name:'Bruxa', w:12, h:16, hp:2, speed:0.32, chase:0.5, sight:160, stomp:true, score:220, drop:0.3, ai:'walker',
           shoot:{ range:175, cd:150, windup:28, type:'potion' } },
  ice_beast: { name:'Animal Morto-vivo', w:13, h:12, hp:2, speed:0.9, chase:1.8, sight:140, stomp:true, score:200, drop:0.24, ai:'erratic' },
  guard: { name:'Guarda do Castelo', w:12, h:16, hp:3, speed:0.4, chase:0.75, sight:120, stomp:true, score:200, drop:0.26, ai:'walker',
           shoot:{ range:120, cd:130, windup:24, type:'shard' } }
};
/* BlockQuest — bosses */
var BQD = window.BQD = window.BQD || {};
BQD.BOSSES = {
  demolidor: { id:'demolidor', name:'DEMOLIDOR', hp:26, w:34, h:46, world:1, fragment:'urbano', fragmentName:'Fragmento Urbano',
               music:'boss', score:2000 },
  perfurador: { id:'perfurador', name:'PERFURADOR', hp:34, w:26, h:30, world:2, fragment:'mineral', fragmentName:'Fragmento Mineral',
               music:'boss', score:2600 },
  burner: { id:'burner', name:'BURNER', hp:44, w:34, h:42, world:3, fragment:'infernal', fragmentName:'Fragmento Infernal',
               music:'boss', score:3200 },
  grausnegativos: { id:'grausnegativos', name:'GRAUS NEGATIVOS', hp:50, w:32, h:44, world:4, fragment:'glacial', fragmentName:'Fragmento Glacial',
               music:'boss', score:3800 },
  krumpie: { id:'krumpie', name:'KRUMPIE', hp:90, w:24, h:40, world:5, fragment:null, fragmentName:null,
               music:'boss', score:6000 }
};
BQD.FRAGMENTS = {
  urbano:  { name:'Fragmento Urbano',  color:'#5fe0a0' },
  mineral: { name:'Fragmento Mineral', color:'#e0a05f' },
  infernal:{ name:'Fragmento Infernal',color:'#ff5a3a' },
  glacial: { name:'Fragmento Glacial', color:'#8fe8ff' }
};
/* BlockQuest — conquistas */
var BQD = window.BQD = window.BQD || {};
BQD.ACHIEVEMENTS = [
  { id:'first',   icon:'🏆', name:'Primeiro Passo',       desc:'Complete a primeira fase.' },
  { id:'frag',    icon:'💠', name:'Caçador de Fragmentos', desc:'Obtenha o primeiro fragmento.' },
  { id:'combo10', icon:'🔥', name:'Mestre dos Combos',    desc:'Consiga combo x10.' },
  { id:'clean',   icon:'✨', name:'Sem Arranhões',        desc:'Complete uma fase sem receber dano.' },
  { id:'boss1',   icon:'💀', name:'Destruidor de Bosses', desc:'Derrote o primeiro Boss.' },
  { id:'fusion5', icon:'⚗️', name:'Mestre da Fusão',      desc:'Descubra 5 combinações.' },
  { id:'saved',   icon:'👑', name:'Reino Salvo',          desc:'Derrote Krumpie.' },
  { id:'rich',    icon:'🪙', name:'Bolsos Cheios',        desc:'Junte 1000 moedas.' },
  { id:'ally',    icon:'🤝', name:'Ajuda Inesperada',     desc:'Invoque um aliado.' },
  { id:'secret',  icon:'🗝️', name:'Olho de Lince',        desc:'Encontre uma sala secreta.' }
];
/* BlockQuest — níveis. Construídos com um pequeno DSL em unidades de tile (16px). */
var BQD = window.BQD = window.BQD || {};

/* ids de tile */
BQD.TILE = { AIR:0, GROUND:1, DIRT:2, BRICK:3, QBLOCK:4, USED:5, GIRDER:6, SPIKES:7, HIDDEN:8, FAKE:9, CRACKED:10, STEEL:11 };

BQD.buildLevel = function (o, script) {
  var T = BQD.TILE, W = o.w, H = 17;
  var tiles = new Uint8Array(W * H), top = [], ents = [], blocks = {}, i;
  for (i = 0; i < W; i++) top[i] = 17;
  function set(x, y, v) { if (x >= 0 && x < W && y >= 0 && y < H) tiles[y * W + x] = v; }
  var b = {
    W: W,
    seg: function (x0, x1, t) {           // terreno com topo na linha t
      for (var x = x0; x <= x1; x++) {
        set(x, t, T.GROUND);
        for (var y = t + 1; y < H; y++) set(x, y, T.DIRT);
        top[x] = t;
      }
    },
    ground: function (x0, x1) { b.seg(x0, x1, 14); },
    plat: function (x, y, w) { for (var i = 0; i < w; i++) set(x + i, y, T.GIRDER); },
    solid: function (x, y, w, h, v) { for (var j = 0; j < h; j++) for (var i = 0; i < w; i++) set(x + i, y + j, v || T.STEEL); },
    brick: function (x, y, w) { for (var i = 0; i < (w || 1); i++) set(x + i, y, T.BRICK); },
    q: function (x, y, content) { set(x, y, T.QBLOCK); blocks[x + ',' + y] = content; },
    brickc: function (x, y, content) { set(x, y, T.BRICK); blocks[x + ',' + y] = content; },
    hid: function (x, y, content) { set(x, y, T.HIDDEN); blocks[x + ',' + y] = content; },
    fake: function (x, y, w, h) { b.solid(x, y, w, h, T.FAKE); },
    crack: function (x, y, w, h) { b.solid(x, y, w, h, T.CRACKED); },
    spikes: function (x0, x1) { for (var x = x0; x <= x1; x++) set(x, top[x] - 1, T.SPIKES); },
    stairs: function (x, n, dir) {          // degraus de aço que sobem (dir 1) ou descem (dir -1)
      for (var k = 0; k < n; k++) {
        var cx = dir > 0 ? x + k : x + (n - 1 - k);
        for (var h = 1; h <= k + 1; h++) set(cx, top[cx] - h, T.STEEL);
      }
    },
    surf: function (x) { return top[Math.floor(x)]; },
    coins: function (x, y, n, step, v) { for (var k = 0; k < n; k++) ents.push({ t: 'coin', x: x + k * (step || 1), y: y, v: v || 1 }); },
    cs: function (x, n, dy, v) { for (var k = 0; k < n; k++) ents.push({ t: 'coin', x: x + k, y: top[x + k] - (dy || 2), v: v || 1 }); },
    arc: function (x, y, n, h) {
      h = h || 2;
      for (var k = 0; k < n; k++) { var p = n > 1 ? k / (n - 1) : 0.5; ents.push({ t: 'coin', x: x + k, y: y - Math.round(Math.sin(p * Math.PI) * h), v: 1 }); }
    },
    en: function (kind, x, y) { ents.push({ t: 'en', k: kind, x: x, y: y, auto: y === undefined }); },
    tramp: function (x, kind) { ents.push({ t: 'tramp', k: kind || 'tire', x: x, auto: true }); },
    cone: function (x) { ents.push({ t: 'cone', x: x, auto: true }); },
    lamp: function (x) { ents.push({ t: 'lamp', x: x, auto: true }); },
    check: function (x) { ents.push({ t: 'check', x: x, auto: true }); },
    orb: function (p, x, y) { ents.push({ t: 'orb', p: p, x: x, y: y }); },
    goal: function (x) { ents.push({ t: 'goal', x: x, auto: true }); },
    spawn: function (x) { ents.push({ t: 'spawn', x: x, auto: true }); },
    boss: function (k, x) { ents.push({ t: 'boss', k: k, x: x, auto: true }); },
    secret: function (x, y, w, h) { ents.push({ t: 'secret', x: x, y: y, w: w, h: h }); },
    lava: function (x0, x1, y) { ents.push({ t: 'lava', x0: x0, x1: x1, y: y }); },
    lift: function (x, a0, a1, w, speed, axis) { ents.push({ t: 'lift', x: x, a0: a0, a1: a1, w: w || 3, speed: speed || 0.5, axis: axis || 'v' }); },
    crystal: function (x, y) { ents.push({ t: 'crystal', x: x, y: y }); }
  };
  script(b);
  ents.forEach(function (e) {
    if (e.auto) { e.y = (top[Math.floor(e.x)] || 14) - 1; }
  });
  var lvl = { id: o.id, name: o.name, w: W, tiles: tiles, blocks: blocks, ents: ents, top: top,
              theme: o.theme || 'urban', tone: o.tone || 'dusk', music: o.music || 'urban',
              boss: !!o.boss, world: o.world || 1, par: o.par || 120, coinsTotal: 0 };
  ents.forEach(function (e) { if (e.t === 'coin') lvl.coinsTotal += e.v; });
  for (var k in blocks) { if (blocks[k] === 'coin') lvl.coinsTotal += 1; }
  return lvl;
};

BQD.LEVELS = {};

/* ───────────── 1-1  Rua Partida ───────────── */
BQD.LEVELS['1-1'] = BQD.buildLevel({ id: '1-1', name: 'Rua Partida', w: 172, tone: 'dusk', par: 110 }, function (b) {
  b.ground(0, 37); b.ground(41, 75); b.ground(80, 103); b.ground(107, 109); b.ground(113, 171);
  b.spawn(3);
  b.cone(6); b.cone(7); b.lamp(9);
  b.cs(9, 5);
  b.brick(10, 10); b.q(11, 10, 'coin'); b.brick(12, 10);
  b.q(14, 10, 'orb:fire'); b.q(17, 10, 'orb:glass');
  b.en('zombie', 24); b.en('zombie', 31);
  b.stairs(33, 4, 1);
  b.arc(36, 11, 8, 3);
  b.check(45); b.lamp(47);
  b.en('zombie', 51); b.en('zombie', 54);
  b.tramp(58, 'tire');
  b.plat(55, 7, 8); b.coins(56, 6, 6); b.coins(60, 5, 1, 1, 20);
  b.q(66, 10, 'helmet');
  b.en('zombie_glass', 72);
  b.plat(77, 11, 2);
  b.cone(78);
  // sala secreta
  b.solid(84, 10, 9, 1, BQD.TILE.STEEL); b.fake(84, 11, 1, 3); b.fake(92, 11, 1, 3);
  b.coins(86, 13, 5); b.coins(88, 12, 1, 1, 20); b.secret(85, 11, 7, 3);
  b.coins(85, 8, 7);
  b.en('zombie', 97); b.en('zombie', 100);
  b.q(98, 10, 'boot');
  b.plat(107, 11, 3); b.coins(107, 10, 3);
  b.spikes(117, 119);
  b.arc(115, 10, 7, 2);
  b.check(123); b.lamp(125);
  b.en('zombie', 129); b.en('zombie', 132); b.en('zombie', 135);
  b.q(131, 10, 'heart'); b.cone(127); b.cone(138);
  b.stairs(145, 5, 1); b.cs(145, 5, 6);
  b.goal(160);
  b.hid(150, 9, '1up');
});

/* ───────────── 1-2  Telhados ───────────── */
BQD.LEVELS['1-2'] = BQD.buildLevel({ id: '1-2', name: 'Telhados', w: 200, tone: 'sunset', par: 130 }, function (b) {
  b.seg(0, 20, 14);
  b.seg(24, 33, 12);
  b.seg(37, 46, 10);
  b.seg(50, 61, 12);
  b.seg(65, 79, 14);
  b.seg(83, 95, 14);
  b.seg(99, 108, 11);
  b.seg(112, 124, 13);
  b.seg(128, 140, 11);
  b.seg(144, 163, 14);
  b.seg(167, 199, 14);
  b.spawn(3);
  b.cone(6); b.lamp(8);
  b.q(10, 10, 'orb:fire'); b.q(12, 10, 'orb:ice'); b.brick(11, 10); b.brick(13, 10);
  b.cs(14, 4);
  b.en('zombie', 18);
  b.arc(20, 11, 5, 2);
  b.en('zombie', 29); b.cone(31);
  b.coins(35, 8, 3);
  b.check(39);
  b.en('zombie_glass', 44);
  b.plat(47, 8, 3); b.coins(47, 7, 3);
  b.q(55, 8, 'orb:energy');
  b.en('zombie', 57); b.en('zombie', 60);
  b.tramp(63, 'bag');
  b.plat(62, 6, 6); b.coins(62, 5, 6); b.coins(65, 4, 1, 1, 20);
  b.en('crow', 70, 9); b.en('zombie', 74);
  b.q(70, 10, 'helmet');
  b.spikes(77, 78);
  b.check(85);
  b.en('zombie_glass', 90); b.en('zombie', 93);
  b.arc(95, 11, 5, 3);
  b.tramp(101, 'spring'); b.plat(103, 6, 5); b.coins(103, 5, 5);
  b.en('crow', 105, 8);
  b.q(114, 10, 'turbine');
  b.en('zombie', 118); b.en('zombie', 121);
  b.arc(124, 10, 5, 2);
  b.hid(132, 7, 'gold');
  b.en('zombie_glass', 134); b.en('crow', 136, 8);
  b.cs(129, 3, 2);
  b.check(148);
  b.en('zombie', 151); b.en('zombie', 154); b.en('zombie', 157);
  b.q(153, 10, 'heart');
  b.arc(163, 11, 5, 2);
  b.en('zombie', 172); b.en('zombie_glass', 178);
  b.stairs(185, 5, 1); b.cs(185, 5, 6);
  b.goal(194);
});

/* ───────────── 1-3  Obras e Metro ───────────── */
BQD.LEVELS['1-3'] = BQD.buildLevel({ id: '1-3', name: 'Obras e Metro', w: 220, tone: 'night', par: 150 }, function (b) {
  b.seg(0, 24, 14);
  b.seg(28, 44, 14);
  b.seg(48, 60, 12);
  b.seg(64, 82, 14);
  b.seg(86, 92, 14);
  b.seg(96, 118, 14);
  b.seg(122, 140, 12);
  b.seg(144, 170, 14);
  b.seg(174, 219, 14);
  b.spawn(3);
  b.cone(6); b.cone(8); b.cone(10); b.lamp(12);
  b.q(14, 10, 'orb:sound'); b.q(16, 10, 'orb:potion');
  b.en('zombie', 21);
  b.plat(29, 10, 4); b.plat(35, 8, 4); b.coins(29, 9, 4); b.coins(35, 7, 4);
  b.en('crow', 34, 7); b.en('zombie', 40);
  b.check(43);
  b.plat(46, 9, 3);
  b.en('zombie_glass', 55); b.q(52, 8, 'orb:energy');
  b.tramp(58, 'tire'); b.plat(56, 5, 6); b.coins(56, 4, 6); b.coins(59, 3, 1, 1, 20);
  b.cone(62);
  b.en('zombie', 68); b.en('crow', 72, 9); b.en('zombie', 76);
  b.crack(80, 11, 1, 3); b.coins(81, 13, 1);
  b.spikes(87, 90);
  b.arc(84, 10, 4, 3);
  b.q(98, 10, 'helmet');
  b.check(100);
  // túnel do metro: tecto de aço
  b.solid(101, 6, 16, 2, BQD.TILE.STEEL);
  b.en('crow', 104, 10); b.en('crow', 110, 11);
  b.en('zombie', 106); b.en('zombie', 112); b.en('zombie_glass', 115);
  b.cs(102, 12, 2);
  // sala secreta escondida por parede rachada (dive / ataque carregado / poder)
  b.solid(119, 8, 3, 2, BQD.TILE.STEEL);
  b.crack(116, 11, 2, 3); b.secret(112, 11, 4, 3); b.coins(112, 13, 4); b.coins(114, 12, 1, 1, 20);
  b.q(126, 8, 'orb:fire');
  b.en('zombie_glass', 128); b.en('zombie', 132); b.en('crow', 135, 8);
  b.plat(138, 8, 3);
  b.hid(133, 7, '1up');
  b.arc(141, 9, 5, 2);
  b.check(147);
  b.en('zombie', 150); b.en('zombie', 153); b.en('zombie', 156); b.en('zombie_glass', 160);
  b.q(152, 10, 'heart'); b.q(158, 10, 'bubble');
  b.spikes(163, 165);
  b.arc(161, 10, 6, 3);
  b.en('crow', 178, 8); b.en('zombie', 182); b.en('zombie', 186); b.en('zombie_glass', 192);
  b.cone(180); b.cone(196);
  b.stairs(204, 6, 1); b.cs(204, 6, 7);
  b.goal(213);
});

/* ───────────── 1-B  Arena do Demolidor ───────────── */
BQD.LEVELS['1-B'] = BQD.buildLevel({ id: '1-B', name: 'Demolidor', w: 30, tone: 'dusk', boss: true, music: 'boss', par: 90 }, function (b) {
  b.ground(0, 29);
  b.solid(0, 0, 1, 14, BQD.TILE.STEEL); b.solid(29, 0, 1, 14, BQD.TILE.STEEL);
  b.spawn(3);
  b.plat(3, 10, 4); b.plat(23, 10, 4); b.plat(12, 8, 6);
  b.q(4, 7, 'heart'); b.q(24, 7, 'heart');
  b.q(13, 5, 'orb:fire'); b.q(16, 5, 'orb:energy');
  b.boss('demolidor', 24);
});

/* ───────────── 2-1  Túneis Antigos ───────────── */
BQD.LEVELS['2-1'] = BQD.buildLevel({ id: '2-1', name: 'Túneis Antigos', w: 158, theme: 'mine', tone: 'mine', music: 'mine', par: 120 }, function (b) {
  b.ground(0, 30); b.ground(36, 58); b.ground(66, 90); b.ground(96, 118); b.ground(124, 157);
  b.spawn(3);
  b.crystal(8, 11); b.crystal(20, 12); b.cs(9, 5);
  b.q(12, 10, 'orb:fire'); b.brick(13, 10); b.q(14, 10, 'orb:sound');
  b.en('fire_demon', 22); b.en('fire_demon', 27);
  b.lava(31, 35, 16); b.lift(33, 8, 14, 3, 0.4, 'v');
  b.crystal(40, 10); b.arc(38, 11, 6, 3);
  b.en('zombie', 46); b.q(50, 9, 'heart');
  b.check(56);
  b.lava(59, 65, 16); b.lift(61, 6, 13, 3, 0.5, 'v');
  b.crystal(70, 9); b.en('fire_demon', 74); b.en('fire_demon', 80);
  b.plat(77, 10, 4); b.coins(78, 9, 4);
  b.solid(84, 9, 3, 2, BQD.TILE.STEEL); b.crack(88, 11, 2, 3); b.secret(85, 11, 6, 3); b.coins(86, 13, 5); b.coins(88, 12, 1, 1, 20);
  b.en('zombie_glass', 94);
  b.lava(91, 95, 16); b.lift(93, 7, 14, 3, 0.45, 'v');
  b.crystal(100, 10); b.crystal(112, 9);
  b.check(104);
  b.en('fire_demon', 108); b.en('fire_demon', 113);
  b.q(110, 9, 'orb:ice');
  b.arc(116, 10, 6, 2);
  b.hid(120, 8, '1up');
  b.lava(121, 123, 16); b.lift(122, 8, 14, 3, 0.4, 'v');
  b.en('fire_demon', 130); b.en('zombie', 135);
  b.q(133, 9, 'orb:energy');
  b.crystal(140, 9); b.crystal(142, 9);
  b.cs(146, 6, 6);
  b.goal(153);
});

/* ───────────── 2-2  Poço de Cristal ───────────── */
BQD.LEVELS['2-2'] = BQD.buildLevel({ id: '2-2', name: 'Poço de Cristal', w: 172, theme: 'mine', tone: 'mine', music: 'mine', par: 130 }, function (b) {
  b.ground(0, 26); b.ground(32, 48); b.ground(54, 70); b.ground(78, 96); b.ground(102, 122); b.ground(128, 171);
  b.spawn(3);
  b.crystal(10, 11); b.crystal(14, 8); b.plat(12, 9, 4); b.coins(12, 8, 4);
  b.en('fire_demon', 20); b.q(24, 9, 'orb:glass');
  b.lava(28, 31, 16); b.lift(29, 9, 14, 3, 0.5, 'v');
  b.en('zombie_glass', 38); b.crystal(42, 10); b.arc(40, 11, 6, 3);
  b.check(46);
  b.lava(49, 53, 16); b.lift(51, 4, 13, 3, 0.42, 'v');
  b.crystal(58, 8); b.crystal(60, 6); b.en('fire_demon', 62); b.en('fire_demon', 66);
  b.q(64, 9, 'heart');
  b.lava(72, 77, 16); b.lift(73, 10, 15, 4, 0.55, 'v');
  b.lift(11, 71, 83, 4, 0.5, 'h');
  b.solid(82, 8, 3, 2, BQD.TILE.STEEL); b.crack(86, 10, 2, 4); b.secret(83, 10, 6, 4); b.coins(84, 13, 5); b.coins(86, 12, 1, 1, 20);
  b.en('zombie', 92);
  b.check(98);
  b.crystal(104, 9); b.crystal(118, 9);
  b.en('fire_demon', 108); b.en('zombie_glass', 114);
  b.q(110, 9, 'orb:sound');
  b.lava(123, 127, 16); b.lift(125, 7, 14, 3, 0.48, 'v');
  b.arc(131, 10, 6, 2); b.hid(136, 8, 'gold');
  b.en('fire_demon', 140); b.en('fire_demon', 146); b.en('zombie', 151);
  b.q(144, 9, 'orb:potion');
  b.crystal(158, 9); b.cs(160, 6, 6);
  b.goal(167);
});

/* ───────────── 2-3  Elevadores e Lava ───────────── */
BQD.LEVELS['2-3'] = BQD.buildLevel({ id: '2-3', name: 'Elevadores e Lava', w: 190, theme: 'mine', tone: 'mine', music: 'mine', par: 150 }, function (b) {
  b.ground(0, 24); b.ground(70, 92); b.ground(140, 189);
  b.spawn(3);
  b.crystal(9, 11); b.en('fire_demon', 14); b.en('fire_demon', 19);
  b.q(16, 9, 'orb:fire');
  b.check(22);
  b.lava(25, 69, 16);
  b.lift(28, 8, 15, 3, 0.5, 'v'); b.lift(38, 5, 14, 3, 0.42, 'v'); b.lift(11, 44, 56, 4, 0.55, 'h');
  b.lift(7, 30, 64, 4, 0.5, 'h'); b.lift(58, 6, 13, 3, 0.46, 'v'); b.lift(65, 10, 15, 3, 0.5, 'v');
  b.crystal(45, 7); b.crystal(52, 6);
  b.en('fire_demon', 76); b.en('zombie_glass', 82);
  b.q(79, 9, 'orb:ice'); b.q(87, 9, 'heart');
  b.solid(90, 8, 3, 2, BQD.TILE.STEEL); b.crack(93, 10, 2, 4);
  b.check(94);
  b.lava(93, 139, 16);
  b.lift(96, 7, 14, 3, 0.48, 'v'); b.lift(106, 4, 13, 3, 0.4, 'v'); b.lift(11, 110, 124, 4, 0.5, 'h');
  b.lift(112, 6, 14, 3, 0.4, 'v'); b.lift(126, 6, 13, 3, 0.44, 'v'); b.lift(134, 9, 15, 3, 0.5, 'v');
  b.crystal(101, 6); b.crystal(121, 7); b.crystal(131, 6);
  b.en('fire_demon', 144); b.en('fire_demon', 149); b.en('zombie', 154);
  b.q(147, 9, 'orb:energy'); b.q(157, 9, 'orb:sound');
  b.crack(160, 11, 2, 3); b.secret(157, 11, 6, 3); b.coins(158, 13, 5); b.coins(160, 12, 1, 1, 20);
  b.hid(165, 8, '1up');
  b.en('fire_demon', 170); b.en('zombie_glass', 176);
  b.crystal(182, 9);
  b.cs(180, 6, 6);
  b.goal(186);
});

/* ───────────── 2-B  Arena do Perfurador ───────────── */
BQD.LEVELS['2-B'] = BQD.buildLevel({ id: '2-B', name: 'Perfurador', w: 30, theme: 'mine', tone: 'mine', boss: true, music: 'boss', par: 100 }, function (b) {
  b.ground(0, 29);
  b.solid(0, 0, 1, 14, BQD.TILE.STEEL); b.solid(29, 0, 1, 14, BQD.TILE.STEEL);
  b.spawn(3);
  b.plat(3, 10, 4); b.plat(23, 10, 4); b.plat(12, 8, 6); b.crystal(15, 7); b.crystal(17, 7);
  b.q(4, 7, 'heart'); b.q(24, 7, 'heart');
  b.q(13, 5, 'orb:ice'); b.q(16, 5, 'orb:glass');
  b.boss('perfurador', 24);
});

/* ───────────── 3-1  Portas do Abismo ───────────── */
BQD.LEVELS['3-1'] = BQD.buildLevel({ id: '3-1', name: 'Portas do Abismo', w: 162, theme: 'infernal', tone: 'infernal', music: 'infernal', par: 125 }, function (b) {
  b.ground(0, 28); b.ground(34, 56); b.ground(64, 86); b.ground(92, 114); b.ground(120, 161);
  b.spawn(3);
  b.cs(9, 5);
  b.q(12, 10, 'orb:fire'); b.brick(13, 10); b.q(14, 10, 'orb:energy');
  b.en('witch', 22); b.en('zombie', 27);
  b.lava(29, 33, 16);
  b.arc(30, 10, 5, 3);
  b.en('witch', 40); b.q(44, 9, 'heart');
  b.check(50);
  b.lava(57, 63, 16); b.lift(59, 8, 14, 3, 0.5, 'v');
  b.en('fire_demon', 68); b.en('witch', 74);
  b.plat(71, 9, 4); b.coins(72, 8, 4);
  b.solid(80, 9, 3, 2, BQD.TILE.STEEL); b.crack(84, 11, 2, 3); b.secret(81, 11, 6, 3); b.coins(82, 13, 5); b.coins(84, 12, 1, 1, 20);
  b.en('zombie_glass', 90);
  b.lava(87, 91, 16);
  b.check(96);
  b.en('witch', 100); b.en('witch', 106);
  b.q(102, 9, 'orb:potion');
  b.arc(110, 10, 5, 2);
  b.hid(116, 8, '1up');
  b.en('fire_demon', 122); b.en('witch', 128);
  b.q(125, 9, 'orb:sound');
  b.cs(150, 6, 6);
  b.en('witch', 138); b.en('zombie', 144);
  b.goal(157);
});

/* ───────────── 3-2  Rios de Lava ───────────── */
BQD.LEVELS['3-2'] = BQD.buildLevel({ id: '3-2', name: 'Rios de Lava', w: 186, theme: 'infernal', tone: 'infernal', music: 'infernal', par: 150 }, function (b) {
  b.ground(0, 22); b.ground(60, 82); b.ground(120, 185);
  b.spawn(3);
  b.en('witch', 14); b.q(16, 9, 'orb:fire');
  b.check(20);
  b.lava(23, 59, 16);
  b.lift(26, 8, 15, 3, 0.5, 'v'); b.lift(36, 5, 14, 3, 0.42, 'v'); b.lift(11, 42, 54, 4, 0.55, 'h');
  b.lift(7, 28, 58, 4, 0.48, 'h'); b.lift(54, 6, 13, 3, 0.46, 'v');
  b.en('fire_demon', 65); b.en('witch', 71);
  b.q(68, 9, 'orb:ice'); b.q(77, 9, 'heart');
  b.solid(84, 8, 3, 2, BQD.TILE.STEEL); b.crack(88, 10, 2, 4); b.secret(85, 10, 6, 4); b.coins(86, 13, 5); b.coins(88, 12, 1, 1, 20);
  b.check(94);
  b.en('witch', 100); b.en('witch', 106); b.en('fire_demon', 112);
  b.q(104, 9, 'orb:energy');
  b.lava(117, 119, 16);
  b.arc(122, 10, 6, 2);
  b.en('witch', 128); b.en('zombie_glass', 134);
  b.q(131, 9, 'orb:glass');
  b.hid(140, 8, 'gold');
  b.en('fire_demon', 145); b.en('witch', 151); b.en('zombie', 157);
  b.q(155, 9, 'orb:sound');
  b.cs(178, 6, 6);
  b.goal(182);
});

/* ───────────── 3-3  Covil das Bruxas ───────────── */
BQD.LEVELS['3-3'] = BQD.buildLevel({ id: '3-3', name: 'Covil das Bruxas', w: 176, theme: 'infernal', tone: 'infernal', music: 'infernal', par: 145 }, function (b) {
  b.ground(0, 26); b.ground(32, 54); b.ground(62, 84); b.ground(90, 112); b.ground(118, 175);
  b.spawn(3);
  b.en('witch', 20); b.en('witch', 26);
  b.q(23, 9, 'orb:potion');
  b.check(30);
  b.lava(33, 37, 16); b.lift(35, 8, 14, 3, 0.5, 'v');
  b.en('fire_demon', 42); b.en('witch', 48);
  b.plat(45, 9, 4); b.coins(46, 8, 4);
  b.q(52, 9, 'heart');
  b.solid(58, 9, 3, 2, BQD.TILE.STEEL); b.crack(62 - 4, 11, 2, 3);
  b.secret(59, 11, 6, 3); b.coins(60, 13, 5); b.coins(62, 12, 1, 1, 20);
  b.en('witch', 68); b.en('witch', 74);
  b.check(80);
  b.q(72, 9, 'orb:fire');
  b.lava(85, 89, 16); b.lift(87, 7, 14, 3, 0.48, 'v');
  b.en('fire_demon', 94); b.en('witch', 100); b.en('witch', 106);
  b.q(98, 9, 'orb:energy');
  b.arc(110, 10, 6, 2);
  b.hid(115, 8, '1up');
  b.en('witch', 122); b.en('witch', 128); b.en('fire_demon', 134); b.en('zombie_glass', 140);
  b.q(125, 9, 'orb:ice'); b.q(137, 9, 'orb:sound');
  b.crystal(150, 9);
  b.cs(168, 6, 6);
  b.goal(172);
});

/* ───────────── 3-B  Arena do Burner ───────────── */
BQD.LEVELS['3-B'] = BQD.buildLevel({ id: '3-B', name: 'Burner', w: 32, theme: 'infernal', tone: 'infernal', boss: true, music: 'boss', par: 110 }, function (b) {
  b.ground(0, 31);
  b.solid(0, 0, 1, 14, BQD.TILE.STEEL); b.solid(31, 0, 1, 14, BQD.TILE.STEEL);
  b.spawn(3);
  b.plat(3, 10, 4); b.plat(25, 10, 4); b.plat(13, 8, 6);
  b.q(4, 7, 'heart'); b.q(26, 7, 'heart');
  b.q(14, 5, 'orb:ice'); b.q(17, 5, 'orb:energy');
  b.lava(9, 12, 16); b.lava(19, 22, 16);
  b.boss('burner', 26);
});

/* ───────────── 4-1  Tempestade Branca ───────────── */
BQD.LEVELS['4-1'] = BQD.buildLevel({ id: '4-1', name: 'Tempestade Branca', w: 160, theme: 'ice', tone: 'ice', music: 'ice', par: 120 }, function (b) {
  b.ground(0, 30); b.ground(36, 58); b.ground(66, 90); b.ground(96, 118); b.ground(124, 159);
  b.spawn(3);
  b.cs(9, 5);
  b.q(12, 10, 'orb:ice'); b.brick(13, 10); b.q(14, 10, 'orb:fire');
  b.en('ice_beast', 22); b.en('ice_beast', 28);
  b.arc(32, 11, 6, 3);
  b.check(45);
  b.en('ice_beast', 50); b.en('ice_beast', 55);
  b.tramp(60, 'tire'); b.plat(58, 7, 6); b.coins(59, 6, 6);
  b.q(68, 9, 'orb:energy');
  b.en('ice_beast', 74); b.en('ice_beast', 80);
  b.solid(84, 9, 3, 2, BQD.TILE.STEEL); b.crack(88, 11, 2, 3); b.secret(85, 11, 6, 3); b.coins(86, 13, 5); b.coins(88, 12, 1, 1, 20);
  b.check(102);
  b.en('ice_beast', 106); b.en('ice_beast', 112); b.en('ice_beast', 116);
  b.q(110, 9, 'heart');
  b.hid(120, 8, '1up');
  b.arc(126, 10, 6, 2);
  b.en('ice_beast', 132); b.en('ice_beast', 138); b.en('ice_beast', 144);
  b.q(140, 9, 'orb:sound');
  b.cs(150, 6, 6);
  b.goal(155);
});

/* ───────────── 4-2  Montanha Congelada ───────────── */
BQD.LEVELS['4-2'] = BQD.buildLevel({ id: '4-2', name: 'Montanha Congelada', w: 176, theme: 'ice', tone: 'ice', music: 'ice', par: 135 }, function (b) {
  b.ground(0, 24); b.ground(60, 82); b.ground(120, 175);
  b.spawn(3);
  b.en('ice_beast', 14); b.q(16, 9, 'orb:ice');
  b.check(20);
  b.lift(28, 8, 15, 3, 0.5, 'v'); b.lift(38, 5, 14, 3, 0.42, 'v'); b.lift(11, 44, 56, 4, 0.55, 'h');
  b.lift(48, 9, 15, 4, 0.5, 'v');
  b.en('ice_beast', 65); b.en('ice_beast', 71);
  b.q(68, 9, 'heart');
  b.solid(84, 8, 3, 2, BQD.TILE.STEEL); b.crack(88, 10, 2, 4); b.secret(85, 10, 6, 4); b.coins(86, 13, 5); b.coins(88, 12, 1, 1, 20);
  b.check(94);
  b.en('ice_beast', 100); b.en('ice_beast', 106); b.en('ice_beast', 112);
  b.q(104, 9, 'orb:glass');
  b.lift(96, 6, 14, 3, 0.48, 'v'); b.lift(106, 9, 15, 3, 0.45, 'v');
  b.arc(122, 10, 6, 2);
  b.en('ice_beast', 128); b.en('ice_beast', 134); b.en('ice_beast', 140);
  b.q(131, 9, 'orb:potion');
  b.hid(145, 8, 'gold');
  b.en('ice_beast', 150); b.en('ice_beast', 156);
  b.cs(168, 6, 6);
  b.goal(172);
});

/* ───────────── 4-3  Caverna de Gelo ───────────── */
BQD.LEVELS['4-3'] = BQD.buildLevel({ id: '4-3', name: 'Caverna de Gelo', w: 168, theme: 'ice', tone: 'ice', music: 'ice', par: 130 }, function (b) {
  b.ground(0, 26); b.ground(32, 54); b.ground(62, 84); b.ground(90, 112); b.ground(118, 167);
  b.spawn(3);
  b.en('ice_beast', 20); b.en('ice_beast', 26);
  b.q(23, 9, 'orb:fire');
  b.check(30);
  b.en('ice_beast', 36); b.en('ice_beast', 42); b.en('ice_beast', 48);
  b.plat(45, 9, 4); b.coins(46, 8, 4);
  b.q(52, 9, 'heart');
  b.solid(58, 9, 3, 2, BQD.TILE.STEEL); b.crack(60, 11, 2, 3); b.secret(59, 11, 6, 3); b.coins(60, 13, 5); b.coins(62, 12, 1, 1, 20);
  b.en('ice_beast', 68); b.en('ice_beast', 74); b.en('ice_beast', 80);
  b.check(86);
  b.q(72, 9, 'orb:energy');
  b.lift(96, 7, 14, 3, 0.5, 'v'); b.lift(106, 5, 13, 3, 0.44, 'v');
  b.en('ice_beast', 100); b.en('ice_beast', 108); b.en('ice_beast', 114);
  b.q(104, 9, 'orb:sound');
  b.arc(116, 10, 6, 2);
  b.hid(122, 8, '1up');
  b.en('ice_beast', 128); b.en('ice_beast', 134); b.en('ice_beast', 140); b.en('ice_beast', 146);
  b.q(137, 9, 'orb:glass');
  b.cs(160, 6, 6);
  b.goal(164);
});

/* ───────────── 4-B  Arena de Graus Negativos ───────────── */
BQD.LEVELS['4-B'] = BQD.buildLevel({ id: '4-B', name: 'Graus Negativos', w: 32, theme: 'ice', tone: 'ice', boss: true, music: 'boss', par: 110 }, function (b) {
  b.ground(0, 31);
  b.solid(0, 0, 1, 14, BQD.TILE.STEEL); b.solid(31, 0, 1, 14, BQD.TILE.STEEL);
  b.spawn(3);
  b.plat(3, 10, 4); b.plat(25, 10, 4); b.plat(13, 8, 6);
  b.q(4, 7, 'heart'); b.q(26, 7, 'heart');
  b.q(14, 5, 'orb:fire'); b.q(17, 5, 'orb:energy');
  b.boss('grausnegativos', 26);
});

/* ───────────── 5-1  Portões de Ferro ───────────── */
BQD.LEVELS['5-1'] = BQD.buildLevel({ id: '5-1', name: 'Portões de Ferro', w: 166, theme: 'castle', tone: 'castle', music: 'castle', par: 125 }, function (b) {
  b.ground(0, 28); b.ground(34, 56); b.ground(64, 86); b.ground(92, 114); b.ground(120, 165);
  b.spawn(3);
  b.cs(9, 5);
  b.q(12, 10, 'orb:energy'); b.brick(13, 10); b.q(14, 10, 'orb:ice');
  b.en('guard', 22); b.en('zombie_glass', 28);
  b.arc(32, 10, 5, 3);
  b.check(45);
  b.en('guard', 50); b.en('guard', 56);
  b.plat(58, 8, 4); b.coins(59, 7, 4);
  b.solid(80, 9, 3, 2, BQD.TILE.STEEL); b.crack(84, 11, 2, 3); b.secret(81, 11, 6, 3); b.coins(82, 13, 5); b.coins(84, 12, 1, 1, 20);
  b.en('zombie_glass', 90); b.en('guard', 96);
  b.q(93, 9, 'heart');
  b.check(102);
  b.en('guard', 106); b.en('guard', 112);
  b.q(109, 9, 'orb:sound');
  b.arc(116, 10, 5, 2);
  b.hid(122, 8, '1up');
  b.en('guard', 128); b.en('guard', 134); b.en('zombie_glass', 140);
  b.cs(156, 6, 6);
  b.goal(161);
});

/* ───────────── 5-2  Corredores Secretos ───────────── */
BQD.LEVELS['5-2'] = BQD.buildLevel({ id: '5-2', name: 'Corredores Secretos', w: 178, theme: 'castle', tone: 'castle', music: 'castle', par: 140 }, function (b) {
  b.ground(0, 22); b.ground(60, 82); b.ground(120, 177);
  b.spawn(3);
  b.en('guard', 14); b.q(16, 9, 'orb:fire');
  b.check(20);
  b.lift(26, 8, 15, 3, 0.5, 'v'); b.lift(36, 5, 14, 3, 0.42, 'v'); b.lift(11, 42, 56, 4, 0.5, 'h');
  b.lift(54, 6, 13, 3, 0.46, 'v');
  b.en('witch', 65); b.en('guard', 71);
  b.q(68, 9, 'orb:glass'); b.q(77, 9, 'heart');
  b.solid(84, 8, 3, 2, BQD.TILE.STEEL); b.crack(88, 10, 2, 4); b.secret(85, 10, 6, 4); b.coins(86, 13, 5); b.coins(88, 12, 1, 1, 20);
  b.check(94);
  b.en('witch', 100); b.en('guard', 106); b.en('guard', 112);
  b.q(104, 9, 'orb:energy');
  b.spikes(117, 119);
  b.arc(122, 10, 6, 2);
  b.en('witch', 128); b.en('zombie_glass', 134);
  b.q(131, 9, 'orb:potion');
  b.hid(140, 8, 'gold');
  b.en('guard', 145); b.en('guard', 151); b.en('witch', 157);
  b.q(155, 9, 'orb:sound');
  b.cs(168, 6, 6);
  b.goal(173);
});

/* ───────────── 5-3  Salão do Trono ───────────── */
BQD.LEVELS['5-3'] = BQD.buildLevel({ id: '5-3', name: 'Salão do Trono', w: 172, theme: 'castle', tone: 'castle', music: 'castle', par: 140 }, function (b) {
  b.ground(0, 26); b.ground(32, 54); b.ground(62, 84); b.ground(90, 112); b.ground(118, 171);
  b.spawn(3);
  b.en('guard', 20); b.en('guard', 26);
  b.q(23, 9, 'orb:energy');
  b.check(30);
  b.en('fire_demon', 36); b.en('witch', 42);
  b.plat(45, 9, 4); b.coins(46, 8, 4);
  b.q(52, 9, 'heart');
  b.solid(58, 9, 3, 2, BQD.TILE.STEEL); b.crack(62, 11, 2, 3); b.secret(59, 11, 6, 3); b.coins(60, 13, 5); b.coins(62, 12, 1, 1, 20);
  b.en('guard', 68); b.en('witch', 74); b.en('guard', 80);
  b.check(86);
  b.q(72, 9, 'orb:ice');
  b.en('fire_demon', 94); b.en('guard', 100); b.en('witch', 106);
  b.q(98, 9, 'orb:fire');
  b.arc(110, 10, 6, 2);
  b.hid(115, 8, '1up');
  b.en('guard', 122); b.en('guard', 128); b.en('witch', 134); b.en('fire_demon', 140);
  b.q(137, 9, 'orb:sound');
  b.crystal(150, 9);
  b.cs(164, 6, 6);
  b.goal(168);
});

/* ───────────── 5-B  Castelo Esmeralda: KRUMPIE ───────────── */
BQD.LEVELS['5-B'] = BQD.buildLevel({ id: '5-B', name: 'Krumpie', w: 30, theme: 'castle', tone: 'castle', boss: true, music: 'boss', par: 150 }, function (b) {
  b.ground(0, 29);
  b.solid(0, 0, 1, 14, BQD.TILE.STEEL); b.solid(29, 0, 1, 14, BQD.TILE.STEEL);
  b.spawn(3);
  b.plat(3, 10, 4); b.plat(23, 10, 4); b.plat(12, 8, 6);
  b.q(4, 7, 'heart'); b.q(24, 7, 'heart');
  b.q(13, 5, 'orb:fire'); b.q(16, 5, 'orb:ice'); b.q(19, 5, 'orb:energy');
  b.lava(8, 10, 16); b.lava(19, 21, 16);
  b.boss('krumpie', 24);
});

/* ───────────── Mundos ───────────── */
BQD.WORLDS = [
  { id: 1, name: 'Zona Urbana', short: 'Urbana', icon: '🏙️', levels: ['1-1', '1-2', '1-3', '1-B'], fragment: 'urbano', storyKey: 'world1', endKey: 'world1end',
    nodes: [ { id: '1-1', x: 14, y: 68 }, { id: '1-2', x: 38, y: 40 }, { id: '1-3', x: 62, y: 62 }, { id: '1-B', x: 84, y: 34, boss: true } ] },
  { id: 2, name: 'Minas Subterrâneas', short: 'Minas', icon: '⛏️', levels: ['2-1', '2-2', '2-3', '2-B'], fragment: 'mineral', storyKey: 'world2', endKey: 'world2end',
    nodes: [ { id: '2-1', x: 14, y: 68 }, { id: '2-2', x: 38, y: 40 }, { id: '2-3', x: 62, y: 62 }, { id: '2-B', x: 84, y: 34, boss: true } ] },
  { id: 3, name: 'Infernum Ground', short: 'Infernum', icon: '🔥', levels: ['3-1', '3-2', '3-3', '3-B'], fragment: 'infernal', storyKey: 'world3', endKey: 'world3end',
    nodes: [ { id: '3-1', x: 14, y: 68 }, { id: '3-2', x: 38, y: 40 }, { id: '3-3', x: 62, y: 62 }, { id: '3-B', x: 84, y: 34, boss: true } ] },
  { id: 4, name: 'Ice Cream Ground', short: 'Ice Cream', icon: '🍦', levels: ['4-1', '4-2', '4-3', '4-B'], fragment: 'glacial', storyKey: 'world4', endKey: 'world4end',
    nodes: [ { id: '4-1', x: 14, y: 68 }, { id: '4-2', x: 38, y: 40 }, { id: '4-3', x: 62, y: 62 }, { id: '4-B', x: 84, y: 34, boss: true } ] },
  { id: 5, name: 'Castelo Esmeralda', short: 'Castelo', icon: '🏰', levels: ['5-1', '5-2', '5-3', '5-B'], fragment: null, storyKey: 'world5', endKey: 'ending', final: true,
    nodes: [ { id: '5-1', x: 14, y: 68 }, { id: '5-2', x: 38, y: 40 }, { id: '5-3', x: 62, y: 62 }, { id: '5-B', x: 84, y: 34, boss: true } ] }
];
/* BlockQuest — narrativa. Cada cena: dur (frames), text, scene (função de desenho em Art.scenes) */
var BQD = window.BQD = window.BQD || {};
BQD.STORY = {
  intro: [
    { dur: 230, scene: 'black',    text: 'Durante séculos, o Reino Esmeralda viveu em paz...' },
    { dur: 230, scene: 'block',    text: 'O lendário Bloco Mestre mantinha o equilíbrio entre os mundos.' },
    { dur: 230, scene: 'theft',    text: 'Até que alguém decidiu quebrar o equilíbrio.' },
    { dur: 230, scene: 'ruin',     text: 'As barreiras do Infernum Ground caíram. Os monstros invadiram o reino.' },
    { dur: 230, scene: 'heroes',   text: 'Os antigos heróis sacrificaram-se e destruíram o Bloco Mestre.' },
    { dur: 230, scene: 'fragments',text: 'Os fragmentos espalharam-se pelos diferentes reinos.' },
    { dur: 240, scene: 'bob',      text: 'Agora, alguém terá de encontrar os fragmentos.' },
    { dur: 999999, scene: 'title', text: '', final: true }
  ],
  world1: [
    { dur: 260, scene: 'cityruin', text: 'O primeiro fragmento caiu numa cidade que antes era símbolo da prosperidade do Reino Esmeralda.' },
    { dur: 240, scene: 'cityzombies', text: 'Agora, mortos-vivos patrulham as ruas destruídas.' },
    { dur: 200, scene: 'goal1', text: 'Objetivo: encontrar o Fragmento Urbano.' }
  ],
  world1end: [
    { dur: 250, scene: 'fragfound', text: 'O primeiro fragmento reagiu aos poderes do Bloco Mestre e revelou a localização de outro fragmento.' },
    { dur: 260, scene: 'mine', text: 'Nas profundezas da terra existem minas abandonadas. Mas os mineiros não foram os únicos a descobrir o que estava escondido lá.' },
    { dur: 200, scene: 'goal1', text: 'Objetivo: encontrar o Fragmento Mineral.' }
  ],
  world2: [
    { dur: 240, scene: 'mineDeep', text: 'Nas profundezas da terra existem minas abandonadas.' },
    { dur: 240, scene: 'mineDemons', text: 'Mas os mineiros não foram os únicos a descobrir o que estava escondido lá. Demónios de fogo agora vagueiam pelos túneis.' },
    { dur: 200, scene: 'goalMine', text: 'Objetivo: encontrar o Fragmento Mineral.' }
  ],
  world2end: [
    { dur: 250, scene: 'fragfound', text: 'O segundo fragmento reagiu e apontou para um terceiro. A fronteira entre os mundos foi destruída.' },
    { dur: 260, scene: 'infernoGate', text: 'O lugar conhecido como Infernum Ground está agora aberto.' },
    { dur: 200, scene: 'goalInferno', text: 'Objetivo: recuperar o Fragmento Infernal.' }
  ],
  world3: [
    { dur: 240, scene: 'infernoGate', text: 'A fronteira entre os mundos foi destruída. O lugar conhecido como Infernum Ground está agora aberto.' },
    { dur: 240, scene: 'infernoWitches', text: 'Bruxas vindas das sombras patrulham a paisagem em chamas.' },
    { dur: 200, scene: 'goalInferno', text: 'Objetivo: recuperar o Fragmento Infernal.' }
  ],
  world3end: [
    { dur: 250, scene: 'fragfound', text: 'O terceiro fragmento reagiu e revelou a localização do quarto. Uma força desconhecida cobriu uma região distante de gelo.' },
    { dur: 220, scene: 'iceStorm', text: 'Uma força desconhecida congelou completamente esta região.' }
  ],
  world4: [
    { dur: 230, scene: 'iceStorm', text: 'Uma força desconhecida congelou completamente esta região.' },
    { dur: 230, scene: 'iceAnimals', text: 'O quarto fragmento encontra-se enterrado sob o gelo, guardado por animais mortos-vivos.' },
    { dur: 200, scene: 'goalIce', text: 'Objetivo: encontrar o Fragmento Glacial.' }
  ],
  world4end: [
    { dur: 250, scene: 'fragfound', text: 'Todos os fragmentos apontam agora para o mesmo lugar.' },
    { dur: 220, scene: 'castleFar', text: 'O Castelo Esmeralda.' }
  ],
  world5: [
    { dur: 220, scene: 'castleFar', text: 'Todos os fragmentos apontam para o mesmo lugar.' },
    { dur: 200, scene: 'castleFar', text: 'O Castelo Esmeralda.' },
    { dur: 230, scene: 'krumpieReveal', text: 'A jornada termina aqui.' },
    { dur: 200, scene: 'goalCastle', text: 'Objetivo: invadir o Castelo Esmeralda e enfrentar Krumpie.' }
  ],
  ending: [
    { dur: 240, scene: 'shardsGather', text: 'Os fragmentos, finalmente juntos, começam a reagir uns com os outros.' },
    { dur: 240, scene: 'blockRebuild', text: 'O Bloco Mestre começa a reconstruir-se.' },
    { dur: 240, scene: 'kingdomHeal', text: 'O Reino Esmeralda começa a recuperar.' },
    { dur: 260, scene: 'heroesLineup', text: 'Bob e todos os que se juntaram a ele na jornada olham para o novo amanhecer.' },
    { dur: 999999, scene: 'victoryTitle', text: '', final: true }
  ]
};
'use strict';
/* BlockQuest — utilitários base */
var BQ = window.BQ = window.BQ || {};
BQ.W = 480; BQ.H = 272; BQ.T = 16;
BQ.FONT = '"Trebuchet MS","Segoe UI",Verdana,system-ui,sans-serif';
BQ.clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
BQ.lerp = function (a, b, t) { return a + (b - a) * t; };
BQ.rand = function (a, b) { return a + Math.random() * (b - a); };
BQ.rint = function (a, b) { return Math.floor(a + Math.random() * (b - a + 1)); };
BQ.pick = function (arr) { return arr[Math.floor(Math.random() * arr.length)]; };
BQ.hash = function (n) { var s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
BQ.mk = function (w, h) { var c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
BQ.hit = function (a, b) { return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y; };
BQ.fmtTime = function (frames) {
  var s = Math.floor(frames / 60), m = Math.floor(s / 60); s = s % 60;
  return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
};
/* texto com contorno (canvas) */
BQ.txt = function (ctx, s, x, y, size, color, align, outline) {
  ctx.font = 'bold ' + size + 'px ' + BQ.FONT;
  ctx.textAlign = align || 'left'; ctx.textBaseline = 'alphabetic';
  ctx.lineJoin = 'round';
  ctx.lineWidth = Math.max(2, size / 3.2);
  ctx.strokeStyle = outline || '#0b0f14';
  ctx.strokeText(s, x, y);
  ctx.fillStyle = color || '#fff';
  ctx.fillText(s, x, y);
};
BQ.rr = function (ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
};
/* contorno de 1px à volta de um sprite (devolve novo canvas 2px maior) */
BQ.outline = function (src, color) {
  var w = src.width + 2, h = src.height + 2, out = BQ.mk(w, h), c = out.getContext('2d');
  var sil = BQ.mk(w, h), s = sil.getContext('2d');
  s.drawImage(src, 1, 1); s.globalCompositeOperation = 'source-in'; s.fillStyle = color || '#10131a'; s.fillRect(0, 0, w, h);
  var d = [[-1, 0], [1, 0], [0, -1], [0, 1]];
  for (var i = 0; i < 4; i++) c.drawImage(sil, d[i][0], d[i][1]);
  c.drawImage(src, 1, 1);
  return out;
};
BQ.flipped = function (src) {
  var o = BQ.mk(src.width, src.height), c = o.getContext('2d');
  c.translate(src.width, 0); c.scale(-1, 1); c.drawImage(src, 0, 0); return o;
};
'use strict';
/* BlockQuest — SaveSystem (localStorage) */
BQ.Save = function () {
  this.key = 'blockquest_save_v1';
  this.data = this.load();
};
BQ.Save.prototype.defaults = function () {
  return {
    hasSave: false, seenIntro: false, char: 'bob', owned: ['bob'], coins: 0,
    done: {}, stars: {}, worlds: 1, bosses: {}, frags: {}, ach: {}, fusions: {}, records: {}, story: {}, newGamePlus: 0,
    settings: { music: true, sfx: true, volume: 0.7, vibration: true, shake: true, quality: 'medium', contrast: false,
                btnScale: 1, btnOpacity: 0.6, btnPos: {}, lang: 'pt' }
  };
};
BQ.Save.prototype.load = function () {
  var d = this.defaults();
  try {
    var raw = localStorage.getItem(this.key);
    if (raw) {
      var s = JSON.parse(raw);
      for (var k in s) { if (k === 'settings') { for (var j in s.settings) d.settings[j] = s.settings[j]; } else d[k] = s[k]; }
    }
  } catch (e) {}
  return d;
};
BQ.Save.prototype.commit = function () {
  try { localStorage.setItem(this.key, JSON.stringify(this.data)); } catch (e) {}
};
BQ.Save.prototype.newGame = function () {
  var keep = this.data.settings, d = this.defaults();
  d.settings = keep; d.hasSave = true; d.seenIntro = this.data.seenIntro;
  this.data = d; this.commit();
};
BQ.Save.prototype.addCoins = function (n) { this.data.coins = Math.min(99999, this.data.coins + n); };
BQ.Save.prototype.levelDone = function (id) { return !!this.data.done[id]; };
'use strict';
/* BlockQuest — AudioSystem: efeitos e música gerados por síntese (sem ficheiros externos) */
BQ.Audio = function (save) {
  this.save = save;
  this.ctx = null; this.master = null; this.musicGain = null; this.sfxGain = null; this.noiseBuf = null;
  this.song = null; this.songName = ''; this.step = 0; this.nextTime = 0; this.timer = null;
  this.lastSfx = {};
};

BQ.Audio.CHORDS = { M: [0, 4, 7, 12, 16, 19], m: [0, 3, 7, 12, 15, 19], d: [0, 3, 6, 12, 15, 18], s: [0, 5, 7, 12, 17, 19] };

/* músicas: prog = [raiz MIDI, tipo] por compasso; motifs = índice do acorde (0-5) por passo de 1/16 */
BQ.Audio.SONGS = {
  menu: { bpm: 104, wave: 'square', prog: [[60, 'M'], [55, 'M'], [57, 'm'], [53, 'M']],
    motifs: [[3, -1, 2, -1, 4, -1, 2, -1, 3, -1, 5, -1, 4, 2, 3, -1], [2, -1, 4, -1, 3, -1, 1, -1, 2, -1, 4, 5, 3, -1, 2, -1]],
    perc: 'k...h...s...h.h.' },
  urban: { bpm: 112, wave: 'square', prog: [[57, 'm'], [53, 'M'], [48, 'M'], [55, 'M']],
    motifs: [[3, -1, 2, 3, -1, 4, -1, 2, 3, -1, 5, -1, 4, 3, 2, -1], [2, -1, 3, -1, 4, 3, -1, 2, 1, -1, 2, 3, -1, 4, -1, 5]],
    perc: 'k.h.s.h.k.hks.h.' },
  night: { bpm: 100, wave: 'triangle', prog: [[52, 'm'], [48, 'M'], [50, 'M'], [47, 'm']],
    motifs: [[3, -1, -1, 4, -1, 2, -1, -1, 3, -1, 5, -1, 4, -1, 2, -1], [2, -1, 3, -1, -1, 4, -1, 3, 1, -1, 2, -1, 3, -1, -1, 4]],
    perc: 'k...s...k.k.s...' },
  mine: { bpm: 96, wave: 'triangle', prog: [[45, 'm'], [43, 'M'], [41, 'm'], [48, 'M']],
    motifs: [[3, -1, -1, 2, -1, -1, 4, -1, 3, -1, -1, 2, -1, -1, 5, -1], [2, -1, 3, -1, 4, -1, -1, 3, 2, -1, 1, -1, 2, -1, -1, 3]],
    perc: 'k..h...k..h..s..' },
  infernal: { bpm: 118, wave: 'sawtooth', prog: [[43, 'm'], [43, 'd'], [40, 'm'], [46, 'M']],
    motifs: [[3, 3, -1, 4, 3, 3, -1, 2, 3, 3, -1, 5, 3, 3, 2, -1], [2, -1, 3, 3, -1, 4, 3, -1, 2, -1, 3, 3, -1, 5, 4, -1]],
    perc: 'k.hks.h.k.hks.h.' },
  ice: { bpm: 104, wave: 'triangle', prog: [[57, 'M'], [55, 'm'], [52, 'M'], [50, 'M']],
    motifs: [[3, -1, 2, -1, 4, -1, 3, -1, 2, -1, 5, -1, 4, 3, 2, -1], [2, -1, 4, -1, 3, -1, 2, -1, 1, -1, 3, -1, 4, -1, 2, -1]],
    perc: 'k...h...k...h.s.' },
  castle: { bpm: 112, wave: 'sawtooth', prog: [[45, 'm'], [50, 'M'], [43, 'M'], [47, 'm']],
    motifs: [[3, -1, 4, -1, 3, -1, 2, -1, 3, -1, 5, -1, 4, -1, 3, -1], [2, -1, 3, -1, 4, 3, -1, 2, 1, -1, 2, -1, 3, -1, 4, -1]],
    perc: 'k.h.s.h.k.h.s.h.' },
  boss: { bpm: 148, wave: 'sawtooth', prog: [[45, 'm'], [45, 'm'], [41, 'M'], [44, 'd']],
    motifs: [[3, 3, -1, 2, 3, 3, -1, 4, 3, 3, -1, 5, 4, 3, 2, 1], [4, -1, 3, 2, 4, -1, 3, 5, 4, 4, 3, 2, 3, 4, 5, 4]],
    perc: 'k.hkskhkk.hkskhs' }
};
BQ.Audio.JINGLES = {
  win: { bpm: 150, notes: [[72, 1], [76, 1], [79, 1], [84, 3], [79, 1], [84, 4]] },
  lose: { bpm: 110, notes: [[67, 2], [64, 2], [60, 2], [55, 6]] },
  frag: { bpm: 130, notes: [[76, 1], [79, 1], [83, 1], [88, 2], [83, 1], [88, 6]] }
};

BQ.Audio.prototype.unlock = function () {
  if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
  var AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  try {
    this.ctx = new AC();
    this.master = this.ctx.createGain(); this.master.connect(this.ctx.destination);
    this.musicGain = this.ctx.createGain(); this.musicGain.connect(this.master);
    this.sfxGain = this.ctx.createGain(); this.sfxGain.connect(this.master);
    var len = this.ctx.sampleRate, buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;
    this.applySettings();
    if (this.songName) { var n = this.songName; this.songName = ''; this.music(n); }
  } catch (e) { this.ctx = null; }
};
BQ.Audio.prototype.applySettings = function () {
  if (!this.ctx) return;
  var s = this.save.data.settings;
  this.master.gain.value = s.volume;
  this.musicGain.gain.value = s.music ? 0.42 : 0;
  this.sfxGain.gain.value = s.sfx ? 1 : 0;
};

BQ.Audio.prototype._osc = function (type, f0, f1, t, dur, vol, dest, attack) {
  var c = this.ctx, o = c.createOscillator(), g = c.createGain();
  o.type = type; o.frequency.setValueAtTime(f0, t);
  if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  var a = attack || 0.004;
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + a);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(dest || this.sfxGain); o.start(t); o.stop(t + dur + 0.03);
};
BQ.Audio.prototype._noise = function (t, dur, vol, freq, type, dest) {
  var c = this.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
  s.buffer = this.noiseBuf; f.type = type || 'lowpass'; f.frequency.value = freq || 1200;
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f); f.connect(g); g.connect(dest || this.sfxGain); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.03);
};
BQ.Audio.prototype.sfx = function (name) {
  if (!this.ctx || !this.save.data.settings.sfx) return;
  var c = this.ctx, t = c.currentTime, self = this;
  if (this.lastSfx[name] && t - this.lastSfx[name] < 0.035) return;   // evita empilhar o mesmo som
  this.lastSfx[name] = t;
  var o = function (ty, a, b, d, v, dl) { self._osc(ty, a, b, t + (dl || 0), d, v); };
  switch (name) {
    case 'jump': o('square', 260, 620, 0.14, 0.09); break;
    case 'djump': o('square', 420, 900, 0.12, 0.09); break;
    case 'coin': o('square', 988, 988, 0.05, 0.08); o('square', 1319, 1319, 0.16, 0.08, 0.05); break;
    case 'coin5': [880, 1109, 1319, 1760].forEach(function (f, i) { o('square', f, f, 0.1, 0.08, i * 0.05); }); break;
    case 'coin20': [988, 1319, 1568, 1976, 2637].forEach(function (f, i) { o('triangle', f, f, 0.16, 0.14, i * 0.06); }); break;
    case 'stomp': o('square', 240, 70, 0.14, 0.14); this._noise(t, 0.06, 0.15, 900); break;
    case 'swing': this._noise(t, 0.09, 0.12, 2400, 'bandpass'); o('sawtooth', 500, 200, 0.07, 0.04); break;
    case 'hit': this._noise(t, 0.08, 0.22, 1600); o('square', 180, 60, 0.1, 0.12); break;
    case 'hit3': this._noise(t, 0.16, 0.3, 900); o('square', 140, 40, 0.2, 0.16); break;
    case 'hurt': o('sawtooth', 420, 90, 0.32, 0.14); break;
    case 'die': [523, 466, 415, 392, 330, 262].forEach(function (f, i) { o('square', f, f * 0.9, 0.16, 0.11, i * 0.11); }); break;
    case 'power': [523, 659, 784, 1047].forEach(function (f, i) { o('square', f, f, 0.09, 0.09, i * 0.05); }); break;
    case 'item': o('triangle', 600, 1200, 0.2, 0.15); break;
    case 'cast': o('sawtooth', 200, 900, 0.16, 0.08); this._noise(t, 0.12, 0.08, 3000, 'highpass'); break;
    case 'beam': o('sawtooth', 1400, 300, 0.22, 0.09); o('square', 700, 150, 0.22, 0.06); break;
    case 'fusion': [392, 523, 659, 784, 1047, 1319].forEach(function (f, i) { o('triangle', f, f * 1.01, 0.3, 0.12, i * 0.07); }); this._noise(t + 0.2, 0.4, 0.08, 4000, 'highpass'); break;
    case 'discover': [659, 784, 988, 1319, 988, 1319, 1568].forEach(function (f, i) { o('square', f, f, 0.14, 0.09, i * 0.08); }); break;
    case 'nofuse': o('square', 200, 150, 0.16, 0.1); o('square', 150, 110, 0.18, 0.1, 0.12); break;
    case 'boom': this._noise(t, 0.6, 0.4, 700); o('sine', 110, 30, 0.5, 0.35); break;
    case 'quake': this._noise(t, 0.35, 0.3, 300); o('sine', 70, 35, 0.35, 0.3); break;
    case 'spring': o('sine', 180, 900, 0.28, 0.2); o('square', 300, 1000, 0.2, 0.05); break;
    case 'block': o('square', 160, 110, 0.09, 0.14); break;
    case 'break': this._noise(t, 0.2, 0.25, 2500); o('square', 300, 80, 0.12, 0.08); break;
    case 'check': [523, 659, 784, 1047].forEach(function (f, i) { o('triangle', f, f, 0.18, 0.14, i * 0.06); }); break;
    case 'shield': o('triangle', 800, 300, 0.25, 0.16); this._noise(t, 0.1, 0.1, 5000, 'highpass'); break;
    case 'helmet': o('square', 330, 330, 0.08, 0.1); o('square', 494, 494, 0.08, 0.1, 0.08); o('square', 659, 659, 0.2, 0.1, 0.16); break;
    case 'ally': [392, 523, 392, 659, 784].forEach(function (f, i) { o('square', f, f, 0.1, 0.09, i * 0.06); }); break;
    case 'poof': this._noise(t, 0.2, 0.16, 1500); o('sine', 300, 100, 0.2, 0.1); break;
    case 'shard': o('square', 900, 500, 0.1, 0.05); break;
    case 'click': o('square', 700, 700, 0.04, 0.07); break;
    case 'select': o('square', 880, 880, 0.05, 0.08); o('square', 1175, 1175, 0.09, 0.08, 0.05); break;
    case 'back': o('square', 500, 350, 0.09, 0.08); break;
    case 'buy': [784, 988, 1175, 1568].forEach(function (f, i) { o('square', f, f, 0.1, 0.09, i * 0.06); }); break;
    case 'boss': o('sawtooth', 90, 45, 0.9, 0.22); this._noise(t, 0.9, 0.2, 400); break;
    case 'roar': o('sawtooth', 120, 50, 0.6, 0.18); this._noise(t, 0.4, 0.14, 500); break;
    case 'star': o('triangle', 1047, 1568, 0.25, 0.14); break;
    case 'radio': o('square', 660, 660, 0.06, 0.07); o('square', 880, 880, 0.06, 0.07, 0.06); o('square', 1100, 1100, 0.12, 0.07, 0.12); break;
    case 'invis': o('sine', 900, 300, 0.4, 0.12); break;
  }
};

BQ.Audio.prototype.jingle = function (name) {
  if (!this.ctx || !this.save.data.settings.music) return;
  var j = BQ.Audio.JINGLES[name]; if (!j) return;
  var t = this.ctx.currentTime + 0.05, sd = 60 / j.bpm / 2, self = this;
  this.pauseMusic();
  j.notes.forEach(function (n) {
    var f = 440 * Math.pow(2, (n[0] - 69) / 12), d = n[1] * sd;
    self._osc('square', f, f, t, d * 0.95, 0.16, self.musicGain);
    self._osc('triangle', f / 2, f / 2, t, d * 0.95, 0.14, self.musicGain);
    t += d;
  });
};

BQ.Audio.prototype.music = function (name) {
  if (name === this.songName && this.timer) return;
  this.songName = name;
  this.stopTimer();
  this.song = BQ.Audio.SONGS[name] || null;
  if (!this.ctx || !this.song) return;
  this.step = 0; this.nextTime = this.ctx.currentTime + 0.08;
  var self = this;
  this.timer = setInterval(function () { self._tick(); }, 30);
};
BQ.Audio.prototype.stopTimer = function () { if (this.timer) { clearInterval(this.timer); this.timer = null; } };
BQ.Audio.prototype.stopMusic = function () { this.stopTimer(); this.songName = ''; this.song = null; };
BQ.Audio.prototype.pauseMusic = function () { this.stopTimer(); };
BQ.Audio.prototype.resumeMusic = function () {
  if (!this.ctx || !this.song || this.timer) return;
  this.nextTime = this.ctx.currentTime + 0.1;
  var self = this; this.timer = setInterval(function () { self._tick(); }, 30);
};
BQ.Audio.prototype._tick = function () {
  if (!this.ctx || !this.song) return;
  var sd = 60 / this.song.bpm / 4;
  if (this.nextTime < this.ctx.currentTime - 0.5) this.nextTime = this.ctx.currentTime + 0.05;
  while (this.nextTime < this.ctx.currentTime + 0.14) { this._step(this.step, this.nextTime, sd); this.nextTime += sd; this.step++; }
};
BQ.Audio.prototype._step = function (s, t, sd) {
  var so = this.song, bar = Math.floor(s / 16) % so.prog.length, i = s % 16, ch = so.prog[bar];
  var tones = BQ.Audio.CHORDS[ch[1]], mo = so.motifs[bar % so.motifs.length][i];
  var f = function (m) { return 440 * Math.pow(2, (m - 69) / 12); };
  if (mo >= 0) this._osc(so.wave, f(ch[0] + 12 + tones[mo]), 0, t, sd * 1.7, 0.07, this.musicGain);
  if (i % 4 === 0) this._osc('triangle', f(ch[0] - 12), 0, t, sd * 3.4, 0.2, this.musicGain);
  else if (i % 2 === 0 && so.bpm > 130) this._osc('triangle', f(ch[0] - 12), 0, t, sd * 1.6, 0.14, this.musicGain);
  var p = so.perc.charAt(i);
  if (p === 'k') { this._osc('sine', 150, 40, t, 0.14, 0.32, this.musicGain); }
  else if (p === 's') { this._noise(t, 0.11, 0.16, 1800, 'bandpass', this.musicGain); }
  else if (p === 'h') { this._noise(t, 0.03, 0.06, 7000, 'highpass', this.musicGain); }
};
'use strict';
/* BlockQuest — InputSystem: teclado, botões de toque (multi-toque) e Gamepad API */
BQ.Input = function () {
  this.ACTS = ['left', 'right', 'down', 'jump', 'attack', 'pick', 'power', 'fuse', 'special', 'swap', 'pause'];
  this.kb = {}; this.touch = {}; this.gp = {}; this.latch = {}; this.held = {}; this.prev = {}; this.pressed = {}; this.released = {};
  this.touchCount = {}; this.enabled = true; this.anyTouch = false;
  this.KEYS = {
    ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right', ArrowDown: 'down', KeyS: 'down',
    Space: 'jump', ArrowUp: 'jump', KeyW: 'jump', KeyG: 'attack', KeyO: 'pick', KeyX: 'power', KeyC: 'fuse',
    KeyV: 'special', KeyQ: 'swap', Escape: 'pause', KeyP: 'pause'
  };
  var self = this, i;
  for (i = 0; i < this.ACTS.length; i++) { var a = this.ACTS[i]; this.held[a] = false; this.prev[a] = false; this.pressed[a] = false; this.released[a] = false; }
  window.addEventListener('keydown', function (e) {
    var a = self.KEYS[e.code];
    if (!a) return;
    if (self.enabled && (a === 'jump' || a === 'left' || a === 'right' || a === 'down')) e.preventDefault();
    if (e.repeat) return;
    self.kb[a] = true; self.latch[a] = true;
  });
  window.addEventListener('keyup', function (e) { var a = self.KEYS[e.code]; if (a) self.kb[a] = false; });
  window.addEventListener('blur', function () { self.kb = {}; self.touch = {}; self.touchCount = {}; });
};

/* liga botões HTML com data-act (mantém-se ligado mesmo que os botões sejam reposicionados) */
BQ.Input.prototype.bindTouch = function (root) {
  var self = this;
  var press = function (act, on) {
    var n = (self.touchCount[act] || 0) + (on ? 1 : -1);
    if (n < 0) n = 0;
    self.touchCount[act] = n;
    self.touch[act] = n > 0;
    if (on) { self.latch[act] = true; self.anyTouch = true; }
  };
  root.addEventListener('pointerdown', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el || root.classList.contains('customizing')) return;
    e.preventDefault();
    try { el.setPointerCapture(e.pointerId); } catch (x) {}
    el._pid = e.pointerId; el.classList.add('down');
    press(el.dataset.act, true);
  }, { passive: false });
  var up = function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el || el._pid !== e.pointerId) return;
    el._pid = null; el.classList.remove('down');
    press(el.dataset.act, false);
  };
  root.addEventListener('pointerup', up);
  root.addEventListener('pointercancel', up);
  root.addEventListener('lostpointercapture', up);
  root.addEventListener('contextmenu', function (e) { e.preventDefault(); });
};

BQ.Input.prototype.pollGamepad = function () {
  var pads = navigator.getGamepads ? navigator.getGamepads() : null, g = {};
  if (pads) {
    for (var i = 0; i < pads.length; i++) {
      var p = pads[i]; if (!p || !p.connected) continue;
      var b = p.buttons, ax = p.axes;
      var bt = function (n) { return b[n] && (b[n].pressed || b[n].value > 0.5); };
      if (bt(14) || (ax[0] || 0) < -0.4) g.left = true;
      if (bt(15) || (ax[0] || 0) > 0.4) g.right = true;
      if (bt(13) || (ax[1] || 0) > 0.6) g.down = true;
      if (bt(0) || bt(12)) g.jump = true;
      if (bt(2)) g.attack = true;
      if (bt(3)) g.pick = true;
      if (bt(1)) g.power = true;
      if (bt(5) || bt(7)) g.fuse = true;
      if (bt(4) || bt(6)) g.special = true;
      if (bt(8)) g.swap = true;
      if (bt(9)) g.pause = true;
    }
  }
  this.gp = g;
};

/* chamar uma vez por tick de lógica */
BQ.Input.prototype.poll = function () {
  this.pollGamepad();
  for (var i = 0; i < this.ACTS.length; i++) {
    var a = this.ACTS[i];
    var h = !!(this.kb[a] || this.touch[a] || this.gp[a]);
    this.prev[a] = this.held[a];
    this.held[a] = h;
    this.pressed[a] = (h && !this.prev[a]) || !!this.latch[a];
    this.released[a] = !h && this.prev[a];
    this.latch[a] = false;
  }
};
BQ.Input.prototype.clear = function () {
  for (var i = 0; i < this.ACTS.length; i++) { var a = this.ACTS[i]; this.held[a] = this.prev[a] = this.pressed[a] = this.released[a] = false; this.latch[a] = false; }
};
'use strict';
/* BlockQuest — Art: pixel art gerada proceduralmente (sprites, tiles, ícones) */
BQ.Art = {
  chars: {}, enemy: {}, icon: {}, tiles: [], coin: {}, lightCache: {}, ready: false
};

(function (Art) {
  var T = BQD.TILE;
  function R(c, x, y, w, h, col) { c.fillStyle = col; c.fillRect(x, y, w, h); }
  function shade(hex, amt) {
    var n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    r = BQ.clamp(Math.round(r + amt), 0, 255); g = BQ.clamp(Math.round(g + amt), 0, 255); b = BQ.clamp(Math.round(b + amt), 0, 255);
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }
  Art.shade = shade;

  /* ───────────── humanoides ───────────── */
  function human(look, pose) {
    var cv = BQ.mk(16, 16), c = cv.getContext('2d');
    var bob = pose.bob ? 1 : 0, st = look.style, dark = shade(look.skin, -40);
    var legs = pose.leg || 'stand', arm = pose.arm || 'down';
    var ly = 11 + (bob && legs === 'stand' ? 0 : 0);
    // costas: cabelo de trás / rádio
    if (st === 'karen') { R(c, 4, 2 + bob, 2, 8, look.hair); }
    if (st === 'dj') { R(c, 2, 8 + bob, 3, 4, '#7a3fd0'); R(c, 3, 9 + bob, 1, 1, '#ffd23f'); R(c, 3, 11 + bob, 1, 1, '#ffd23f'); }
    // braço de trás
    var bax = 4, bay = 7 + bob;
    if (arm === 'swing') bax = 5; if (arm === 'up') { bax = 3; bay = 3 + bob; }
    R(c, bax, bay, 2, 4, shade(look.top, -30)); R(c, bax, bay + 4, 2, 1, dark);
    // pernas
    var lc = look.bottom, sh = look.shoe;
    var legDraw = function (x, y, h, w) { R(c, x, y, w || 2, h, lc); R(c, x, y + h, (w || 2) + 1, 1, sh); };
    if (st === 'funny') { legDraw = function (x, y, h) { R(c, x, y, 2, h, lc); R(c, x, y + h, 4, 1, sh); }; }
    if (legs === 'stand') { legDraw(5, ly, 4); legDraw(9, ly, 4); }
    else if (legs === 'a') { legDraw(3, ly, 3); legDraw(10, ly, 3); R(c, 4, ly + 2, 1, 1, lc); R(c, 9, ly + 2, 1, 1, lc); }
    else if (legs === 'b') { legDraw(6, ly, 4); legDraw(8, ly, 4); }
    else if (legs === 'c') { legDraw(4, ly, 4); legDraw(9, ly, 2); R(c, 10, ly + 2, 2, 1, sh); }
    else if (legs === 'jump') { legDraw(4, ly, 2); R(c, 3, ly + 2, 2, 1, sh); legDraw(9, ly, 3); }
    // tronco
    R(c, 5, 7 + bob, 6, 4, look.top);
    R(c, 5, 10 + bob, 6, 1, look.top2);
    if (st === 'karen') { R(c, 4, 10 + bob, 8, 2, look.top); R(c, 4, 12 + bob, 8, 1, look.top2); R(c, 5, 8 + bob, 6, 1, '#ffd0e6'); }
    if (st === 'ze') { R(c, 4, 10 + bob, 8, 3, look.top); R(c, 4, 13 + bob, 8, 1, look.top2); R(c, 7, 7 + bob, 2, 6, '#ffd23f'); }
    if (st === 'bob') { R(c, 7, 7 + bob, 1, 4, '#ff8a1f'); R(c, 8, 9 + bob, 2, 2, '#e8e0c0'); R(c, 5, 10 + bob, 6, 1, '#2b2b1e'); }
    if (st === 'r26') { R(c, 6, 8 + bob, 4, 2, '#2f3a44'); R(c, 7, 8 + bob, 1, 1, '#4cff8a'); R(c, 9, 8 + bob, 1, 1, '#ff4a4a'); }
    if (st === 'funny') { R(c, 5, 8 + bob, 6, 1, look.top2); R(c, 5, 10 + bob, 6, 1, look.top2); }
    if (st === 'dj') { R(c, 5, 7 + bob, 6, 1, shade(look.top, -25)); R(c, 7, 9 + bob, 2, 2, '#14707a'); }
    // cabeça
    var hx = 5, hy = 1 + bob;
    R(c, hx, hy, 6, 6, look.skin); R(c, hx, hy + 5, 6, 1, dark);
    if (st === 'r26') { R(c, hx, hy, 6, 6, '#c8d2dc'); R(c, hx, hy + 5, 6, 1, '#8a97a3'); R(c, 8, hy + 2, 3, 2, pose.hurt ? '#ffffff' : '#ff3a3a'); R(c, 7, hy - 2, 1, 2, '#8a97a3'); R(c, 6, hy - 3, 3, 1, '#ffd23f'); }
    else {
      // olhos
      if (pose.hurt) { R(c, 8, hy + 2, 1, 1, '#141414'); R(c, 10, hy + 2, 1, 1, '#141414'); R(c, 9, hy + 3, 1, 1, '#141414'); R(c, 9, hy + 1, 1, 1, '#141414'); R(c, 9, hy + 2, 1, 1, '#141414'); }
      else if (st === 'dj') { R(c, 7, hy + 2, 4, 2, '#111'); R(c, 8, hy + 2, 1, 1, '#5cf0ff'); }
      else R(c, 9, hy + 2, 1, 2, '#141414');
      if (pose.win || pose.smile) R(c, 8, hy + 4, 2, 1, '#7a2a2a');
    }
    // cabelo / chapéus
    if (st === 'bob') { R(c, 4, hy - 1, 8, 3, '#6a7d3a'); R(c, 4, hy - 1, 8, 1, '#8ea34c'); R(c, 4, hy + 2, 8, 1, '#4a5a28'); R(c, 6, hy - 2, 4, 1, '#6a7d3a'); R(c, 5, hy + 3, 1, 2, look.hair); }
    if (st === 'karen') { R(c, 5, hy - 1, 6, 2, look.hair); R(c, 9, hy + 1, 2, 1, look.hair); R(c, 5, hy - 3, 1, 2, '#ffd23f'); R(c, 7, hy - 4, 2, 3, '#ffd23f'); R(c, 10, hy - 3, 1, 2, '#ffd23f'); R(c, 5, hy - 1, 6, 1, '#ffb400'); R(c, 8, hy - 3, 1, 1, '#ff4a4a'); }
    if (st === 'ze') { R(c, 4, hy, 8, 2, '#6a3fc0'); R(c, 5, hy - 2, 6, 2, '#6a3fc0'); R(c, 7, hy - 4, 3, 2, '#6a3fc0'); R(c, 8, hy - 5, 1, 1, '#ffd23f'); R(c, 6, hy + 4, 5, 3, '#f4f4f4'); R(c, 8, hy + 3, 3, 1, '#f4f4f4'); }
    if (st === 'funny') { R(c, 3, hy - 2, 10, 3, look.hair); R(c, 2, hy, 2, 3, look.hair); R(c, 12, hy, 2, 2, look.hair); R(c, 5, hy - 3, 3, 1, '#ff9b1f'); R(c, 11, hy + 3, 2, 2, '#ff2a2a'); R(c, 8, hy + 4, 3, 1, '#7a2a2a'); }
    if (st === 'dj') { R(c, 5, hy - 1, 6, 1, '#1a1a1a'); R(c, 4, hy - 1, 1, 6, '#2b2b45'); R(c, 4, hy + 2, 2, 3, '#2fd0e0'); R(c, 10, hy + 2, 2, 3, '#2fd0e0'); R(c, 4, hy, 1, 3, '#2b2b45'); R(c, 11, hy, 1, 2, '#2b2b45'); R(c, 5, hy, 6, 1, look.hair); }
    // braço da frente
    var fax = 10, fay = 7 + bob;
    if (arm === 'swing') fax = 9;
    if (arm === 'punch') { R(c, 10, 8 + bob, 4, 2, look.top); R(c, 14, 8 + bob, 2, 2, look.skin); }
    else if (arm === 'punch2') { R(c, 10, 5 + bob, 4, 2, look.top); R(c, 14, 5 + bob, 2, 2, look.skin); }
    else if (arm === 'up') { R(c, 10, 3 + bob, 2, 4, look.top); R(c, 10, 2 + bob, 2, 1, look.skin); }
    else { R(c, fax, fay, 2, 4, look.top); R(c, fax, fay + 4, 2, 1, look.skin); }
    if (st === 'r26') { /* mãos metálicas */ }
    return BQ.outline(cv);
  }

  function buildChars() {
    var poses = {
      idle0: { leg: 'stand', arm: 'down' }, idle1: { leg: 'stand', arm: 'down', bob: 1 },
      run0: { leg: 'a', arm: 'swing' }, run1: { leg: 'b', arm: 'down', bob: 1 }, run2: { leg: 'c', arm: 'swing' }, run3: { leg: 'b', arm: 'down', bob: 1 },
      jump: { leg: 'jump', arm: 'up' }, fall: { leg: 'a', arm: 'up' },
      hurt: { leg: 'b', arm: 'up', hurt: true }, win0: { leg: 'jump', arm: 'up', win: true }, win1: { leg: 'stand', arm: 'up', win: true, bob: 1 },
      atk0: { leg: 'a', arm: 'punch' }, atk1: { leg: 'c', arm: 'punch2' }, atk2: { leg: 'a', arm: 'punch', win: true },
      dive: { leg: 'jump', arm: 'up' }, charge: { leg: 'b', arm: 'swing', bob: 1 }, dead: { leg: 'jump', arm: 'up', hurt: true }
    };
    BQD.CHARACTERS.forEach(function (ch) {
      var set = {};
      for (var k in poses) set[k] = human(ch.look, poses[k]);
      Art.chars[ch.id] = set;
    });
  }

  /* ───────────── inimigos ───────────── */
  function zombie(variant, frame) {
    var cv = BQ.mk(16, 16), c = cv.getContext('2d'), skin = variant === 'glass' ? '#8fb5a0' : '#7fae5a', cl = variant === 'glass' ? '#e08a2a' : '#6a4a7a';
    var f = frame % 2, b = frame === 2 ? 1 : 0;
    R(c, f ? 4 : 5, 12, 2, 3, '#3a3a52'); R(c, f ? 9 : 8, 12, 2, 3, '#3a3a52'); R(c, f ? 4 : 5, 15, 3, 1, '#222'); R(c, f ? 9 : 8, 15, 3, 1, '#222');
    R(c, 4, 7 + b, 8, 5, cl); R(c, 4, 10 + b, 8, 1, shade(cl, -30)); R(c, 6, 11 + b, 1, 2, cl);
    R(c, 5, 1 + b, 6, 6, skin); R(c, 5, 6 + b, 6, 1, shade(skin, -40));
    R(c, 6, 3 + b, 2, 2, '#ff3a3a'); R(c, 9, 3 + b, 2, 2, '#ff3a3a'); R(c, 6, 3 + b, 1, 1, '#fff'); R(c, 9, 3 + b, 1, 1, '#fff');
    R(c, 7, 5 + b, 3, 1, '#2a1010'); R(c, 8, 5 + b, 1, 1, '#f2f2f2');
    R(c, 5, 0 + b, 3, 1, '#3a2a1e'); R(c, 9, 1 + b, 2, 1, '#3a2a1e');
    R(c, 11, 8 + b, 5, 2, cl); R(c, 14, 8 + b, 2, 2, skin);    // braços esticados
    R(c, 2, 8 + b, 3, 2, cl); R(c, 1, 8 + b, 2, 2, skin);
    if (variant === 'glass') { c.fillStyle = '#bfe9ff'; c.beginPath(); c.moveTo(15, 5 + b); c.lineTo(16, 9 + b); c.lineTo(13, 8 + b); c.fill(); R(c, 15, 6 + b, 1, 2, '#fff'); }
    return BQ.outline(cv);
  }
  function crow(frame) {
    var cv = BQ.mk(16, 14), c = cv.getContext('2d'), up = frame % 2 === 0;
    R(c, 4, 5, 8, 5, '#2a2a3a'); R(c, 3, 6, 2, 3, '#2a2a3a'); R(c, 12, 4, 4, 4, '#2a2a3a'); R(c, 15, 5, 2, 2, '#ff9b1f');
    R(c, 13, 5, 1, 1, '#ff3a3a'); R(c, 5, 8, 6, 2, '#43435a');
    if (up) { R(c, 5, 1, 3, 4, '#1c1c28'); R(c, 8, 0, 3, 5, '#1c1c28'); R(c, 4, 0, 2, 2, '#1c1c28'); }
    else { R(c, 5, 9, 3, 4, '#1c1c28'); R(c, 8, 9, 3, 5, '#1c1c28'); R(c, 4, 12, 2, 2, '#1c1c28'); }
    R(c, 2, 8, 3, 1, '#1c1c28'); R(c, 6, 10, 1, 2, '#ff9b1f'); R(c, 9, 10, 1, 2, '#ff9b1f');
    return BQ.outline(cv);
  }
  function demon(frame) {
    var cv = BQ.mk(16, 16), c = cv.getContext('2d'), b = frame === 1 ? 1 : 0;
    R(c, 5, 12, 2, 3, '#3a1008'); R(c, 9, 12, 2, 3, '#3a1008');
    R(c, 4, 7 + b, 8, 5, '#8a1f10'); R(c, 4, 10 + b, 8, 1, '#5a0f08');
    R(c, 5, 1 + b, 6, 6, '#c9401f'); R(c, 5, 6 + b, 6, 1, '#6e1a0c');
    R(c, 6, 3 + b, 2, 2, '#ffe27a'); R(c, 9, 3 + b, 2, 2, '#ffe27a'); R(c, 6, 3 + b, 1, 1, '#fff8d0'); R(c, 9, 3 + b, 1, 1, '#fff8d0');
    c.fillStyle = '#ff8a2b'; c.beginPath(); c.moveTo(5, 1 + b); c.lineTo(3, -1 + b); c.lineTo(6, 1 + b); c.fill();
    c.beginPath(); c.moveTo(11, 1 + b); c.lineTo(13, -1 + b); c.lineTo(10, 1 + b); c.fill();
    R(c, 11, 8 + b, 4, 2, '#8a1f10'); R(c, 1, 8 + b, 4, 2, '#8a1f10');
    if (frame === 2) { c.fillStyle = 'rgba(255,150,60,0.6)'; c.fillRect(3, 5, 10, 8); }
    return BQ.outline(cv);
  }
  function witch(frame) {
    var cv = BQ.mk(16, 17), c = cv.getContext('2d'), b = frame === 1 ? 1 : 0;
    R(c, 3, 13, 3, 3, '#2a2033'); R(c, 9, 13, 3, 3, '#2a2033');
    c.fillStyle = '#3a2a52'; c.beginPath(); c.moveTo(4, 8 + b); c.lineTo(12, 8 + b); c.lineTo(14, 16); c.lineTo(2, 16); c.fill();
    R(c, 5, 6 + b, 6, 4, '#4a3568');
    R(c, 5, 1 + b, 6, 6, '#c9a882'); R(c, 5, 6 + b, 6, 1, '#8a6a52');
    R(c, 6, 3 + b, 1, 2, '#2a1030'); R(c, 9, 3 + b, 1, 2, '#2a1030');
    R(c, 7, 5 + b, 2, 1, '#5a3a2a');
    c.fillStyle = '#241830'; c.beginPath(); c.moveTo(3, 1 + b); c.lineTo(13, 1 + b); c.lineTo(8, -6 + b); c.fill();
    R(c, 3, 0 + b, 10, 2, '#241830');
    R(c, 0, 9 + b, 4, 2, '#3a2a52'); R(c, 12, 9 + b, 4, 2, '#3a2a52');
    if (frame === 2) { c.fillStyle = '#9be24a'; c.beginPath(); c.arc(13, 8 + b, 2, 0, 6.283); c.fill(); }
    return BQ.outline(cv);
  }

  function iceBeast(frame) {
    var cv = BQ.mk(16, 14), c = cv.getContext('2d'), b = frame === 1 ? 1 : 0;
    R(c, 3, 10, 2, 3, '#bfe9ff'); R(c, 11, 10, 2, 3, '#bfe9ff'); R(c, 6, 10, 2, 3, '#bfe9ff'); R(c, 9, 10, 2, 3, '#bfe9ff');
    R(c, 3, 4 + b, 10, 7, '#dff6ff'); R(c, 3, 9 + b, 10, 1, '#8fc8e0');
    R(c, 11, 3 + b, 4, 4, '#dff6ff');
    R(c, 13, 2 + b, 2, 2, '#dff6ff'); R(c, 14, 3 + b, 1, 2, '#fff');
    R(c, 13, 4 + b, 1, 1, '#1a2a34'); 
    c.fillStyle = '#9fdcff'; c.beginPath(); c.moveTo(1, 5 + b); c.lineTo(4, 4 + b); c.lineTo(4, 8 + b); c.fill();
    R(c, 0, 6 + b, 3, 2, '#dff6ff');
    return BQ.outline(cv);
  }
  function guard(frame) {
    var cv = BQ.mk(16, 17), c = cv.getContext('2d'), b = frame === 1 ? 1 : 0;
    R(c, 4, 12, 3, 4, '#2a2a34'); R(c, 9, 12, 3, 4, '#2a2a34');
    R(c, 3, 6 + b, 10, 7, '#5a6270'); R(c, 3, 12 + b, 10, 1, '#3a4048');
    R(c, 3, 7 + b, 10, 2, '#7a8492');
    R(c, 5, 1 + b, 6, 6, '#c9a882'); R(c, 5, 6 + b, 6, 1, '#8a6a52');
    R(c, 4, 0 + b, 8, 2, '#4a5058'); R(c, 4, -2 + b, 8, 3, '#4a5058');
    R(c, 6, 3 + b, 1, 2, '#241830'); R(c, 9, 3 + b, 1, 2, '#241830');
    R(c, 12, 8 + b, 3, 6, '#8a95a3'); R(c, 1, 8 + b, 3, 6, '#5a6270');
    if (frame === 2) { R(c, 12, 6 + b, 2, 10, '#dcdfe3'); }
    return BQ.outline(cv);
  }

  function buildEnemies() {
    Art.enemy.zombie = [zombie('a', 0), zombie('a', 1), zombie('a', 2)];
    Art.enemy.zombie_glass = [zombie('glass', 0), zombie('glass', 1), zombie('glass', 2)];
    Art.enemy.crow = [crow(0), crow(1)];
    Art.enemy.fire_demon = [demon(0), demon(1), demon(2)];
    Art.enemy.witch = [witch(0), witch(1), witch(2)];
    Art.enemy.ice_beast = [iceBeast(0), iceBeast(1)];
    Art.enemy.guard = [guard(0), guard(1), guard(2)];
  }

  /* ───────────── tiles ───────────── */
  var QGLYPH = ['01110', '10001', '00001', '00110', '00100', '00000', '00100'];
  function tile(id, v) {
    var cv = BQ.mk(16, 16), c = cv.getContext('2d'), i, j;
    var h = function (n) { return BQ.hash(n + v * 17 + id * 3.1); };
    if (id === T.GROUND) {
      R(c, 0, 0, 16, 16, '#3c414d'); R(c, 0, 0, 16, 3, '#59606f'); R(c, 0, 0, 16, 1, '#8b95a8'); R(c, 0, 3, 16, 1, '#2a2e38');
      if (v % 3 === 0) { R(c, 2, 1, 5, 1, '#e6c229'); R(c, 9, 1, 5, 1, '#e6c229'); }
      for (i = 0; i < 9; i++) { R(c, Math.floor(h(i) * 15), 4 + Math.floor(h(i + 9) * 11), 1 + (i % 2), 1, i % 3 ? '#2d313b' : '#4c5260'); }
      if (v % 4 === 1) { R(c, 5, 4, 1, 3, '#20232b'); R(c, 6, 6, 1, 3, '#20232b'); R(c, 7, 8, 1, 2, '#20232b'); }
    } else if (id === T.DIRT) {
      R(c, 0, 0, 16, 16, '#2c303a');
      for (i = 0; i < 14; i++) { var w = 2 + Math.floor(h(i + 40) * 3); R(c, Math.floor(h(i) * 14), Math.floor(h(i + 20) * 14), w, 2, i % 2 ? '#3a3f4c' : '#22252d'); }
      if (v % 3 === 0) { R(c, 3, 4, 1, 4, '#1c1f26'); R(c, 4, 7, 1, 3, '#1c1f26'); }
    } else if (id === T.BRICK) {
      R(c, 0, 0, 16, 16, '#7a2f22');
      for (j = 0; j < 4; j++) {
        var off = j % 2 ? 4 : 0;
        for (i = -1; i < 3; i++) { R(c, i * 8 + off, j * 4, 7, 3, j % 2 ? '#c2573a' : '#b84e34'); R(c, i * 8 + off, j * 4, 7, 1, '#df7350'); }
      }
      R(c, 0, 15, 16, 1, '#4d1c14');
    } else if (id === T.QBLOCK) {
      R(c, 0, 0, 16, 16, '#7a4c10'); R(c, 1, 1, 14, 14, '#f5b935'); R(c, 1, 1, 14, 1, '#ffe27a'); R(c, 1, 1, 1, 14, '#ffe27a'); R(c, 1, 14, 14, 1, '#d98a1c'); R(c, 14, 1, 1, 14, '#d98a1c');
      R(c, 2, 2, 1, 1, '#7a4c10'); R(c, 13, 2, 1, 1, '#7a4c10'); R(c, 2, 13, 1, 1, '#7a4c10'); R(c, 13, 13, 1, 1, '#7a4c10');
      for (j = 0; j < 7; j++) for (i = 0; i < 5; i++) if (QGLYPH[j].charAt(i) === '1') { R(c, 5 + i * 1.2 | 0, 4 + j, 2, 1, '#7a4c10'); }
    } else if (id === T.USED) {
      R(c, 0, 0, 16, 16, '#4a3520'); R(c, 1, 1, 14, 14, '#8a6a46'); R(c, 1, 1, 14, 1, '#a8865c'); R(c, 1, 14, 14, 1, '#6a4e30');
      R(c, 2, 2, 1, 1, '#4a3520'); R(c, 13, 2, 1, 1, '#4a3520'); R(c, 2, 13, 1, 1, '#4a3520'); R(c, 13, 13, 1, 1, '#4a3520');
    } else if (id === T.GIRDER) {
      R(c, 0, 0, 16, 6, '#2b2f38'); R(c, 0, 0, 16, 1, '#c9d2e0');
      for (i = -1; i < 4; i++) { c.fillStyle = '#f2a81d'; c.beginPath(); c.moveTo(i * 6 + 2, 5); c.lineTo(i * 6 + 6, 5); c.lineTo(i * 6 + 8, 1); c.lineTo(i * 6 + 4, 1); c.fill(); }
      R(c, 0, 5, 16, 1, '#171a20'); R(c, 1, 2, 1, 1, '#c9d2e0'); R(c, 14, 2, 1, 1, '#c9d2e0');
    } else if (id === T.SPIKES) {
      for (i = 0; i < 4; i++) { c.fillStyle = '#8a4a2a'; c.beginPath(); c.moveTo(i * 4, 16); c.lineTo(i * 4 + 2, 5); c.lineTo(i * 4 + 4, 16); c.fill(); R(c, i * 4 + 2, 6, 1, 8, '#d9a070'); }
      R(c, 0, 14, 16, 2, '#4a2a1a');
    } else if (id === T.STEEL || id === T.FAKE) {
      var base = id === T.FAKE ? '#6f7a8b' : '#6c7686';
      R(c, 0, 0, 16, 16, '#2f3642'); R(c, 1, 1, 14, 14, base); R(c, 1, 1, 14, 1, '#a3b0c4'); R(c, 1, 1, 1, 14, '#8996ac'); R(c, 1, 14, 14, 1, '#4a5363'); R(c, 14, 1, 1, 14, '#4a5363');
      R(c, 2, 2, 2, 2, '#c7d1e0'); R(c, 12, 2, 2, 2, '#c7d1e0'); R(c, 2, 12, 2, 2, '#c7d1e0'); R(c, 12, 12, 2, 2, '#c7d1e0');
      R(c, 5, 7, 6, 2, '#59647a');
    } else if (id === T.CRACKED) {
      R(c, 0, 0, 16, 16, '#3a3f49'); R(c, 1, 1, 14, 14, '#8d929c'); R(c, 1, 1, 14, 1, '#b4b9c4'); R(c, 1, 14, 14, 1, '#666b75');
      R(c, 7, 1, 1, 4, '#22262e'); R(c, 6, 5, 1, 3, '#22262e'); R(c, 8, 8, 1, 4, '#22262e'); R(c, 4, 10, 4, 1, '#22262e'); R(c, 10, 5, 3, 1, '#22262e'); R(c, 12, 6, 1, 3, '#22262e');
      R(c, 5, 4, 2, 2, '#b4b9c4'); R(c, 10, 10, 2, 2, '#b4b9c4');
    }
    return cv;
  }
  function buildTiles() {
    for (var id = 1; id <= 11; id++) {
      var vs = [];
      for (var v = 0; v < 4; v++) vs.push(tile(id, v));
      Art.tiles[id] = vs;
    }
  }

  /* ───────────── ícones ───────────── */
  function powerIcon(p) {
    var cv = BQ.mk(16, 16), c = cv.getContext('2d'), col = p.color, col2 = p.color2;
    c.lineJoin = 'round';
    switch (p.id) {
      case 'fire':
        c.fillStyle = '#ff5a1f'; c.beginPath(); c.moveTo(8, 1); c.bezierCurveTo(13, 5, 14, 9, 11, 13); c.lineTo(5, 13); c.bezierCurveTo(2, 9, 5, 6, 8, 1); c.fill();
        c.fillStyle = '#ffd23f'; c.beginPath(); c.moveTo(8, 6); c.bezierCurveTo(11, 9, 11, 12, 9, 13); c.lineTo(6, 13); c.bezierCurveTo(5, 10, 7, 9, 8, 6); c.fill(); break;
      case 'ice':
        c.strokeStyle = '#dff6ff'; c.lineWidth = 2; c.beginPath();
        for (var a = 0; a < 3; a++) { var an = a * Math.PI / 3; c.moveTo(8 + Math.cos(an) * 6, 8 + Math.sin(an) * 6); c.lineTo(8 - Math.cos(an) * 6, 8 - Math.sin(an) * 6); }
        c.stroke(); c.strokeStyle = '#4fb6ee'; c.lineWidth = 1; c.stroke(); break;
      case 'glass':
        c.fillStyle = '#bfe9ff'; c.fillRect(3, 2, 10, 12); c.fillStyle = '#5aa8d8'; c.fillRect(3, 12, 10, 2); c.fillRect(12, 2, 1, 12);
        c.fillStyle = '#fff'; c.fillRect(4, 3, 2, 8); c.fillRect(7, 3, 1, 3); break;
      case 'potion':
        c.fillStyle = '#e9f6ff'; c.fillRect(6, 1, 4, 4); c.fillStyle = '#8a5a2a'; c.fillRect(6, 1, 4, 1);
        c.fillStyle = '#9be24a'; c.beginPath(); c.moveTo(6, 5); c.lineTo(10, 5); c.lineTo(14, 13); c.lineTo(2, 13); c.fill();
        c.fillStyle = '#d9ff9a'; c.fillRect(5, 11, 3, 1); c.fillStyle = '#fff'; c.fillRect(6, 7, 1, 2); break;
      case 'sound':
        c.fillStyle = '#ffd84a'; c.fillRect(2, 6, 3, 4); c.beginPath(); c.moveTo(5, 6); c.lineTo(9, 3); c.lineTo(9, 13); c.lineTo(5, 10); c.fill();
        c.strokeStyle = '#ff9b1f'; c.lineWidth = 1.5; c.beginPath(); c.arc(9, 8, 3, -1, 1); c.stroke(); c.beginPath(); c.arc(9, 8, 6, -1, 1); c.stroke(); break;
      case 'energy':
        c.fillStyle = '#ffe14a'; c.beginPath(); c.moveTo(10, 1); c.lineTo(3, 9); c.lineTo(7, 9); c.lineTo(5, 15); c.lineTo(13, 6); c.lineTo(9, 6); c.fill();
        c.strokeStyle = '#b58cff'; c.lineWidth = 1; c.stroke(); break;
      default:   // fusão: esfera bicolor com estrela
        var g = c.createLinearGradient(2, 2, 14, 14); g.addColorStop(0, col); g.addColorStop(1, col2);
        c.fillStyle = g; c.beginPath(); c.arc(8, 8, 6, 0, 7); c.fill();
        c.fillStyle = '#fff'; c.beginPath(); c.moveTo(8, 3); c.lineTo(9.5, 7); c.lineTo(13, 8); c.lineTo(9.5, 9); c.lineTo(8, 13); c.lineTo(6.5, 9); c.lineTo(3, 8); c.lineTo(6.5, 7); c.fill();
    }
    return cv;
  }
  Art.getPowerIcon = function (p) {
    if (!Art.icon['p_' + p.id]) Art.icon['p_' + p.id] = powerIcon(p);
    return Art.icon['p_' + p.id];
  };

  function itemIcons() {
    var mk = function (fn) { var cv = BQ.mk(16, 16); fn(cv.getContext('2d')); return BQ.outline(cv); };
    Art.icon.helmet = mk(function (c) { R(c, 2, 5, 12, 7, '#9fb3c8'); R(c, 4, 3, 8, 3, '#b8ccdf'); R(c, 1, 11, 14, 2, '#6d7f94'); R(c, 4, 4, 4, 1, '#fff'); R(c, 7, 6, 2, 5, '#ffd23f'); R(c, 2, 8, 12, 1, '#7d90a6'); });
    Art.icon.boot = mk(function (c) { R(c, 4, 2, 6, 8, '#3fa86a'); R(c, 4, 9, 10, 4, '#3fa86a'); R(c, 4, 12, 10, 2, '#1f5a3a'); R(c, 4, 2, 6, 2, '#ffd23f'); R(c, 5, 5, 1, 4, '#8be0ae'); R(c, 0, 4, 3, 2, '#fff'); R(c, 1, 6, 3, 2, '#fff'); });
    Art.icon.bubble = mk(function (c) { R(c, 1, 5, 14, 6, '#ffc21f'); R(c, 1, 5, 14, 1, '#ffe27a'); R(c, 1, 10, 14, 1, '#c98a10'); R(c, 5, 6, 6, 4, '#2a2a2a'); R(c, 6, 7, 4, 2, '#9be2ff'); R(c, 8, 7, 1, 2, '#fff'); R(c, 2, 7, 1, 2, '#7a4c10'); R(c, 13, 7, 1, 2, '#7a4c10'); });
    Art.icon.turbine = mk(function (c) { R(c, 5, 10, 6, 4, '#8b8f99'); c.fillStyle = '#c7ced9'; c.beginPath(); c.arc(8, 7, 6, 0, 7); c.fill(); c.fillStyle = '#5a6272'; for (var i = 0; i < 4; i++) { var a = i * Math.PI / 2 + 0.4; c.beginPath(); c.moveTo(8, 7); c.lineTo(8 + Math.cos(a) * 5, 7 + Math.sin(a) * 5); c.lineTo(8 + Math.cos(a + 0.7) * 5, 7 + Math.sin(a + 0.7) * 5); c.fill(); } R(c, 7, 6, 2, 2, '#ff8a1f'); });
    Art.icon.heart = mk(function (c) { c.fillStyle = '#ff4a5e'; c.beginPath(); c.moveTo(8, 14); c.bezierCurveTo(-2, 7, 3, 0, 8, 5); c.bezierCurveTo(13, 0, 18, 7, 8, 14); c.fill(); R(c, 4, 4, 2, 2, '#ffb0ba'); });
    Art.icon.oneup = mk(function (c) { R(c, 1, 3, 14, 10, '#2fbf5f'); R(c, 1, 3, 14, 1, '#8dffb0'); R(c, 1, 12, 14, 1, '#177a3a'); R(c, 3, 5, 1, 6, '#fff'); R(c, 2, 6, 1, 1, '#fff'); R(c, 6, 5, 1, 6, '#fff'); R(c, 6, 10, 3, 1, '#fff'); R(c, 10, 5, 3, 1, '#fff'); R(c, 10, 5, 1, 5, '#fff'); R(c, 12, 5, 1, 5, '#fff'); R(c, 10, 10, 3, 1, '#fff'); });
    Art.icon.heartHud = mk(function (c) { c.fillStyle = '#ff3b55'; c.beginPath(); c.moveTo(8, 14); c.bezierCurveTo(-2, 7, 3, 0, 8, 5); c.bezierCurveTo(13, 0, 18, 7, 8, 14); c.fill(); R(c, 4, 4, 2, 2, '#ffd0d6'); });
    Art.icon.heartEmpty = mk(function (c) { c.fillStyle = '#4a2a34'; c.beginPath(); c.moveTo(8, 14); c.bezierCurveTo(-2, 7, 3, 0, 8, 5); c.bezierCurveTo(13, 0, 18, 7, 8, 14); c.fill(); });
    Art.icon.shard = mk(function (c) { c.fillStyle = '#5fe0a0'; c.beginPath(); c.moveTo(8, 0); c.lineTo(13, 6); c.lineTo(10, 15); c.lineTo(5, 15); c.lineTo(3, 6); c.fill(); c.fillStyle = '#c9ffe3'; c.beginPath(); c.moveTo(8, 2); c.lineTo(10, 6); c.lineTo(8, 12); c.lineTo(6, 6); c.fill(); });
    Art.icon.star = mk(function (c) { c.fillStyle = '#ffd23f'; c.beginPath(); for (var i = 0; i < 10; i++) { var r = i % 2 ? 3 : 7.5, a = -Math.PI / 2 + i * Math.PI / 5; c.lineTo(8 + Math.cos(a) * r, 8.5 + Math.sin(a) * r); } c.fill(); });
    // moedas (frames de rotação)
    ['1', '5', '20'].forEach(function (k) {
      var frames = [], ws = [12, 10, 6, 2, 6, 10];
      ws.forEach(function (w) {
        var cv = BQ.mk(14, 14), c = cv.getContext('2d');
        if (k === '20') {
          c.fillStyle = '#26c6e8'; c.beginPath(); c.moveTo(7, 0); c.lineTo(7 + Math.max(1, w / 2 + 1), 7); c.lineTo(7, 14); c.lineTo(7 - Math.max(1, w / 2 + 1), 7); c.fill();
          c.fillStyle = '#b9f6ff'; c.beginPath(); c.moveTo(7, 2); c.lineTo(7 + Math.max(0, w / 4), 6); c.lineTo(7, 8); c.lineTo(7 - Math.max(0, w / 4), 6); c.fill();
        } else {
          var cw = Math.max(2, w), x = 7 - cw / 2;
          R(c, x, 1, cw, 12, k === '5' ? '#e07b12' : '#c98a10'); R(c, x + 1, 1, Math.max(1, cw - 2), 12, k === '5' ? '#ffb02e' : '#ffd23f');
          if (cw > 5) { R(c, 5, 4, 4, 6, k === '5' ? '#e07b12' : '#e2a51d'); R(c, 6, 5, 2, 4, k === '5' ? '#fff0a8' : '#ffe98a'); }
          if (k === '5' && cw > 5) { R(c, 6, 5, 2, 1, '#fff'); }
        }
        frames.push(BQ.outline(cv));
      });
      Art.coin[k] = frames;
    });
  }

  /* ───────────── Demolidor (boss 1) ───────────── */
  function demolidor(hurt, anger) {
    var cv = BQ.mk(44, 54), c = cv.getContext('2d'), y = 2;
    var body = hurt ? '#ffffff' : '#f2b21f', dk = hurt ? '#dddddd' : '#c98a10', stripe = '#22252d';
    // pernas / lagartas
    R(c, 4, 42, 14, 10, '#2b2f38'); R(c, 26, 42, 14, 10, '#2b2f38'); R(c, 5, 44, 12, 2, '#535a68'); R(c, 27, 44, 12, 2, '#535a68'); R(c, 6, 49, 10, 2, '#171a20'); R(c, 28, 49, 10, 2, '#171a20');
    // tronco
    R(c, 6, 18, 32, 26, body); R(c, 6, 18, 32, 3, hurt ? '#fff' : '#ffd968'); R(c, 6, 40, 32, 4, dk); R(c, 30, 20, 8, 22, dk);
    for (var i = 0; i < 4; i++) R(c, 8 + i * 8, 34, 4, 6, stripe);
    R(c, 12, 24, 20, 8, '#2a2d36'); R(c, 14, 26, 16, 4, anger ? '#ff3a1f' : '#ff8a1f'); R(c, 16, 27, 4, 2, '#ffe27a'); R(c, 24, 27, 4, 2, '#ffe27a');
    // capacete
    R(c, 10, 6, 24, 14, hurt ? '#fff' : '#ff8a1f'); R(c, 10, 6, 24, 3, hurt ? '#fff' : '#ffb15a'); R(c, 8, 17, 28, 3, dk); R(c, 30, 8, 4, 10, '#c9611a');
    R(c, 16, 11, 5, 4, '#ff3a3a'); R(c, 25, 11, 5, 4, '#ff3a3a'); R(c, 17, 12, 2, 2, '#fff'); R(c, 26, 12, 2, 2, '#fff');
    R(c, 14, 9, 8, 2, '#22252d'); R(c, 24, 9, 8, 2, '#22252d');
    // exaustor
    R(c, 2, 10, 4, 14, '#535a68'); R(c, 1, 8, 6, 3, '#2b2f38');
    // braços
    R(c, 0, 24, 8, 10, dk); R(c, 36, 24, 8, 10, dk); R(c, 0, 33, 8, 4, '#2b2f38'); R(c, 36, 33, 8, 4, '#2b2f38');
    return BQ.outline(cv);
  }

  Art.buildBoss = function () {
    Art.demolidor = [demolidor(false, false), demolidor(true, false), demolidor(false, true), demolidor(true, true)];
    Art.perfurador = [perfurador(false, 0), perfurador(true, 0), perfurador(false, 1), perfurador(true, 1)];
    Art.burner = [burner(false, false), burner(true, false), burner(false, true), burner(true, true)];
    Art.grausnegativos = [grausNeg(false, false), grausNeg(true, false), grausNeg(false, true), grausNeg(true, true)];
  };

  /* ───────────── Graus Negativos (boss 4): gigante de gelo ───────────── */
  function grausNeg(hurt, anger) {
    var cv = BQ.mk(42, 50), c = cv.getContext('2d'), body = hurt ? '#ffffff' : '#bfe9ff', dk = hurt ? '#eee' : '#6fb0d8', core = anger ? '#ff8a8a' : '#2a4a5a';
    R(c, 4, 30, 12, 18, dk); R(c, 26, 30, 12, 18, dk);
    R(c, 6, 8, 30, 26, body); R(c, 6, 8, 30, 4, '#fff'); R(c, 6, 30, 30, 4, dk);
    c.fillStyle = 'rgba(255,255,255,0.6)'; c.beginPath(); c.moveTo(10, 8); c.lineTo(14, 0); c.lineTo(18, 8); c.fill();
    c.beginPath(); c.moveTo(24, 8); c.lineTo(28, -2); c.lineTo(32, 8); c.fill();
    R(c, 12, 16, 7, 8, core); R(c, 23, 16, 7, 8, core);
    R(c, 14, 18, 3, 3, hurt ? '#fff' : '#eaffff'); R(c, 25, 18, 3, 3, hurt ? '#fff' : '#eaffff');
    R(c, 16, 26, 10, 2, '#1a2a34');
    R(c, 0, 14, 8, 18, dk); R(c, 34, 14, 8, 18, dk);
    R(c, 0, 30, 4, 10, body); R(c, 38, 30, 4, 10, body);
    return BQ.outline(cv);
  }

  /* ───────────── Perfurador (boss 2): broca que surge das paredes ───────────── */
  function perfurador(hurt, frame) {
    var cv = BQ.mk(40, 46), c = cv.getContext('2d'), body = hurt ? '#ffffff' : '#c94a2a', dk = hurt ? '#ddd' : '#7a2a14', drill = hurt ? '#eee' : '#dcdfe3';
    R(c, 6, 10, 28, 26, body); R(c, 6, 10, 28, 3, hurt ? '#fff' : '#e07850'); R(c, 6, 33, 28, 3, dk);
    R(c, 10, 18, 20, 10, '#241010');
    R(c, 13, 20, 6, 5, hurt ? '#fff' : '#ffd23f'); R(c, 21, 20, 6, 5, hurt ? '#fff' : '#ffd23f');
    R(c, 14, 21, 3, 3, '#241010'); R(c, 22, 21, 3, 3, '#241010');
    // broca rotativa à frente
    var spin = frame % 2;
    c.save(); c.translate(34, 23); c.rotate(spin ? 0.4 : -0.4);
    c.fillStyle = drill; c.beginPath(); c.moveTo(0, -7); c.lineTo(11, 0); c.lineTo(0, 7); c.lineTo(-4, 0); c.fill();
    c.fillStyle = dk; c.fillRect(-2, -3, 4, 6);
    c.restore();
    R(c, 2, 6, 6, 32, dk); R(c, 32, 6, 6, 32, dk);
    R(c, 4, 4, 3, 3, '#8a95a3'); R(c, 33, 4, 3, 3, '#8a95a3');
    return BQ.outline(cv);
  }

  /* ───────────── Burner (boss 3): entidade flamejante ───────────── */
  function burner(hurt, anger) {
    var cv = BQ.mk(48, 56), c = cv.getContext('2d'), body = hurt ? '#ffffff' : anger ? '#ff3a1a' : '#ff6a2b', dk = hurt ? '#eee' : '#8a1a0a', core = hurt ? '#fff' : '#ffe27a';
    // chamas de fundo
    c.fillStyle = 'rgba(255,140,50,0.35)';
    for (var i = 0; i < 6; i++) { c.beginPath(); c.moveTo(8 + i * 6, 52); c.lineTo(11 + i * 6, 30 - (i % 3) * 4); c.lineTo(14 + i * 6, 52); c.fill(); }
    R(c, 10, 14, 28, 30, body); R(c, 10, 14, 28, 4, core); R(c, 10, 40, 28, 4, dk);
    c.fillStyle = dk; c.beginPath(); c.moveTo(10, 14); c.lineTo(24, 0); c.lineTo(38, 14); c.fill();
    c.fillStyle = core; c.beginPath(); c.moveTo(15, 13); c.lineTo(24, 4); c.lineTo(33, 13); c.fill();
    R(c, 16, 22, 6, 7, '#1a0a06'); R(c, 26, 22, 6, 7, '#1a0a06');
    R(c, 17, 24, 4, 4, hurt ? '#fff' : '#ffe27a'); R(c, 27, 24, 4, 4, hurt ? '#fff' : '#ffe27a');
    R(c, 18, 32, 12, 3, '#1a0a06');
    R(c, 2, 18, 8, 18, dk); R(c, 38, 18, 8, 18, dk);
    R(c, 0, 30, 6, 8, body); R(c, 42, 30, 6, 8, body);
    return BQ.outline(cv);
  }

  Art.krumpie = function (ctx, x, y, s, t, opts) {
    // vilão: figura encapuzada com coroa de espigões e olhos brilhantes (x,y = pés, centro)
    opts = opts || {}; s = s || 1; t = t || 0;
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
    var sway = Math.sin(t / 22) * 1.5;
    ctx.fillStyle = '#120a1e'; ctx.beginPath(); ctx.moveTo(-16, 0); ctx.lineTo(-11, -34 + sway); ctx.lineTo(11, -34 + sway); ctx.lineTo(16, 0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#2a1442'; ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(-10, -32 + sway); ctx.lineTo(0, -32 + sway); ctx.lineTo(-2, 0); ctx.fill();
    ctx.fillStyle = '#120a1e'; ctx.beginPath(); ctx.arc(0, -40 + sway, 10, 0, 7); ctx.fill();
    ctx.fillStyle = '#3a1a5a'; ctx.fillRect(-9, -44 + sway, 18, 5);
    ctx.fillStyle = '#7a2fd0'; for (var i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(i * 6 - 3, -48 + sway); ctx.lineTo(i * 6, -57 + sway - (i === 0 ? 4 : 0)); ctx.lineTo(i * 6 + 3, -48 + sway); ctx.fill(); }
    ctx.fillStyle = '#ff2a4a'; ctx.fillRect(-6, -41 + sway, 4, 3); ctx.fillRect(2, -41 + sway, 4, 3);
    ctx.fillStyle = '#fff'; ctx.fillRect(-5, -41 + sway, 1, 1); ctx.fillRect(3, -41 + sway, 1, 1);
    if (opts.arms) { ctx.fillStyle = '#120a1e'; ctx.fillRect(-22, -30 + sway, 8, 5); ctx.fillRect(14, -30 + sway, 8, 5); }
    ctx.restore();
  };

  Art.light = function (color) {
    if (Art.lightCache[color]) return Art.lightCache[color];
    var cv = BQ.mk(64, 64), c = cv.getContext('2d'), g = c.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, color); g.addColorStop(0.35, color.replace(/[\d.]+\)$/, '0.35)')); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.fillRect(0, 0, 64, 64);
    Art.lightCache[color] = cv; return cv;
  };

  Art.init = function () {
    if (Art.ready) return;
    buildChars(); buildEnemies(); buildTiles(); itemIcons(); Art.buildBoss();
    Object.keys(BQD.POWERS).forEach(function (k) { Art.getPowerIcon(BQD.POWERS[k]); });
    Object.keys(BQD.FUSIONS).forEach(function (k) { Art.getPowerIcon(BQD.FUSIONS[k]); });
    Art.ready = true;
  };
})(BQ.Art);
'use strict';
/* BlockQuest — cenários com parallax (6 camadas) e cenas de história */
(function (Art) {
  var W = BQ.W, H = BQ.H;
  var PAL = {
    dusk:   { sky: ['#1f2657', '#6a3f7c', '#e9705a', '#ffb46a'], far: '#4a3d78', mid: '#352f62', bld: '#1f2140', edge: '#3b3b6a', cloud: '#f2a0a0', cloud2: '#c96a86', sun: '#ffe2a0', win: '#ffd27a', near: '#14162a', winp: 0.10 },
    sunset: { sky: ['#2a2358', '#b04a73', '#ff8a4c', '#ffd27a'], far: '#7a4a86', mid: '#5a3a72', bld: '#2a1d3f', edge: '#5a3a6e', cloud: '#ffd0a0', cloud2: '#f08a70', sun: '#fff0b8', win: '#ffe08a', near: '#1c1228', winp: 0.08 },
    night:  { sky: ['#060a1c', '#111a44', '#242a60', '#3d2f6a'], far: '#1b2050', mid: '#141a3f', bld: '#0d1028', edge: '#262d5e', cloud: '#3a4478', cloud2: '#28305a', sun: '#e8f0ff', win: '#ffd27a', near: '#070914', winp: 0.2 },
    mine:   { sky: ['#050505', '#120c0a', '#231610', '#2e1c12'], far: '#2a1c14', mid: '#1c130d', bld: '#120b07', edge: '#3a2416', cloud: '#5a3a24', cloud2: '#3a2414', sun: '#ffb347', win: '#8fe8ff', near: '#0a0605', winp: 0.05 },
    infernal:{ sky: ['#1a0402', '#3a0a04', '#6a1a08', '#a8340f'], far: '#4a1006', mid: '#330a04', bld: '#200602', edge: '#5a1a08', cloud: '#ff8a3a', cloud2: '#c94a12', sun: '#ffe27a', win: '#ffb347', near: '#160402', winp: 0.0 },
    ice:    { sky: ['#0a1a30', '#1c3a5a', '#3a6a8a', '#8fc8dc'], far: '#2a5878', mid: '#1e4460', bld: '#0f2a3e', edge: '#3a6e8e', cloud: '#eaf6ff', cloud2: '#bfe3f2', sun: '#f0faff', win: '#bfe9ff', near: '#081824', winp: 0.06 },
    castle: { sky: ['#0a0614', '#1e1030', '#3a1a44', '#5a2a4a'], far: '#2a1638', mid: '#1c0f28', bld: '#12081c', edge: '#3a2050', cloud: '#7a4a8a', cloud2: '#4a2860', sun: '#e0c8ff', win: '#8fe8ff', near: '#08050e', winp: 0.14 }
  };
  Art.PAL = PAL;

  function ridge(cv, color, seed, amp, base, hi) {
    var c = cv.getContext('2d'), w = cv.width, h = cv.height;
    for (var x = 0; x < w; x += 4) {
      var n = base + amp * Math.abs(Math.sin(x * 0.011 + seed)) + hi * BQ.hash(Math.floor(x / 8) + seed * 9) + amp * 0.4 * Math.sin(x * 0.031 + seed * 2);
      c.fillStyle = color; c.fillRect(x, h - n, 4, n);
    }
  }
  function caveStrip(p) {
    var cv = BQ.mk(640, 190), c = cv.getContext('2d'), x = 0, i = 0;
    c.fillStyle = p.bld; c.fillRect(0, 60, 640, 130);
    while (x < 640) {
      var w = 34 + Math.floor(BQ.hash(i * 3.3) * 40);
      var h = 40 + Math.floor(BQ.hash(i * 7.7) * 70), y = 190 - h;
      c.fillStyle = p.bld;
      c.beginPath(); c.moveTo(x, 190); c.lineTo(x + 4, y + 10); c.lineTo(x + w * 0.5, y); c.lineTo(x + w - 4, y + 14); c.lineTo(x + w, 190); c.fill();
      c.fillStyle = p.edge; c.fillRect(x + w * 0.5 - 1, y, 1, h);
      if (BQ.hash(i * 5.5) < 0.4) {   // veio de cristal a brilhar
        c.fillStyle = '#6fd8ff'; c.globalAlpha = 0.55;
        c.fillRect(x + w * 0.3, y + h * 0.4, 2, 10); c.fillRect(x + w * 0.6, y + h * 0.5, 2, 7);
        c.globalAlpha = 1;
      }
      if (BQ.hash(i * 6.6) < 0.25) { c.fillStyle = 'rgba(255,140,40,0.5)'; c.fillRect(x + w * 0.4, 186, w * 0.2, 4); }
      x += w - 4; i++;
    }
    return cv;
  }
  function lavaStrip(p) {
    var cv = BQ.mk(640, 190), c = cv.getContext('2d'), x = 0, i = 0;
    c.fillStyle = p.bld; c.fillRect(0, 70, 640, 120);
    while (x < 640) {
      var w = 40 + Math.floor(BQ.hash(i * 3.1) * 44), h = 50 + Math.floor(BQ.hash(i * 8.1) * 80), y = 190 - h;
      c.fillStyle = p.bld;
      c.beginPath(); c.moveTo(x, 190); c.lineTo(x + w * 0.2, y + 20); c.lineTo(x + w * 0.5, y); c.lineTo(x + w * 0.8, y + 24); c.lineTo(x + w, 190); c.fill();
      c.fillStyle = 'rgba(255,110,40,0.5)'; c.fillRect(x + w * 0.45, y + 6, 2, h * 0.5);
      x += w - 6; i++;
    }
    c.fillStyle = 'rgba(255,90,20,0.28)'; c.fillRect(0, 160, 640, 30);
    return cv;
  }
  function buildingsStrip(p, tone) {
    var cv = BQ.mk(640, 190), c = cv.getContext('2d'), x = 0, i = 0;
    while (x < 640) {
      var w = 28 + Math.floor(BQ.hash(i * 3.3) * 28), gap = Math.floor(BQ.hash(i * 5.1) * 6);
      if (640 - (x + w + gap) < 26) w = 640 - x; gap = x + w >= 640 ? 0 : gap;
      var h = 64 + Math.floor(BQ.hash(i * 7.7) * 100), style = Math.floor(BQ.hash(i * 9.9) * 4), y = 190 - h;
      c.fillStyle = p.bld;
      if (style === 0) c.fillRect(x, y, w, h);
      else if (style === 1) { c.fillRect(x, y + 14, w, h - 14); c.fillRect(x + w * 0.4, y, w * 0.6, 14); }
      else if (style === 2) { c.beginPath(); c.moveTo(x, 190); c.lineTo(x, y + 18); c.lineTo(x + w, y); c.lineTo(x + w, 190); c.fill(); }
      else { c.fillRect(x, y + 6, w, h - 6); c.clearRect(x + w * 0.55, y + 6, 5, 6); c.clearRect(x + w * 0.3, y + 6, 3, 3); c.fillRect(x + 4, y - 8, 2, 14); }
      c.fillStyle = p.edge; c.fillRect(x, y + (style === 2 ? 14 : 6), 1, h);
      for (var wy = y + 14; wy < 180; wy += 10) for (var wx = x + 5; wx < x + w - 5; wx += 8) {
        if (BQ.hash(wx * 1.3 + wy * 7.1 + i) < p.winp) { c.fillStyle = p.win; c.fillRect(wx, wy, 3, 4); }
        else if (BQ.hash(wx * 2.1 + wy * 3.7 + i) < 0.5) { c.fillStyle = 'rgba(0,0,0,0.22)'; c.fillRect(wx, wy, 3, 4); }
      }
      if (BQ.hash(i * 2.2) < 0.34) {   // fumo
        var g = c.createLinearGradient(0, y - 60, 0, y); g.addColorStop(0, 'rgba(40,36,56,0)'); g.addColorStop(1, 'rgba(40,36,56,0.55)');
        c.fillStyle = g; c.fillRect(x + w * 0.4, Math.max(0, y - 60), 9, Math.min(60, y));
      }
      x += w + gap; i++;
    }
    return cv;
  }
  function nearStrip(p) {
    var cv = BQ.mk(640, 64), c = cv.getContext('2d'), x = 6, i = 0;
    c.fillStyle = p.near;
    while (x < 620) {
      var k = Math.floor(BQ.hash(i * 4.1) * 5);
      if (k === 0) { c.fillRect(x, 46, 44, 10); c.fillRect(x + 8, 38, 26, 9); c.fillStyle = p.bld; c.fillRect(x + 11, 40, 8, 5); c.fillRect(x + 22, 40, 8, 5); c.fillStyle = p.near; c.beginPath(); c.arc(x + 9, 57, 5, 0, 7); c.arc(x + 35, 57, 5, 0, 7); c.fill(); x += 70; }
      else if (k === 1) { c.fillRect(x, 8, 3, 50); c.fillRect(x, 8, 16, 3); c.fillRect(x + 13, 8, 3, 6); x += 46; }
      else if (k === 2) { c.beginPath(); c.moveTo(x, 58); c.lineTo(x + 14, 36); c.lineTo(x + 24, 46); c.lineTo(x + 40, 30); c.lineTo(x + 58, 58); c.fill(); x += 66; }
      else if (k === 3) { for (var f = 0; f < 4; f++) { c.fillRect(x + f * 8, 40, 6, 18); c.fillRect(x + f * 8 + 2, 36, 2, 4); } x += 44; }
      else { c.fillRect(x, 24, 3, 34); c.fillRect(x - 8, 30, 8, 2); c.fillRect(x + 3, 26, 9, 2); c.fillRect(x - 4, 38, 7, 2); x += 36; }
      i++;
    }
    return cv;
  }
  function caveNear(p) {
    var cv = BQ.mk(640, 64), c = cv.getContext('2d'), x = 4, i = 0;
    c.fillStyle = p.near;
    while (x < 630) {
      var w = 30 + Math.floor(BQ.hash(i * 4.4) * 26);
      c.beginPath(); c.moveTo(x, 64); c.lineTo(x + 3, 30 - (i % 3) * 6); c.lineTo(x + w * 0.5, 14); c.lineTo(x + w - 3, 28 - (i % 4) * 5); c.lineTo(x + w, 64); c.fill();
      if (BQ.hash(i * 3.3) < 0.4) { c.fillStyle = '#4fd8ff'; c.globalAlpha = 0.4; c.fillRect(x + w * 0.45, 20, 2, 8); c.globalAlpha = 1; c.fillStyle = p.near; }
      x += w - 4; i++;
    }
    return cv;
  }
  function infernalNear(p) {
    var cv = BQ.mk(640, 64), c = cv.getContext('2d'), x = 4, i = 0;
    c.fillStyle = p.near;
    while (x < 630) {
      var w = 26 + Math.floor(BQ.hash(i * 4.7) * 30);
      c.beginPath(); c.moveTo(x, 64); c.lineTo(x + 4, 24 - (i % 3) * 5); c.lineTo(x + w * 0.5, 8); c.lineTo(x + w - 4, 22 - (i % 4) * 4); c.lineTo(x + w, 64); c.fill();
      x += w - 5; i++;
    }
    c.fillStyle = 'rgba(255,100,30,0.4)'; c.fillRect(0, 50, 640, 14);
    return cv;
  }
  function iceStrip(p) {
    var cv = BQ.mk(640, 190), c = cv.getContext('2d'), x = 0, i = 0;
    c.fillStyle = p.bld; c.fillRect(0, 90, 640, 100);
    while (x < 640) {
      var w = 40 + Math.floor(BQ.hash(i * 3.1) * 50), h = 40 + Math.floor(BQ.hash(i * 7.3) * 90), y = 190 - h;
      c.fillStyle = p.bld;
      c.beginPath(); c.moveTo(x, 190); c.lineTo(x + w * 0.15, y + 30); c.lineTo(x + w * 0.5, y); c.lineTo(x + w * 0.85, y + 26); c.lineTo(x + w, 190); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.55)';
      c.beginPath(); c.moveTo(x + w * 0.4, y + 8); c.lineTo(x + w * 0.5, y); c.lineTo(x + w * 0.6, y + 10); c.lineTo(x + w * 0.5, y + 20); c.fill();
      x += w - 8; i++;
    }
    return cv;
  }
  function iceNear(p) {
    var cv = BQ.mk(640, 64), c = cv.getContext('2d'), x = 4, i = 0;
    c.fillStyle = p.near;
    while (x < 630) {
      var w = 30 + Math.floor(BQ.hash(i * 4.2) * 30);
      c.beginPath(); c.moveTo(x, 64); c.lineTo(x + 4, 20 - (i % 3) * 5); c.lineTo(x + w * 0.5, 6); c.lineTo(x + w - 4, 18 - (i % 4) * 4); c.lineTo(x + w, 64); c.fill();
      c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(x + w * 0.45, 10, 2, 10); c.fillStyle = p.near;
      x += w - 6; i++;
    }
    return cv;
  }
  function castleStrip(p) {
    var cv = BQ.mk(640, 190), c = cv.getContext('2d'), x = 0, i = 0;
    c.fillStyle = p.bld; c.fillRect(0, 70, 640, 120);
    while (x < 640) {
      var w = 30 + Math.floor(BQ.hash(i * 3.3) * 20), h = 70 + Math.floor(BQ.hash(i * 7.1) * 90), y = 190 - h;
      c.fillStyle = p.bld; c.fillRect(x, y + 10, w, h - 10);
      for (var m = 0; m < w; m += 8) c.fillRect(x + m, y, 5, 10);
      if (BQ.hash(i * 5.5) < 0.5) { c.fillStyle = p.win; c.globalAlpha = 0.55; c.beginPath(); c.moveTo(x + w * 0.5, y + 20); c.lineTo(x + w * 0.5 + 6, y + 32); c.lineTo(x + w * 0.5, y + 44); c.lineTo(x + w * 0.5 - 6, y + 32); c.fill(); c.globalAlpha = 1; c.fillStyle = p.bld; }
      c.fillStyle = p.edge; c.fillRect(x, y + 10, 1, h - 10);
      x += w + 4; i++;
    }
    return cv;
  }
  function castleNear(p) {
    var cv = BQ.mk(640, 64), c = cv.getContext('2d'), x = 4, i = 0;
    c.fillStyle = p.near;
    while (x < 630) {
      var w = 20 + Math.floor(BQ.hash(i * 4.4) * 14);
      c.fillRect(x, 10, w, 54); for (var m = 0; m < w; m += 7) c.fillRect(x + m, 6, 4, 8);
      x += w + 14; i++;
    }
    return cv;
  }

  Art.makeBG = function (tone) {
    var p = PAL[tone] || PAL.dusk, bg = { tone: tone, p: p };
    var sky = BQ.mk(W, H), c = sky.getContext('2d'), g = c.createLinearGradient(0, 0, 0, 230);
    g.addColorStop(0, p.sky[0]); g.addColorStop(0.45, p.sky[1]); g.addColorStop(0.8, p.sky[2]); g.addColorStop(1, p.sky[3]);
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    bg.stars = [];
    if (tone === 'night') {
      for (var i = 0; i < 70; i++) { var sx = Math.floor(BQ.hash(i * 1.7) * W), sy = Math.floor(BQ.hash(i * 2.9) * 150); c.fillStyle = i % 5 ? '#c8d4ff' : '#fff'; c.fillRect(sx, sy, 1, 1); if (i % 9 === 0) bg.stars.push([sx, sy]); }
      c.fillStyle = p.sun; c.beginPath(); c.arc(370, 58, 20, 0, 7); c.fill();
      c.fillStyle = p.sky[1]; c.beginPath(); c.arc(378, 52, 17, 0, 7); c.fill();
    } else if (tone === 'mine') {
      c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(0, 0, W, H);
      for (var m = 0; m < 26; m++) { var mx = Math.floor(BQ.hash(m * 2.1) * W), my = Math.floor(BQ.hash(m * 3.3) * 130); c.fillStyle = '#5fd8ff'; c.globalAlpha = 0.3 + BQ.hash(m) * 0.4; c.fillRect(mx, my, 1, 1); }
      c.globalAlpha = 1;
    } else if (tone === 'infernal') {
      // sem sol; brilho difuso de lava ao fundo
      c.fillStyle = 'rgba(255,120,40,0.18)'; c.fillRect(0, 120, W, 60);
    } else if (tone === 'ice') {
      for (var s1 = 0; s1 < 40; s1++) { var sx1 = Math.floor(BQ.hash(s1 * 1.9) * W), sy1 = Math.floor(BQ.hash(s1 * 2.7) * 180); c.fillStyle = '#fff'; c.globalAlpha = 0.5 + BQ.hash(s1) * 0.4; c.fillRect(sx1, sy1, 1, 1); }
      c.globalAlpha = 1;
      c.fillStyle = 'rgba(255,255,255,0.3)'; c.beginPath(); c.arc(360, 60, 22, 0, 7); c.fill();
      c.fillStyle = p.sun; c.beginPath(); c.arc(360, 60, 14, 0, 7); c.fill();
    } else if (tone === 'castle') {
      for (var s2 = 0; s2 < 34; s2++) { var sx2 = Math.floor(BQ.hash(s2 * 1.6) * W), sy2 = Math.floor(BQ.hash(s2 * 2.4) * 140); c.fillStyle = '#e8d8ff'; c.globalAlpha = 0.3 + BQ.hash(s2) * 0.4; c.fillRect(sx2, sy2, 1, 1); }
      c.globalAlpha = 1;
      c.fillStyle = p.sun; c.globalAlpha = 0.5; c.beginPath(); c.arc(90, 50, 16, 0, 7); c.fill(); c.globalAlpha = 1;
    } else {
      c.fillStyle = 'rgba(255,240,190,0.25)'; c.beginPath(); c.arc(340, 172, 46, 0, 7); c.fill();
      c.fillStyle = p.sun; c.beginPath(); c.arc(340, 172, 28, 0, 7); c.fill();
    }
    bg.sky = sky;
    var cl = BQ.mk(640, 90), cc = cl.getContext('2d');
    if (tone === 'mine') {
      for (var k1 = 0; k1 < 20; k1++) { var cx1 = k1 * 33 + BQ.hash(k1 * 3) * 20, cy1 = 6 + BQ.hash(k1 * 5) * 70; cc.fillStyle = '#ffb347'; cc.globalAlpha = 0.35 + BQ.hash(k1) * 0.3; cc.fillRect(cx1, cy1, 1.5, 1.5); }
      cc.globalAlpha = 1;
    } else if (tone === 'infernal') {
      for (var k2 = 0; k2 < 24; k2++) { var cx2 = k2 * 27 + BQ.hash(k2 * 3) * 20, cy2 = 4 + BQ.hash(k2 * 5) * 80; cc.fillStyle = BQ.pick ? (k2 % 2 ? '#ff8a3a' : '#ffd23f') : '#ff8a3a'; cc.globalAlpha = 0.4 + BQ.hash(k2) * 0.35; cc.fillRect(cx2, cy2, 2, 2); }
      cc.globalAlpha = 1;
    } else if (tone === 'ice') {
      for (var k3 = 0; k3 < 26; k3++) { var cx3 = k3 * 25 + BQ.hash(k3 * 3) * 18, cy3 = 4 + BQ.hash(k3 * 5) * 80; cc.fillStyle = '#ffffff'; cc.globalAlpha = 0.4 + BQ.hash(k3) * 0.4; cc.fillRect(cx3, cy3, 2, 2); }
      cc.globalAlpha = 1;
    } else if (tone === 'castle') {
      for (var k4 = 0; k4 < 8; k4++) {
        var cx4 = k4 * 84 + BQ.hash(k4 * 3) * 30, cy4 = 8 + BQ.hash(k4 * 5) * 46, cw4 = 34 + BQ.hash(k4 * 7) * 26;
        cc.fillStyle = p.cloud2; cc.fillRect(cx4, cy4 + 6, cw4, 6); cc.fillStyle = p.cloud; cc.fillRect(cx4 + 4, cy4 + 1, cw4 - 12, 4);
      }
    } else {
      for (var k = 0; k < 9; k++) {
        var cx = k * 74 + BQ.hash(k * 3) * 30, cy = 10 + BQ.hash(k * 5) * 50, cw = 30 + BQ.hash(k * 7) * 30;
        cc.fillStyle = p.cloud2; cc.fillRect(cx, cy + 6, cw, 6); cc.fillRect(cx + 6, cy + 2, cw - 14, 6);
        cc.fillStyle = p.cloud; cc.fillRect(cx + 4, cy + 1, cw - 12, 4); cc.fillRect(cx + 10, cy - 2, cw - 24, 4);
      }
    }
    bg.clouds = cl;
    bg.far = BQ.mk(640, 120); ridge(bg.far, p.far, 1.3, 36, 30, 12);
    bg.mid = BQ.mk(640, 100); ridge(bg.mid, p.mid, 4.1, 26, 24, 10);
    bg.bld = tone === 'mine' ? caveStrip(p) : tone === 'infernal' ? lavaStrip(p) : tone === 'ice' ? iceStrip(p) : tone === 'castle' ? castleStrip(p) : buildingsStrip(p, tone);
    bg.near = tone === 'mine' ? caveNear(p) : tone === 'infernal' ? infernalNear(p) : tone === 'ice' ? iceNear(p) : tone === 'castle' ? castleNear(p) : nearStrip(p);
    return bg;
  };

  function strip(ctx, img, off, y) {
    var w = img.width, x = -(((off % w) + w) % w);
    ctx.drawImage(img, x, y); if (x + w < W) ctx.drawImage(img, x + w, y);
  }
  Art.drawBG = function (ctx, bg, cam, t, quality) {
    ctx.drawImage(bg.sky, 0, 0);
    if (bg.tone === 'night' && quality !== 'low') { ctx.fillStyle = '#fff'; for (var i = 0; i < bg.stars.length; i++) { if (((t >> 4) + i) % 5 !== 0) ctx.fillRect(bg.stars[i][0], bg.stars[i][1], 2, 2); } }
    if (quality !== 'low') strip(ctx, bg.clouds, cam * 0.08 + t * 0.12, 16);
    strip(ctx, bg.far, cam * 0.16, 100);
    if (quality !== 'low') strip(ctx, bg.mid, cam * 0.26, 124);
    strip(ctx, bg.bld, cam * 0.5, 42);
  };
  Art.drawNear = function (ctx, bg, cam) { strip(ctx, bg.near, cam * 0.82, 166); };

  /* ───────────── cenas ───────────── */
  var S = Art.scenes = {};
  var bgCache = {};
  function cbg(tone) { return bgCache[tone] || (bgCache[tone] = Art.makeBG(tone)); }
  function fill(ctx, col) { ctx.fillStyle = col; ctx.fillRect(0, 0, W, H); }
  function vgrad(ctx, cols) { var g = ctx.createLinearGradient(0, 0, 0, H); cols.forEach(function (c, i) { g.addColorStop(i / (cols.length - 1), c); }); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }
  function glow(ctx, x, y, r, col, a) { var g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.globalAlpha = a == null ? 1 : a; ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); ctx.globalAlpha = 1; }
  function stars(ctx, t, n) { ctx.fillStyle = '#fff'; for (var i = 0; i < (n || 60); i++) { var x = BQ.hash(i * 1.7) * W, y = BQ.hash(i * 2.9) * H; if (((t >> 3) + i) % 6) ctx.fillRect(x | 0, y | 0, 1 + (i % 4 === 0 ? 1 : 0), 1 + (i % 4 === 0 ? 1 : 0)); } }
  function blockMaster(ctx, x, y, s, t, alpha) {
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.globalAlpha = alpha == null ? 1 : alpha;
    var dark = '#0e6a48', mid = '#1fbf7f', lt = '#7cf5c0';
    ctx.fillStyle = '#062a1e'; ctx.fillRect(-17, -13, 34, 34);
    ctx.fillStyle = mid; ctx.fillRect(-16, -12, 32, 32); ctx.fillStyle = lt; ctx.fillRect(-16, -12, 32, 3); ctx.fillRect(-16, -12, 3, 32);
    ctx.fillStyle = dark; ctx.fillRect(13, -12, 3, 32); ctx.fillRect(-16, 17, 32, 3);
    ctx.fillStyle = dark; ctx.fillRect(-9, -5, 18, 18); ctx.fillStyle = mid; ctx.fillRect(-8, -4, 16, 16);
    ctx.fillStyle = '#eafff5'; ctx.beginPath(); ctx.moveTo(0, -3); ctx.lineTo(6, 4); ctx.lineTo(0, 11); ctx.lineTo(-6, 4); ctx.fill();
    ctx.fillStyle = lt; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(3, 4); ctx.lineTo(0, 8); ctx.lineTo(-3, 4); ctx.fill();
    ctx.fillStyle = '#ffd23f'; ctx.fillRect(-9, -17, 18, 4); ctx.fillRect(-9, -22, 4, 6); ctx.fillRect(-2, -25, 4, 9); ctx.fillRect(5, -22, 4, 6);
    ctx.restore();
  }
  function shardShape(ctx, x, y, s, rot, col) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
    ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, -12); ctx.lineTo(7, -2); ctx.lineTo(4, 12); ctx.lineTo(-4, 12); ctx.lineTo(-7, -2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.65)'; ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(3, -2); ctx.lineTo(0, 8); ctx.lineTo(-3, -2); ctx.fill();
    ctx.restore();
  }
  function flame(ctx, x, y, s, t, seed) {
    var h = (10 + Math.sin(t / 3 + seed) * 3) * s;
    ctx.fillStyle = '#ff5a1f'; ctx.beginPath(); ctx.moveTo(x - 4 * s, y); ctx.quadraticCurveTo(x - 5 * s, y - h * 0.6, x, y - h); ctx.quadraticCurveTo(x + 5 * s, y - h * 0.6, x + 4 * s, y); ctx.fill();
    ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.moveTo(x - 2 * s, y); ctx.quadraticCurveTo(x - 2.5 * s, y - h * 0.4, x, y - h * 0.6); ctx.quadraticCurveTo(x + 2.5 * s, y - h * 0.4, x + 2 * s, y); ctx.fill();
  }
  function figure(ctx, x, y, s, col, cape) {   // silhueta de herói
    ctx.fillStyle = col; ctx.fillRect(x - 3 * s, y - 14 * s, 6 * s, 8 * s); ctx.fillRect(x - 4 * s, y - 20 * s, 8 * s, 6 * s);
    ctx.fillRect(x - 3 * s, y - 6 * s, 2 * s, 6 * s); ctx.fillRect(x + 1 * s, y - 6 * s, 2 * s, 6 * s);
    if (cape) { ctx.fillStyle = cape; ctx.beginPath(); ctx.moveTo(x - 3 * s, y - 14 * s); ctx.lineTo(x - 9 * s, y - 2 * s); ctx.lineTo(x - 3 * s, y - 4 * s); ctx.fill(); }
  }
  function sprite(ctx, img, x, y, s, flip) {
    ctx.save(); ctx.imageSmoothingEnabled = false; ctx.translate(x, y); if (flip) ctx.scale(-1, 1);
    ctx.drawImage(img, -img.width * s / 2, -img.height * s, img.width * s, img.height * s); ctx.restore();
  }
  function ground(ctx, y, col) { ctx.fillStyle = col || '#161826'; ctx.fillRect(0, y, W, H - y); ctx.fillStyle = 'rgba(255,255,255,0.08)'; ctx.fillRect(0, y, W, 1); }

  S.black = function (ctx) { fill(ctx, '#000'); };
  S.block = function (ctx, t) {
    fill(ctx, '#03040a'); stars(ctx, t, 50);
    var fy = 110 + Math.sin(t / 30) * 6; glow(ctx, 240, fy, 120 + Math.sin(t / 20) * 10, 'rgba(60,255,170,0.55)');
    for (var i = 0; i < 14; i++) { var a = t / 40 + i * 0.45, r = 60 + (i % 3) * 14; ctx.fillStyle = i % 2 ? '#9dffd2' : '#ffe27a'; ctx.fillRect(240 + Math.cos(a) * r, fy + Math.sin(a) * r * 0.6, 2, 2); }
    blockMaster(ctx, 240, fy, 2.2, t, Math.min(1, t / 40));
  };
  S.theft = function (ctx, t) {
    vgrad(ctx, ['#0a0416', '#2a0f3a', '#4a1a4a']); stars(ctx, t, 30); ground(ctx, 212, '#120a1c');
    ctx.fillStyle = '#2a2140'; ctx.fillRect(200, 170, 80, 42); ctx.fillStyle = '#3c3060'; ctx.fillRect(196, 164, 88, 8);
    var kx = t < 80 ? 540 - t * 3.6 : 252, bx = 240, by = 132 + Math.sin(t / 20) * 3;
    if (t > 96) { var p = Math.min(1, (t - 96) / 40); bx = BQ.lerp(240, kx - 8, p); by = BQ.lerp(132, 150, p) - Math.sin(p * Math.PI) * 30; }
    glow(ctx, bx, by, 90, 'rgba(60,255,170,0.5)', 0.8);
    blockMaster(ctx, bx, by, t > 96 ? 1.2 : 1.8, t);
    Art.krumpie(ctx, kx + 30, 212, 2.2, t, { arms: true });
    if (t > 96 && t < 112) { ctx.fillStyle = 'rgba(255,255,255,' + (0.7 - (t - 96) / 30) + ')'; ctx.fillRect(0, 0, W, H); }
  };
  S.ruin = function (ctx, t) {
    vgrad(ctx, ['#1a0508', '#5a1010', '#c2431a']); ground(ctx, 220, '#170a0a');
    for (var i = 0; i < 9; i++) {
      var x = i * 58 - 10, h = 60 + BQ.hash(i * 3.3) * 90, tilt = (BQ.hash(i * 1.1) - 0.5) * 0.25 * Math.min(1, t / 100);
      ctx.save(); ctx.translate(x + 24, 220); ctx.rotate(tilt); ctx.fillStyle = '#1b0e14'; ctx.fillRect(-24, -h, 48, h);
      ctx.fillStyle = '#ffb14a'; for (var w = 0; w < 6; w++) if (BQ.hash(i * 9 + w) < 0.4) ctx.fillRect(-16 + (w % 3) * 12, -h + 12 + Math.floor(w / 3) * 14, 5, 6);
      ctx.restore();
      flame(ctx, x + 24, 220 - h * 0.9, 1.6, t, i); flame(ctx, x + 12, 220, 1.2, t, i + 3);
    }
    for (var k = 0; k < 4; k++) { var px = 60 + k * 120, ph = 40 + Math.min(200, t * 1.2); var g = ctx.createLinearGradient(0, 220 - ph, 0, 220); g.addColorStop(0, 'rgba(200,60,255,0)'); g.addColorStop(1, 'rgba(200,60,255,0.6)'); ctx.fillStyle = g; ctx.fillRect(px, 220 - ph, 6, ph); }
    for (var d = 0; d < 14; d++) { var dx = BQ.hash(d * 2.3) * W, dy = ((t * (1 + BQ.hash(d) * 2) + d * 40) % 260); ctx.fillStyle = '#3a2a2a'; ctx.fillRect(dx, dy, 3, 3); }
  };
  S.heroes = function (ctx, t) {
    vgrad(ctx, ['#05060f', '#0c1230', '#1a2450']); stars(ctx, t, 40); ground(ctx, 214, '#0b0f24');
    var cols = ['#e0b040', '#5aa0e0', '#e05a7a', '#7ae05a', '#b07ae0'];
    for (var i = 0; i < 5; i++) figure(ctx, 130 + i * 55, 214, 1.7, cols[i], cols[(i + 2) % 5]);
    var p = Math.min(1, t / 130);
    if (t < 140) { glow(ctx, 240, 100, 30 + p * 160, 'rgba(255,255,255,0.85)', 0.5 + p * 0.5); blockMaster(ctx, 240, 118 - p * 6, 1.6, t, 1 - Math.max(0, (t - 120) / 20)); }
    else { var q = (t - 140); glow(ctx, 240, 100, 220 - q, 'rgba(255,255,255,0.8)', Math.max(0, 1 - q / 80));
      for (var s = 0; s < 12; s++) { var a = s * 0.52; shardShape(ctx, 240 + Math.cos(a) * q * 2.2, 100 + Math.sin(a) * q * 1.6 + q * q * 0.01, 0.7, a + q / 12, '#5fe0a0'); } }
    if (t > 118 && t < 150) { ctx.fillStyle = 'rgba(255,255,255,' + Math.min(0.9, (t - 118) / 20) * (1 - (t - 118) / 40) + ')'; ctx.fillRect(0, 0, W, H); }
  };
  S.fragments = function (ctx, t) {
    vgrad(ctx, ['#02030a', '#0a0f2a', '#101a40']); stars(ctx, t, 80);
    var cols = ['#5fe0a0', '#e0a05f', '#ff5a3a', '#8fe8ff', '#c78aff'], dirs = [[-1, -0.4], [-0.5, -0.9], [0.3, -1], [0.9, -0.5], [1, 0.3]];
    for (var i = 0; i < 5; i++) {
      var p = Math.min(1, t / 170), e = 1 - Math.pow(1 - p, 2), x = 240 + dirs[i][0] * 210 * e, y = 130 + dirs[i][1] * 120 * e;
      for (var tr = 1; tr <= 8; tr++) { var pe = Math.max(0, e - tr * 0.03); ctx.globalAlpha = 0.5 - tr * 0.06; ctx.fillStyle = cols[i]; ctx.fillRect(240 + dirs[i][0] * 210 * pe, 130 + dirs[i][1] * 120 * pe, 4, 4); }
      ctx.globalAlpha = 1; glow(ctx, x, y, 34, cols[i], 0.55); shardShape(ctx, x, y, 1.2, t / 15 + i, cols[i]);
    }
  };
  function hillBG(ctx, t) {
    Art.drawBG(ctx, cbg('sunset'), 0, t, 'medium'); ground(ctx, 214, '#1f1a2e'); ctx.fillStyle = '#332a48'; ctx.fillRect(0, 214, W, 3);
    ctx.fillStyle = '#20102f'; ctx.fillRect(360, 150, 90, 66); ctx.fillRect(352, 130, 16, 86); ctx.fillRect(442, 130, 16, 86); ctx.fillRect(388, 110, 30, 40);
    ctx.beginPath(); ctx.moveTo(350, 130); ctx.lineTo(360, 108); ctx.lineTo(370, 130); ctx.moveTo(440, 130); ctx.lineTo(450, 108); ctx.lineTo(460, 130); ctx.moveTo(386, 110); ctx.lineTo(403, 84); ctx.lineTo(420, 110); ctx.fill();
    ctx.fillStyle = '#2fe098'; ctx.fillRect(398, 96, 10, 10); glow(ctx, 403, 100, 50, 'rgba(60,255,170,0.6)', 0.7); ctx.fillStyle = '#ff2a4a'; ctx.fillRect(374, 160, 3, 3); ctx.fillRect(430, 160, 3, 3);
  }
  S.bob = function (ctx, t) { hillBG(ctx, t); sprite(ctx, Art.chars.bob['idle' + ((t >> 5) & 1)], 150, 214, 3.4, false); };
  S.title = function (ctx, t) { hillBG(ctx, t); sprite(ctx, Art.chars.bob['idle' + ((t >> 5) & 1)], 120, 214, 3, false); };
  S.cityruin = function (ctx, t) { Art.drawBG(ctx, cbg('dusk'), t * 0.6, t, 'medium'); ground(ctx, 214, '#22252f'); Art.drawNear(ctx, cbg('dusk'), t * 0.6); ground(ctx, 218, '#1b1e26'); ctx.fillStyle = '#3b414d'; ctx.fillRect(0, 218, W, 3); };
  S.cityzombies = function (ctx, t) {
    S.cityruin(ctx, t + 200);
    for (var i = 0; i < 4; i++) { var x = ((t * (0.5 + i * 0.12) + i * 140) % 640) - 60; sprite(ctx, Art.enemy.zombie[((t >> 4) + i) % 2], x, 244, 3, false); }
  };
  S.goal1 = function (ctx, t) {
    S.cityruin(ctx, t + 300);
    var y = 100 + Math.sin(t / 20) * 6; glow(ctx, 300, y, 90, 'rgba(60,255,170,0.7)', 0.8);
    var g = ctx.createLinearGradient(0, 0, 0, 218); g.addColorStop(0, 'rgba(120,255,200,0)'); g.addColorStop(1, 'rgba(120,255,200,0.35)'); ctx.fillStyle = g; ctx.fillRect(292, 0, 16, 218);
    shardShape(ctx, 300, y, 2, t / 30, '#5fe0a0');
  };
  S.fragfound = function (ctx, t) {
    vgrad(ctx, ['#02100c', '#062a1e', '#0a4a34']); stars(ctx, t, 50);
    var col = Art.fragColor || '#5fe0a0';
    for (var r = 0; r < 12; r++) { ctx.save(); ctx.translate(240, 120); ctx.rotate(r * 0.52 + t / 200); ctx.fillStyle = 'rgba(120,255,200,0.12)'; ctx.fillRect(0, -5, 220, 10); ctx.restore(); }
    glow(ctx, 240, 120, 110, col, 0.9); shardShape(ctx, 240, 118 + Math.sin(t / 22) * 5, 3.4, Math.sin(t / 40) * 0.3, col);
    for (var i = 0; i < 16; i++) { var a = t / 30 + i * 0.4, rr = 50 + (i % 4) * 14; ctx.fillStyle = '#d9fff0'; ctx.fillRect(240 + Math.cos(a) * rr, 120 + Math.sin(a) * rr * 0.7, 2, 2); }
  };
  S.mine = function (ctx, t) {
    fill(ctx, '#140d0a'); var g = ctx.createRadialGradient(240, 120, 10, 240, 120, 300); g.addColorStop(0, '#3a261a'); g.addColorStop(1, '#0a0605'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#2a1a12'; for (var i = 0; i < 8; i++) { ctx.fillRect(i * 64 - (t % 64) * 0.3, 0, 12, 200); ctx.fillRect(i * 64 - 20, 40, 76, 8); }
    ground(ctx, 214, '#1a100c'); ctx.fillStyle = '#7a5a3a'; ctx.fillRect(0, 216, W, 3); for (var s = 0; s < 14; s++) ctx.fillRect(s * 36 - (t * 1.4 % 36), 220, 22, 4);
    var cols = ['#ff7a3a', '#3affb0', '#7a8aff'];
    for (var c = 0; c < 9; c++) { var cx = (c * 61 + 20) % W, cy = 170 + (c % 3) * 14; glow(ctx, cx, cy, 30 + Math.sin(t / 20 + c) * 4, cols[c % 3], 0.5); shardShape(ctx, cx, cy, 0.7, 0.2 * c, cols[c % 3]); }
    var bx = Math.min(180, -40 + t * 1.2); sprite(ctx, Art.chars.bob['run' + ((t >> 3) & 3)], bx, 216, 3.4, false);
    glow(ctx, bx + 24, 170, 70, 'rgba(255,200,120,0.6)', 0.5);
  };
  S.soon = function (ctx, t) {
    vgrad(ctx, ['#05060f', '#0c1230']); stars(ctx, t, 50);
    var icons = ['⛏️', '🔥', '🍦', '🏰'];
    ctx.font = '40px ' + BQ.FONT; ctx.textAlign = 'center'; ctx.globalAlpha = 0.6; for (var i = 0; i < 4; i++) ctx.fillText(icons[i], 90 + i * 100, 130 + Math.sin(t / 25 + i) * 6); ctx.globalAlpha = 1;
    ctx.fillStyle = '#fff'; ctx.fillText('🔒', 240, 190);
  };
  S.mineDeep = function (ctx, t) {
    vgrad(ctx, ['#050302', '#1a0f08', '#2e1c10']); ground(ctx, 214, '#0d0805');
    for (var i = 0; i < 8; i++) { var x = i * 62 - 8, h = 50 + BQ.hash(i * 3) * 90; ctx.fillStyle = '#120b07'; ctx.beginPath(); ctx.moveTo(x, 214); ctx.lineTo(x + 6, 214 - h); ctx.lineTo(x + 30, 214 - h * 0.6); ctx.lineTo(x + 54, 214); ctx.fill(); }
    for (var k = 0; k < 14; k++) { var cx = 20 + k * 33 + BQ.hash(k * 4) * 14, cy = 120 + BQ.hash(k * 2) * 90; glow(ctx, cx, cy, 12 + Math.sin(t / 20 + k) * 3, '#5fd8ff', 0.5); shardShape(ctx, cx, cy, 0.6, k, '#8fe8ff'); }
  };
  S.mineDemons = function (ctx, t) {
    S.mineDeep(ctx, t + 200);
    for (var i = 0; i < 3; i++) { var x = ((t * (0.5 + i * 0.15) + i * 150) % 640) - 60; sprite(ctx, Art.enemy.fire_demon[((t >> 4) + i) % 2], x, 220, 3, false); flame(ctx, x, 220, 1.6, t, i); }
  };
  S.goalMine = function (ctx, t) {
    S.mineDeep(ctx, t + 300);
    var y = 100 + Math.sin(t / 20) * 6; glow(ctx, 300, y, 90, 'rgba(200,150,255,0.7)', 0.8);
    shardShape(ctx, 300, y, 2, t / 30, '#e0a05f');
  };
  S.infernoGate = function (ctx, t) {
    vgrad(ctx, ['#1a0402', '#3a0a04', '#6a1a08']); ground(ctx, 216, '#160402');
    for (var i = 0; i < 7; i++) { var x = i * 70 - 10; flame(ctx, x + 20, 216, 2.2, t, i); flame(ctx, x + 40, 216, 1.6, t, i + 4); }
    ctx.fillStyle = 'rgba(255,90,20,0.3)'; ctx.fillRect(0, 190, W, 26);
    for (var k = 0; k < 10; k++) { var dx = BQ.hash(k * 2.3) * W, dy = ((t * (1 + BQ.hash(k) * 2) + k * 40) % 200); ctx.fillStyle = '#ffb347'; ctx.globalAlpha = 0.5; ctx.fillRect(dx, dy, 2, 2); ctx.globalAlpha = 1; }
  };
  S.infernoWitches = function (ctx, t) {
    S.infernoGate(ctx, t + 200);
    for (var i = 0; i < 3; i++) { var x = ((t * (0.4 + i * 0.1) + i * 160) % 640) - 60; sprite(ctx, Art.enemy.witch[((t >> 5) + i) % 2], x, 216, 3, false); }
  };
  S.goalInferno = function (ctx, t) {
    S.infernoGate(ctx, t + 300);
    var y = 100 + Math.sin(t / 20) * 6; glow(ctx, 300, y, 90, 'rgba(255,90,60,0.8)', 0.85);
    shardShape(ctx, 300, y, 2, t / 30, '#ff5a3a');
  };
  function iceBG(ctx, t) {
    Art.drawBG(ctx, cbg('ice'), t * 0.4, t, 'medium'); ground(ctx, 216, '#0d2436'); ctx.fillStyle = '#1a3a52'; ctx.fillRect(0, 216, W, 3);
    for (var i = 0; i < 30; i++) { var sx = (BQ.hash(i * 3.1) * W + t * (0.3 + BQ.hash(i) * 0.6)) % W, sy = (BQ.hash(i * 5.3) * H + t * (0.5 + BQ.hash(i * 2) * 0.5)) % H; ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.fillRect(sx, sy, 2, 2); }
  }
  S.iceStorm = function (ctx, t) { iceBG(ctx, t); ctx.fillStyle = 'rgba(220,240,255,0.18)'; ctx.fillRect(0, 0, W, H); };
  S.iceAnimals = function (ctx, t) {
    S.iceStorm(ctx, t + 200);
    for (var i = 0; i < 3; i++) { var x = ((t * (0.7 + i * 0.2) + i * 140) % 640) - 60; sprite(ctx, Art.enemy.ice_beast[((t >> 3) + i) % 2], x, 218, 3, false); }
  };
  S.goalIce = function (ctx, t) {
    iceBG(ctx, t + 300);
    var y = 100 + Math.sin(t / 20) * 6; glow(ctx, 300, y, 90, 'rgba(160,220,255,0.8)', 0.85);
    shardShape(ctx, 300, y, 2, t / 30, '#8fe8ff');
  };
  function castleBG(ctx, t) {
    Art.drawBG(ctx, cbg('castle'), t * 0.4, t, 'medium'); ground(ctx, 216, '#160a20'); ctx.fillStyle = '#2a1638'; ctx.fillRect(0, 216, W, 3);
  }
  S.castleFar = function (ctx, t) {
    castleBG(ctx, t);
    var p = Math.min(1, t / 160);
    ctx.save(); ctx.translate(240 + (1 - p) * 40, 140); ctx.scale(1 + p * 0.6, 1 + p * 0.6);
    ctx.fillStyle = '#241238'; ctx.fillRect(-70, -10, 140, 90); ctx.fillRect(-90, -40, 26, 120); ctx.fillRect(64, -40, 26, 120); ctx.fillRect(-20, -60, 40, 60);
    ctx.fillStyle = '#3a2050'; for (var i = -3; i <= 3; i++) ctx.fillRect(i * 20 - 6, -12, 12, 6);
    ctx.fillStyle = '#8fe8ff'; ctx.globalAlpha = 0.6; ctx.fillRect(-6, -30, 12, 18); ctx.globalAlpha = 1;
    ctx.restore();
  };
  S.krumpieReveal = function (ctx, t) {
    castleBG(ctx, t + 400);
    glow(ctx, 240, 130, 90, 'rgba(120,50,180,0.6)', 0.7);
    Art.krumpie(ctx, 240, 190, 2.6, t, { arms: t > 60 });
  };
  S.goalCastle = function (ctx, t) {
    castleBG(ctx, t + 500);
    var y = 100 + Math.sin(t / 20) * 6; glow(ctx, 300, y, 90, 'rgba(200,150,255,0.8)', 0.85);
    shardShape(ctx, 300, y, 2, t / 30, '#c78aff');
  };
  /* ───────────── final ───────────── */
  S.shardsGather = function (ctx, t) {
    vgrad(ctx, ['#02100c', '#062a1e', '#0a4a34']); stars(ctx, t, 60);
    var cols = ['#5fe0a0', '#e0a05f', '#ff5a3a', '#8fe8ff'], dirs = [[-1, -0.4], [-0.4, -0.9], [0.4, -0.9], [1, -0.3]];
    var p = Math.min(1, t / 180), e = Math.pow(p, 0.6);
    for (var i = 0; i < 4; i++) {
      var x = 240 + dirs[i][0] * 160 * (1 - e), y = 130 + dirs[i][1] * 90 * (1 - e);
      glow(ctx, x, y, 26, cols[i], 0.6); shardShape(ctx, x, y, 1, t / 20 + i, cols[i]);
    }
    if (p > 0.7) glow(ctx, 240, 120, (p - 0.7) * 300, '#fff', (p - 0.7) * 2);
  };
  S.blockRebuild = function (ctx, t) {
    vgrad(ctx, ['#02100c', '#062a1e', '#0a4a34']); stars(ctx, t, 60);
    var p = Math.min(1, t / 200);
    glow(ctx, 240, 120, 60 + p * 60, 'rgba(120,255,190,0.7)', 0.8);
    blockMaster(ctx, 240, 120, 1 + p * 1.4, t, Math.min(1, p * 2));
    if (p > 0.5) { ctx.fillStyle = '#fff'; ctx.globalAlpha = (p - 0.5); for (var i = 0; i < 20; i++) { var a = i * 0.31 + t / 20, r = 40 + (i % 5) * 12; ctx.fillRect(240 + Math.cos(a) * r, 120 + Math.sin(a) * r * 0.7, 2, 2); } ctx.globalAlpha = 1; }
  };
  S.kingdomHeal = function (ctx, t) {
    Art.drawBG(ctx, cbg('dusk'), t * 0.5, t, 'medium'); ground(ctx, 214, '#22252f'); Art.drawNear(ctx, cbg('dusk'), t * 0.5);
    var p = Math.min(1, t / 220);
    ctx.fillStyle = 'rgba(160,255,200,' + (0.25 * p) + ')'; ctx.fillRect(0, 0, W, H);
    glow(ctx, 240, 90, 40 + p * 50, 'rgba(160,255,200,0.6)', 0.6);
  };
  S.heroesLineup = function (ctx, t) {
    Art.drawBG(ctx, cbg('sunset'), 0, t, 'medium'); ground(ctx, 214, '#1f1a2e'); ctx.fillStyle = '#332a48'; ctx.fillRect(0, 214, W, 3);
    var order = ['bob', 'karen', 'ze', 'r26', 'funny', 'dj'], p = Math.min(1, t / 60);
    for (var i = 0; i < order.length; i++) {
      var set = Art.chars[order[i]]; if (!set) continue;
      var x = 60 + i * 62 * p + (1 - p) * (60 + i * 20);
      sprite(ctx, set['idle' + ((t >> 5) % 2)], x, 214, 2.6, false);
    }
  };
  S.victoryTitle = function (ctx, t) {
    S.heroesLineup(ctx, t + 60);
    ctx.fillStyle = 'rgba(4,10,8,0.5)'; ctx.fillRect(0, 60, W, 90);
    BQ.txt(ctx, 'BLOCKQUEST', W / 2, 100, 22, '#ffe27a', 'center');
    BQ.txt(ctx, 'REINO ESMERALDA SALVO!', W / 2, 126, 14, '#8effa0', 'center');
  };
  Art.sceneBG = cbg;
})(BQ.Art);
'use strict';
/* BlockQuest — ParticleSystem (com pool), Camera e CollisionSystem */

/* ───────────── Partículas ───────────── */
BQ.Particles = function (game) {
  this.game = game; this.max = 260; this.list = [];
  for (var i = 0; i < this.max; i++) this.list.push({ on: false });
  this.texts = [];
  for (i = 0; i < 24; i++) this.texts.push({ on: false });
  this.cursor = 0;
};
BQ.Particles.prototype.cap = function () {
  var q = this.game.save.data.settings.quality;
  return q === 'low' ? 70 : q === 'medium' ? 160 : this.max;
};
BQ.Particles.prototype.spawn = function (x, y, vx, vy, life, size, color, grav, kind, fade) {
  var l = this.list, n = this.cap();
  for (var k = 0; k < n; k++) {
    var i = (this.cursor + k) % n, p = l[i];
    if (!p.on) {
      p.on = true; p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = life; p.max = life; p.size = size; p.color = color;
      p.grav = grav || 0; p.kind = kind || 0; p.fade = fade !== false; this.cursor = i + 1; return p;
    }
  }
  return null;
};
BQ.Particles.prototype.burst = function (x, y, n, color, spd, life, size, grav) {
  for (var i = 0; i < n; i++) {
    var a = Math.random() * 6.283, s = Math.random() * (spd || 2);
    this.spawn(x, y, Math.cos(a) * s, Math.sin(a) * s, (life || 24) * (0.6 + Math.random() * 0.6), size || 2, color, grav == null ? 0.08 : grav);
  }
};
BQ.Particles.prototype.dust = function (x, y, n, dir) {
  for (var i = 0; i < n; i++) this.spawn(x + BQ.rand(-3, 3), y, (dir || 0) * BQ.rand(0.2, 0.8) + BQ.rand(-0.4, 0.4), BQ.rand(-0.5, -0.1), BQ.rint(12, 22), BQ.rint(2, 3), 'rgba(200,200,215,0.7)', -0.005);
};
BQ.Particles.prototype.smoke = function (x, y, n, color) {
  for (var i = 0; i < n; i++) this.spawn(x + BQ.rand(-4, 4), y + BQ.rand(-3, 3), BQ.rand(-0.25, 0.25), BQ.rand(-0.8, -0.2), BQ.rint(40, 90), BQ.rint(4, 8), color || 'rgba(70,70,80,0.55)', -0.004, 1);
};
BQ.Particles.prototype.fire = function (x, y, n) {
  for (var i = 0; i < n; i++) this.spawn(x + BQ.rand(-2, 2), y + BQ.rand(-2, 2), BQ.rand(-0.3, 0.3), BQ.rand(-0.9, -0.3), BQ.rint(12, 22), BQ.rint(2, 4), BQ.pick(['#ff5a1f', '#ff9b1f', '#ffd23f']), -0.01, 2);
};
BQ.Particles.prototype.ice = function (x, y, n) {
  for (var i = 0; i < n; i++) this.spawn(x, y, BQ.rand(-1.2, 1.2), BQ.rand(-1.6, 0.2), BQ.rint(18, 30), BQ.rint(2, 3), BQ.pick(['#dff6ff', '#7fd6ff', '#ffffff']), 0.07);
};
BQ.Particles.prototype.ring = function (x, y, r, color) {   // onda de choque (desenhada como anel)
  var p = this.spawn(x, y, 0, 0, 18, r, color || '#fff', 0, 3); return p;
};
BQ.Particles.prototype.text = function (x, y, str, color, size) {
  for (var i = 0; i < this.texts.length; i++) {
    var t = this.texts[i];
    if (!t.on) { t.on = true; t.x = x; t.y = y; t.s = str; t.c = color || '#fff'; t.life = 46; t.size = size || 9; return; }
  }
};
BQ.Particles.prototype.update = function () {
  var l = this.list, i, p;
  for (i = 0; i < l.length; i++) {
    p = l[i]; if (!p.on) continue;
    p.x += p.vx; p.y += p.vy; p.vy += p.grav; p.life--;
    if (p.kind === 1) { p.size += 0.05; }
    if (p.life <= 0) p.on = false;
  }
  for (i = 0; i < this.texts.length; i++) { var t = this.texts[i]; if (t.on) { t.y -= 0.45; t.life--; if (t.life <= 0) t.on = false; } }
};
BQ.Particles.prototype.draw = function (ctx, camX) {
  var l = this.list, i, p;
  for (i = 0; i < l.length; i++) {
    p = l[i]; if (!p.on) continue;
    var a = p.fade ? Math.min(1, p.life / (p.max * 0.6)) : 1, x = Math.round(p.x - camX), y = Math.round(p.y);
    if (x < -20 || x > 500) continue;
    ctx.globalAlpha = a;
    if (p.kind === 3) {
      ctx.strokeStyle = p.color; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, (1 - p.life / p.max) * p.size + 2, 0, 6.283); ctx.stroke();
    } else if (p.kind === 1) {
      ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(x, y, p.size, 0, 6.283); ctx.fill();
    } else { ctx.fillStyle = p.color; ctx.fillRect(x, y, p.size, p.size); }
  }
  ctx.globalAlpha = 1;
  for (i = 0; i < this.texts.length; i++) {
    var t = this.texts[i]; if (!t.on) continue;
    ctx.globalAlpha = Math.min(1, t.life / 14);
    BQ.txt(ctx, t.s, Math.round(t.x - camX), Math.round(t.y), t.size, t.c, 'center');
  }
  ctx.globalAlpha = 1;
};
BQ.Particles.prototype.clear = function () {
  for (var i = 0; i < this.list.length; i++) this.list[i].on = false;
  for (i = 0; i < this.texts.length; i++) this.texts[i].on = false;
};

/* ───────────── Câmara ───────────── */
BQ.Camera = function (game) {
  this.game = game; this.x = 0; this.tx = 0; this.min = 0; this.max = 0; this.look = 0;
  this.shakeT = 0; this.shakeA = 0; this.ox = 0; this.oy = 0; this.locked = false;
};
BQ.Camera.prototype.setLevel = function (pxW) { this.min = 0; this.max = Math.max(0, pxW - BQ.W); this.locked = this.max === 0; this.x = 0; this.tx = 0; };
BQ.Camera.prototype.snap = function (p) { this.x = BQ.clamp(p.x + p.w / 2 - BQ.W * 0.4, this.min, this.max); this.tx = this.x; };
BQ.Camera.prototype.update = function (p) {
  if (!this.locked) {
    var want = p.x + p.w / 2 - BQ.W * 0.42 + p.face * 34;      // olha um pouco para a frente
    this.look += (want - this.look) * 0.05;
    var dz = 26, cur = this.x + BQ.W * 0.42, tgt = this.look + BQ.W * 0.42 - p.face * 34 * 0;
    var px = p.x + p.w / 2;
    if (px - this.x > BQ.W * 0.58) this.tx = px - BQ.W * 0.58;               // só avança quando necessário
    else if (px - this.x < BQ.W * 0.3) this.tx = px - BQ.W * 0.3;
    this.tx = BQ.clamp(this.tx, this.min, this.max);
    this.x += (this.tx - this.x) * 0.12;
    if (Math.abs(this.tx - this.x) < 0.05) this.x = this.tx;
  } else this.x = 0;
  var st = this.game.save.data.settings.shake;
  if (this.shakeT > 0 && st) {
    this.shakeT--; var a = this.shakeA * (this.shakeT / 20 + 0.2);
    this.ox = (Math.random() * 2 - 1) * a; this.oy = (Math.random() * 2 - 1) * a;
  } else { this.ox = this.oy = 0; if (this.shakeT > 0) this.shakeT--; }
};
BQ.Camera.prototype.shake = function (amt, frames) {
  if (amt >= this.shakeA * (this.shakeT / 20 + 0.2) || this.shakeT <= 0) { this.shakeA = amt; this.shakeT = frames || 18; }
};

/* ───────────── Colisões com o mapa ───────────── */
BQ.Collision = {
  T: BQD.TILE,
  solid: function (id) { var T = this.T; return id === T.GROUND || id === T.DIRT || id === T.BRICK || id === T.QBLOCK || id === T.USED || id === T.STEEL || id === T.CRACKED; },
  /* move em X, devolve true se bateu */
  moveX: function (lv, e, dx) {
    if (dx === 0) return false;
    e.x += dx;
    var T = this.T, ts = 16, y0 = Math.floor(e.y / ts), y1 = Math.floor((e.y + e.h - 0.01) / ts), tx, ty, hit = false;
    if (dx > 0) { tx = Math.floor((e.x + e.w - 0.01) / ts); }
    else { tx = Math.floor(e.x / ts); }
    for (ty = y0; ty <= y1; ty++) {
      if (this.solid(lv.tile(tx, ty))) {
        e.x = dx > 0 ? tx * ts - e.w : (tx + 1) * ts; hit = true; break;
      }
    }
    if (e.x < 0) { e.x = 0; hit = true; }
    if (e.x + e.w > lv.pxW) { e.x = lv.pxW - e.w; hit = true; }
    return hit;
  },
  /* move em Y; devolve 1 = aterrou, -1 = bateu a cabeça, 0 = livre. Lida com plataformas de sentido único. */
  moveY: function (lv, e, dy, drop) {
    var ts = 16, T = this.T, x0 = Math.floor(e.x / ts), x1 = Math.floor((e.x + e.w - 0.01) / ts), tx, ty, oldBottom = e.y + e.h;
    e.y += dy;
    if (dy >= 0) {
      ty = Math.floor((e.y + e.h - 0.01) / ts);
      for (tx = x0; tx <= x1; tx++) {
        var id = lv.tile(tx, ty);
        if (this.solid(id) || (id === T.GIRDER && !drop && oldBottom <= ty * ts + 0.5 && e.y + e.h > ty * ts)) {
          if (this.solid(id) || oldBottom <= ty * ts + 0.5) { e.y = ty * ts - e.h; return 1; }
        }
      }
    } else {
      ty = Math.floor(e.y / ts);
      for (tx = x0; tx <= x1; tx++) {
        var id2 = lv.tile(tx, ty);
        if (id2 === T.HIDDEN && e.isPlayer) { e.y = (ty + 1) * ts; lv.hitBlock(tx, ty, e); return -1; }
        if (this.solid(id2)) { e.y = (ty + 1) * ts; lv.hitBlock(tx, ty, e); return -1; }
      }
    }
    return 0;
  },
  onGround: function (lv, e) {
    var ts = 16, y = e.y + e.h + 0.5, x0 = Math.floor(e.x / ts), x1 = Math.floor((e.x + e.w - 0.01) / ts), ty = Math.floor(y / ts);
    for (var tx = x0; tx <= x1; tx++) {
      var id = lv.tile(tx, ty);
      if (this.solid(id)) return true;
      if (id === this.T.GIRDER && e.y + e.h <= ty * ts + 1) return true;
    }
    return false;
  },
  spikeAt: function (lv, e) {
    var ts = 16, T = this.T, x0 = Math.floor((e.x + 2) / ts), x1 = Math.floor((e.x + e.w - 2) / ts), y0 = Math.floor((e.y + e.h - 6) / ts), y1 = Math.floor((e.y + e.h - 1) / ts);
    for (var ty = y0; ty <= y1; ty++) for (var tx = x0; tx <= x1; tx++) {
      if (lv.tile(tx, ty) === T.SPIKES && e.y + e.h > ty * ts + 6) return true;
    }
    return false;
  }
};
'use strict';
/* BlockQuest — PowerSystem (projéteis, zonas, feixes), FusionSystem e InventorySystem */

/* ───────────── Fusões ───────────── */
BQ.FusionSystem = {
  combine: function (a, b) {
    if (!a || !b) return null;
    return BQD.FUSIONS[BQD.fusionKey(a.id, b.id)] || null;
  },
  /* ids base de um poder (para fusões guardamos a chave) */
  isFusion: function (def) { return !BQD.POWERS[def.id]; }
};

/* ───────────── Inventário (2 slots) ───────────── */
BQ.Inventory = function (player) { this.player = player; this.slots = [null, null]; };
BQ.Inventory.prototype.equipped = function () { return this.slots[0]; };
BQ.Inventory.prototype.add = function (def) {
  var s = { def: def, ammo: def.ammo };
  if (!this.slots[0]) { this.slots[0] = s; return null; }
  if (!this.slots[1]) { this.slots[1] = s; return null; }
  var old = this.slots[0]; this.slots[0] = s; return old;       // cheio: substitui o equipado e devolve o antigo
};
BQ.Inventory.prototype.swap = function () { var t = this.slots[0]; this.slots[0] = this.slots[1]; this.slots[1] = t; };
BQ.Inventory.prototype.use = function () {
  var s = this.slots[0]; if (!s) return null;
  s.ammo--;
  if (s.ammo <= 0) { this.slots[0] = this.slots[1]; this.slots[1] = null; }
  return s.def;
};
BQ.Inventory.prototype.take = function () {     // retira o poder equipado (para sacrificar)
  var s = this.slots[0]; if (!s) return null;
  this.slots[0] = this.slots[1]; this.slots[1] = null; return s.def;
};

/* ───────────── PowerSystem ───────────── */
BQ.PowerSystem = function (game) {
  this.game = game; this.proj = []; this.zones = []; this.beams = [];
  for (var i = 0; i < 90; i++) this.proj.push({ on: false });
  for (i = 0; i < 30; i++) this.zones.push({ on: false });
  for (i = 0; i < 10; i++) this.beams.push({ on: false });
};
BQ.PowerSystem.prototype.clear = function () {
  var i; for (i = 0; i < this.proj.length; i++) this.proj[i].on = false;
  for (i = 0; i < this.zones.length; i++) this.zones[i].on = false;
  for (i = 0; i < this.beams.length; i++) this.beams[i].on = false;
};
BQ.PowerSystem.prototype.targets = function (team) {
  var g = this.game, lv = g.level, out = [], i;
  if (team === 'p') {
    for (i = 0; i < lv.enemies.length; i++) { var e = lv.enemies[i]; if (e.state !== 'DEAD') out.push(e); }
    if (lv.boss && lv.boss.canBeHit()) out.push(lv.boss);
  } else {
    if (g.player && g.player.state !== 'dead') out.push(g.player);
    for (i = 0; i < g.allies.length; i++) out.push(g.allies[i]);
  }
  return out;
};
BQ.PowerSystem.prototype.hurtTarget = function (t, dmg, srcX, team, opts) {
  if (team === 'p') return t.damage(dmg, srcX, opts);
  return t.hurt(dmg, srcX, opts);
};
BQ.PowerSystem.prototype.newProj = function () {
  for (var i = 0; i < this.proj.length; i++) if (!this.proj[i].on) return this.proj[i];
  return null;
};
BQ.PowerSystem.prototype.newZone = function () {
  for (var i = 0; i < this.zones.length; i++) if (!this.zones[i].on) return this.zones[i];
  return null;
};

BQ.PowerSystem.prototype.shoot = function (o) {   // projétil genérico
  var p = this.newProj(); if (!p) return null;
  p.on = true; p.x = o.x; p.y = o.y; p.vx = o.vx; p.vy = o.vy || 0; p.gravity = o.gravity || 0;
  p.r = o.r || 3; p.w = p.r * 2; p.h = o.h || p.r * 2; p.wave = !!o.wave; p.life = o.life || 60; p.dmg = o.dmg || 1;
  p.team = o.team || 'p'; p.pierce = !!o.pierce; p.knock = o.knock || 0; p.status = o.status || null; p.def = o.def || null;
  p.kind = o.kind || 'bolt'; p.trail = o.trail || null; p.bounce = !!o.bounce; p.bounces = 0; p.land = o.land || null;
  p.color = o.color || '#fff'; p.hit = []; p.tick = 0; p.laser = !!o.laser; p.shard = !!o.shard;
  return p;
};

/* dispara um poder (def) a partir de (x,y) para a direção dir (1/-1). team: 'p' jogador/aliado */
BQ.PowerSystem.prototype.cast = function (def, x, y, dir, team) {
  var g = this.game, i, k = def.kind, sp;
  team = team || 'p';
  g.audio.sfx(k === 'beam' ? 'beam' : 'cast');
  if (k === 'bolt') {
    this.shoot({ x: x, y: y, vx: dir * def.speed, vy: 0, gravity: def.gravity, r: def.r, life: def.life, dmg: def.dmg, team: team, pierce: def.pierce,
      status: def.status, def: def, kind: 'bolt', trail: def.trail, bounce: def.bounce, color: def.color, knock: 1.2 });
  } else if (k === 'fan') {
    for (i = 0; i < def.count; i++) {
      var ang = (i - (def.count - 1) / 2) * def.spread;
      this.shoot({ x: x, y: y, vx: dir * Math.cos(ang) * def.speed, vy: Math.sin(ang) * def.speed, r: def.r, life: def.life, dmg: def.dmg, team: team,
        pierce: def.pierce, def: def, kind: 'shard', trail: def.trail, color: def.color, knock: 0.8, shard: true });
    }
  } else if (k === 'lob') {
    this.shoot({ x: x, y: y, vx: dir * def.vx, vy: def.vy, gravity: def.gravity, r: def.r, life: 120, dmg: def.dmg || 0, team: team, def: def, kind: 'lob',
      land: def.land, trail: def.trail || 'potion', color: def.color });
  } else if (k === 'wave') {
    this.shoot({ x: x, y: y, vx: dir * def.speed, vy: 0, r: 4, h: def.h, life: def.life, dmg: def.dmg, team: team, pierce: true, wave: true, def: def, kind: 'wave',
      knock: def.knock, status: def.status, trail: def.trail, color: def.color });
    g.camera.shake(1.5, 6);
  } else if (k === 'beam') {
    var b = null; for (i = 0; i < this.beams.length; i++) if (!this.beams[i].on) { b = this.beams[i]; break; }
    if (b) {
      b.on = true; b.x = x; b.y = y; b.dir = dir; b.def = def; b.t = def.dur; b.team = team; b.len = def.len;
      this.beamHit(b);
    }
  } else if (k === 'cloud') {
    var z = this.newZone();
    if (z) { z.on = true; z.kind = 'cloud'; z.style = def.style; z.w = def.w; z.h = def.h; z.x = x + dir * def.ahead - def.w / 2; z.y = y + 6 - def.h + 6;
      z.life = def.life; z.tick = def.tick; z.dmg = def.dmg; z.status = def.status; z.team = team; z.t = 0; z.color = def.color; z.delay = 0; }
  } else if (k === 'nova') {
    this.nova(x, y, def.r, def.dmg, def.knock, def.status, team, def);
  } else if (k === 'spikes') {
    var gy = g.level.groundY(x, y);
    for (i = 0; i < def.count; i++) {
      var zz = this.newZone(); if (!zz) break;
      zz.on = true; zz.kind = 'spike'; zz.x = x + dir * (14 + i * def.gap) - 4; zz.w = 9; zz.h = def.h; zz.y = g.level.groundY(x + dir * (14 + i * def.gap), y) - def.h;
      zz.delay = i * def.delay; zz.life = 34; zz.t = 0; zz.dmg = def.dmg; zz.status = def.status; zz.team = team; zz.done = false; zz.color = def.color; zz.tick = 999;
    }
  }
};

BQ.PowerSystem.prototype.beamHit = function (b) {
  var g = this.game, lv = g.level, def = b.def, angs = def.angles || [0], hitSet = [], tg = this.targets(b.team), a, d, i;
  for (a = 0; a < angs.length; a++) {
    var ang = angs[a], cx = Math.cos(ang) * b.dir, sy = Math.sin(ang);
    for (d = 8; d <= def.len; d += 6) {
      var px = b.x + cx * d, py = b.y + sy * d, id = lv.tile(Math.floor(px / 16), Math.floor(py / 16));
      if (BQ.Collision.solid(id)) { if (id === BQD.TILE.CRACKED && b.team === 'p') lv.breakTile(Math.floor(px / 16), Math.floor(py / 16)); break; }
      for (i = 0; i < tg.length; i++) {
        var t = tg[i];
        if (hitSet.indexOf(t) >= 0) continue;
        if (px > t.x - 2 && px < t.x + t.w + 2 && py > t.y - def.h / 2 && py < t.y + t.h + def.h / 2) {
          hitSet.push(t); this.hurtTarget(t, def.dmg, b.x, b.team, { status: def.status, knock: 1.5 });
          g.particles.burst(t.x + t.w / 2, t.y + t.h / 2, 6, def.color, 2, 18, 2);
        }
      }
    }
  }
};

BQ.PowerSystem.prototype.nova = function (x, y, r, dmg, knock, status, team, def) {
  var g = this.game, tg = this.targets(team), i;
  g.audio.sfx('boom'); g.camera.shake(3, 10);
  g.particles.ring(x, y, r, (def && def.color) || '#fff'); g.particles.ring(x, y, r * 0.6, '#fff');
  g.particles.burst(x, y, 16, (def && def.color) || '#fff', 3, 26, 3, 0);
  for (i = 0; i < tg.length; i++) {
    var t = tg[i], cx = t.x + t.w / 2, cy = t.y + t.h / 2, dx = cx - x, dy = cy - y;
    if (dx * dx + dy * dy < r * r) this.hurtTarget(t, dmg, x, team, { status: status, knock: knock });
  }
};

BQ.PowerSystem.prototype.land = function (p) {
  var g = this.game, L = p.land, x = p.x, y = p.y, lv = g.level;
  g.audio.sfx('break');
  if (!L) return;
  var gy = lv.groundY(x, y);
  if (L.burst) this.nova(x, gy - 4, L.burst, L.burstDmg, 2.5, null, p.team, p.def);
  if (L.shards) {
    for (var i = 0; i < L.shards; i++) {
      var a = -Math.PI * (0.15 + 0.7 * i / (L.shards - 1));
      this.shoot({ x: x, y: gy - 6, vx: Math.cos(a) * 2.6, vy: Math.sin(a) * 2.6, gravity: 0.12, r: 3, life: 50, dmg: L.shardDmg, team: p.team, def: p.def, kind: 'shard', trail: 'glass', color: '#bfe9ff', shard: true });
    }
  }
  if (L.zone) {
    var z = this.newZone();
    if (z) { z.on = true; z.kind = 'cloud'; z.style = L.zone; z.w = L.w; z.h = L.h; z.x = x - L.w / 2; z.y = gy - L.h; z.life = L.life; z.tick = L.tick; z.dmg = L.dmg;
      z.status = L.status; z.team = p.team; z.t = 0; z.color = p.def ? p.def.color : '#9be24a'; z.delay = 0; }
  }
};

BQ.PowerSystem.prototype.killProj = function (p, burst) {
  p.on = false;
  if (burst) this.game.particles.burst(p.x, p.y, 5, p.color, 1.6, 16, 2);
};

BQ.PowerSystem.prototype.update = function () {
  var g = this.game, lv = g.level, i, j, p, tg;
  for (i = 0; i < this.proj.length; i++) {
    p = this.proj[i]; if (!p.on) continue;
    p.vy += p.gravity; p.x += p.vx; p.y += p.vy; p.life--; p.tick++;
    // rasto
    if (p.trail && (p.tick & 1) === 0) {
      var tcol = p.color;
      if (p.trail === 'fire') g.particles.fire(p.x, p.y, 1);
      else if (p.trail === 'ice') g.particles.spawn(p.x, p.y, BQ.rand(-0.3, 0.3), BQ.rand(-0.3, 0.3), 14, 2, '#dff6ff', 0.02);
      else if (p.trail === 'plasma') g.particles.spawn(p.x + BQ.rand(-3, 3), p.y + BQ.rand(-3, 3), 0, 0, 16, 3, BQ.pick(['#ff6bd6', '#fff2a8', '#ff9bf0']), 0);
      else if (p.trail === 'energy') g.particles.spawn(p.x, p.y, BQ.rand(-0.4, 0.4), BQ.rand(-0.4, 0.4), 12, 2, BQ.pick(['#b58cff', '#f2e6ff']), 0);
      else if (p.trail === 'sound') { /* ondas desenhadas */ }
      else if (p.trail === 'glass') g.particles.spawn(p.x, p.y, 0, 0, 8, 1, '#ffffff', 0);
      else if (p.trail === 'potion') g.particles.spawn(p.x, p.y, 0, 0, 12, 2, '#9be24a', 0.02);
    }
    // mapa
    var tx = Math.floor(p.x / 16), ty = Math.floor(p.y / 16), id = lv.tile(tx, ty), solid = BQ.Collision.solid(id);
    if (solid) {
      if (id === BQD.TILE.CRACKED && p.team === 'p') lv.breakTile(tx, ty);
      if (p.kind === 'lob') { p.y -= p.vy; this.land(p); p.on = false; continue; }
      if (p.bounce && p.vy > 0 && p.bounces < 3) { p.y -= p.vy; p.vy = -Math.abs(p.vy) * 0.65; p.bounces++; g.particles.fire(p.x, p.y, 3); continue; }
      this.killProj(p, true); continue;
    }
    if (p.y > 300 || p.x < -20 || p.x > lv.pxW + 20) { p.on = false; continue; }
    if (p.life <= 0) { if (p.kind === 'lob') this.land(p); p.on = false; continue; }
    if (p.kind === 'lob' && p.team === 'p') {
      // frasco rebenta ao tocar num inimigo
      tg = this.targets('p');
      for (j = 0; j < tg.length; j++) { var t0 = tg[j]; if (p.x > t0.x && p.x < t0.x + t0.w && p.y > t0.y && p.y < t0.y + t0.h) { this.land(p); p.on = false; break; } }
      if (!p.on) continue;
    }
    if (p.dmg <= 0) continue;
    // alvos
    tg = this.targets(p.team);
    var hw = p.wave ? 5 : p.r, hh = p.wave ? p.h / 2 : p.r;
    for (j = 0; j < tg.length; j++) {
      var t = tg[j];
      if (p.hit.indexOf(t) >= 0) continue;
      if (p.x + hw > t.x && p.x - hw < t.x + t.w && p.y + hh > t.y && p.y - hh < t.y + t.h) {
        var ok = this.hurtTarget(t, p.dmg, p.x - p.vx * 3, p.team, { status: p.status, knock: p.knock || 1.2, proj: true });
        p.hit.push(t);
        if (ok !== false) {
          g.particles.burst(p.x, p.y, 5, p.color, 1.8, 16, 2);
          if (!p.pierce) { p.on = false; break; }
        }
      }
    }
  }
  // feixes
  for (i = 0; i < this.beams.length; i++) { var b = this.beams[i]; if (b.on) { b.t--; if (b.t <= 0) b.on = false; } }
  // zonas
  for (i = 0; i < this.zones.length; i++) {
    var z = this.zones[i]; if (!z.on) continue;
    if (z.delay > 0) { z.delay--; continue; }
    z.t++; z.life--;
    if (z.kind === 'spike') {
      if (!z.done) {
        z.done = true; g.audio.sfx('break'); g.particles.ice(z.x + 4, z.y + z.h, 4);
        tg = this.targets(z.team);
        for (j = 0; j < tg.length; j++) { var tz = tg[j]; if (tz.x + tz.w > z.x && tz.x < z.x + z.w && tz.y + tz.h > z.y && tz.y < z.y + z.h) this.hurtTarget(tz, z.dmg, z.x + 4, z.team, { status: z.status, knock: 0.6 }); }
      }
    } else {
      if (z.t % z.tick === 1) {
        tg = this.targets(z.team);
        for (j = 0; j < tg.length; j++) { var t2 = tg[j]; if (t2.x + t2.w > z.x && t2.x < z.x + z.w && t2.y + t2.h > z.y && t2.y < z.y + z.h) this.hurtTarget(t2, z.dmg, z.x + z.w / 2, z.team, { status: z.status, knock: 0, zone: true }); }
      }
      if (z.t % 4 === 0) {
        var px = z.x + Math.random() * z.w, py = z.y + z.h * (0.3 + Math.random() * 0.7);
        if (z.style === 'steam') g.particles.spawn(px, py, BQ.rand(-0.2, 0.2), -0.3, 34, BQ.rint(4, 7), 'rgba(235,240,245,0.55)', -0.003, 1);
        else if (z.style === 'poison') g.particles.spawn(px, py, BQ.rand(-0.2, 0.2), -0.3, 30, BQ.rint(3, 6), 'rgba(140,230,60,0.55)', -0.004, 1);
        else if (z.style === 'snow') g.particles.spawn(px, py, BQ.rand(-0.3, 0.3), -0.1, 30, BQ.rint(2, 4), BQ.pick(['rgba(220,250,240,0.8)', 'rgba(140,230,60,0.6)']), 0.01, 1);
        else if (z.style === 'fire') g.particles.fire(px, z.y + z.h - 2, 1);
      }
    }
    if (z.life <= 0) z.on = false;
  }
};

BQ.PowerSystem.prototype.draw = function (ctx, camX) {
  var i, p, t = this.game.frame;
  // zonas (base translúcida)
  for (i = 0; i < this.zones.length; i++) {
    var z = this.zones[i]; if (!z.on || z.delay > 0) continue;
    var zx = Math.round(z.x - camX), zy = Math.round(z.y);
    if (z.kind === 'spike') {
      var rise = Math.min(1, z.t / 6), fade = Math.min(1, z.life / 10), hh = z.h * rise;
      ctx.globalAlpha = fade; ctx.fillStyle = z.color; ctx.beginPath(); ctx.moveTo(zx, zy + z.h); ctx.lineTo(zx + 4.5, zy + z.h - hh); ctx.lineTo(zx + 9, zy + z.h); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(zx + 2, zy + z.h); ctx.lineTo(zx + 4.5, zy + z.h - hh * 0.85); ctx.lineTo(zx + 5, zy + z.h); ctx.fill(); ctx.globalAlpha = 1;
    } else {
      var a = Math.min(1, z.life / 30) * 0.18;
      ctx.globalAlpha = a; ctx.fillStyle = z.style === 'fire' ? '#ff7a2b' : z.style === 'poison' ? '#7fe03a' : '#e6eef3'; ctx.fillRect(zx, zy, z.w, z.h); ctx.globalAlpha = 1;
    }
  }
  // feixes
  for (i = 0; i < this.beams.length; i++) {
    var b = this.beams[i]; if (!b.on) continue;
    var angs = b.def.angles || [0], al = Math.min(1, b.t / 5);
    for (var a = 0; a < angs.length; a++) {
      var ex = b.x + Math.cos(angs[a]) * b.dir * b.len, ey = b.y + Math.sin(angs[a]) * b.len, jit = (Math.random() - 0.5) * 2;
      ctx.globalAlpha = al; ctx.lineCap = 'round';
      ctx.strokeStyle = b.def.color; ctx.lineWidth = b.def.h; ctx.beginPath(); ctx.moveTo(b.x - camX, b.y); ctx.lineTo(ex - camX, ey + jit); ctx.stroke();
      ctx.strokeStyle = b.def.color2 || '#fff'; ctx.lineWidth = b.def.h * 0.45; ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.globalAlpha = 1;
    }
  }
  // projéteis
  for (i = 0; i < this.proj.length; i++) {
    p = this.proj[i]; if (!p.on) continue;
    var x = Math.round(p.x - camX), y = Math.round(p.y);
    if (p.wave) {
      ctx.strokeStyle = p.color; ctx.lineWidth = 2; var dir = p.vx > 0 ? 1 : -1;
      for (var k = 0; k < 3; k++) { ctx.globalAlpha = 1 - k * 0.28; ctx.beginPath(); ctx.arc(x - dir * k * 5, y, 6 + k * 3, dir > 0 ? -1.1 : Math.PI - 1.1, dir > 0 ? 1.1 : Math.PI + 1.1); ctx.stroke(); }
      ctx.globalAlpha = 1;
    } else if (p.kind === 'shard') {
      ctx.save(); ctx.translate(x, y); ctx.rotate(Math.atan2(p.vy, p.vx));
      ctx.fillStyle = p.color; ctx.beginPath(); ctx.moveTo(5, 0); ctx.lineTo(-3, -2.5); ctx.lineTo(-3, 2.5); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.fillRect(-1, -1, 3, 1); ctx.restore();
    } else if (p.kind === 'lob') {
      ctx.save(); ctx.translate(x, y); ctx.rotate(t / 6); var ic = BQ.Art.getPowerIcon(p.def); ctx.imageSmoothingEnabled = false; ctx.drawImage(ic, -6, -6, 12, 12); ctx.restore();
    } else {
      var g2 = this.game;
      if (g2.save.data.settings.quality !== 'low') { ctx.globalAlpha = 0.5; ctx.drawImage(BQ.Art.light('rgba(255,255,255,1)'), x - p.r * 3, y - p.r * 3, p.r * 6, p.r * 6); ctx.globalAlpha = 1; }
      ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(x, y, p.r + 0.5, 0, 6.283); ctx.fill();
      ctx.fillStyle = (p.def && p.def.color2) || '#fff'; ctx.beginPath(); ctx.arc(x, y, Math.max(1, p.r - 1.5), 0, 6.283); ctx.fill();
      if (p.laser) { ctx.fillStyle = '#7fffd4'; ctx.fillRect(x - 6, y - 1, 12, 2); }
    }
  }
};
'use strict';
/* BlockQuest — Player, Enemy, Ally, Boss */

/* ───────────── Player ───────────── */
BQ.Player = function (game, ch, x, y) {
  this.game = game; this.ch = ch; this.x = x; this.y = y; this.w = 10; this.h = 14;
  this.vx = 0; this.vy = 0; this.face = 1; this.onGround = false; this.isPlayer = true;
  this.state = 'idle'; this.anim = 0; this.animT = 0; this.hp = 3; this.maxHp = 3; this.lives = 3;
  this.inv = 0; this.hurtT = 0; this.attackT = 0; this.attackCd = 0; this.comboN = 0; this.comboT = 0;
  this.jumps = 0; this.maxJumps = ch.flags.doubleJump ? 2 : 1; this.coyote = 0; this.jumpBuf = 0;
  this.charge = 0; this.diving = false; this.shield = !!ch.flags.startShield; this.inventory = new BQ.Inventory(this);
  this.invisT = 0; this.invisCd = 0; this.radioT = ch.flags.radio ? ch.flags.radio.every : 0;
  this.magnetR = ch.flags.magnet || 0; this.coinMult = ch.flags.coinMult || 1;
  this.score = 0; this.coins = 0; this.killChain = 0; this.killChainT = 0; this.frozeT = 0; this.stunT = 0; this.burnT = 0; this.burnTick = 0;
  this.won = false; this.dead = false; this.deadT = 0; this.discoveredFusion = null; this.discFlashT = 0;
  this.noDamage = true; this.spawnX = x; this.spawnY = y; this.finishT = 0;
};
BQ.Player.SPEED = 1.55; BQ.Player.ACC = 0.17; BQ.Player.FRICTION = 0.22; BQ.Player.GRAV = 0.34; BQ.Player.JUMPV = -5.7; BQ.Player.MAXFALL = 5.6;

BQ.Player.prototype.respawnAt = function (x, y) {
  this.x = x; this.y = y; this.vx = 0; this.vy = 0; this.hp = this.maxHp; this.inv = 60;
  this.frozeT = 0; this.stunT = 0; this.game.powers.clear();
};
BQ.Player.prototype.damage = function () { return false; };  // jogador não é alvo de "team p"
BQ.Player.prototype.hurt = function (dmg, srcX, opts) {
  if (this.inv > 0 || this.dead || this.invisT > 0) return false;
  if (this.shield) { this.shield = false; this.game.audio.sfx('shield'); this.inv = 50; this.game.particles.ring(this.x + this.w / 2, this.y + this.h / 2, 14, '#7dd0ff'); return true; }
  this.hp -= dmg; this.inv = 80; this.noDamage = false;
  if (srcX !== undefined) this.vx = srcX < this.x ? 1.6 : -1.6, this.vy = -2.2;
  this.game.audio.sfx('hurt'); this.game.camera.shake(2.2, 12);
  if (opts && opts.status) this.applyStatus(opts.status);
  if (this.hp <= 0) this.die();
  return true;
};
BQ.Player.prototype.applyStatus = function (st) {
  if (st.freeze) this.frozeT = Math.max(this.frozeT, st.freeze * 0.4);
  if (st.stun) this.stunT = Math.max(this.stunT, st.stun * 0.5);
  if (st.burn) this.burnT = Math.max(this.burnT, st.burn);
  if (st.poison) this.burnT = Math.max(this.burnT, st.poison * 0.6);
};
BQ.Player.prototype.die = function () {
  if (this.dead) return; this.dead = true; this.deadT = 0; this.game.audio.sfx('die'); this.game.audio.stopMusic();
};
BQ.Player.prototype.pickPower = function (id, isFusion) {
  var def = isFusion ? BQD.FUSIONS[id] : BQD.POWERS[id];
  if (!def) return;
  this.inventory.add(def);
  this.game.audio.sfx('power');
  this.game.particles.text(this.x + this.w / 2, this.y - 6, def.icon + ' ' + def.name, '#ffe27a', 8);
};
BQ.Player.prototype.tryFuse = function () {
  var inv = this.inventory, a = inv.slots[0], b = inv.slots[1];
  if (!a || !b) return;
  var def = BQ.FusionSystem.combine(a.def, b.def);
  var g = this.game;
  if (!def) { g.audio.sfx('nofuse'); g.particles.text(this.x + this.w / 2, this.y - 6, 'Sem fusão', '#ff8a8a', 8); return; }
  inv.slots[0] = null; inv.slots[1] = null;
  var save = g.save, isNew = !save.data.fusions[def.id];
  save.data.fusions[def.id] = true; save.commit();
  var cx = this.x + this.w / 2 + this.face * 12, cy = this.y + 2;
  g.powers.cast(def, cx, cy, this.face, 'p');
  if (isNew) { g.audio.sfx('discover'); this.discoveredFusion = def; this.discFlashT = 130; g.checkAchievement('fusion5', Object.keys(save.data.fusions).length >= 5); }
  else g.audio.sfx('fusion');
};
BQ.Player.prototype.summonAlly = function () {
  var def = this.inventory.take(); if (!def) return;
  this.game.spawnAlly(def, this.x, this.y);
  this.game.audio.sfx('ally'); this.game.checkAchievement('ally', true);
};

BQ.Player.prototype.update = function () {
  var g = this.game, inp = g.input, lv = g.level;
  if (this.dead) { this.deadT++; if (this.vy < 6) this.vy += 0.3; this.y += this.vy; this.animT++; return; }
  if (this.finishT > 0) { this.finishT--; this.vx *= 0.9; this.x += this.vx; this.animT++; return; }
  if (this.inv > 0) this.inv--;
  if (this.hurtT > 0) this.hurtT--;
  if (this.attackCd > 0) this.attackCd--;
  if (this.comboT > 0) { this.comboT--; if (this.comboT === 0) this.comboN = 0; }
  if (this.killChainT > 0) { this.killChainT--; if (this.killChainT === 0) this.killChain = 0; }
  if (this.invisT > 0) this.invisT--;
  if (this.invisCd > 0) this.invisCd--;
  if (this.discFlashT > 0) this.discFlashT--;
  var frozen = this.frozeT > 0, stunned = this.stunT > 0;
  if (frozen) this.frozeT--;
  if (stunned) this.stunT--;
  if (this.burnT > 0) {
    this.burnT--; this.burnTick++;
    if (this.burnTick % 45 === 0 && this.inv <= 0) { this.hurt(1); g.particles.fire(this.x + this.w / 2, this.y + 4, 3); }
  }

  var canAct = !frozen && !stunned && this.attackT <= 0;
  var left = inp.held.left, right = inp.held.right;
  if (canAct && (left || right) && !(left && right)) {
    this.face = left ? -1 : 1; var d = left ? -1 : 1;
    this.vx += d * BQ.Player.ACC; if (Math.abs(this.vx) > BQ.Player.SPEED) this.vx = d * BQ.Player.SPEED;
  } else {
    var s = this.vx > 0 ? -1 : 1, fric = (g.level && g.level.theme === 'ice') ? BQ.Player.FRICTION * 0.28 : BQ.Player.FRICTION;
    this.vx += s * fric; if (Math.abs(this.vx) < fric) this.vx = 0;
  }
  if (frozen) this.vx *= 0.4;

  // salto
  if (inp.pressed.jump) this.jumpBuf = 8;
  if (this.jumpBuf > 0) this.jumpBuf--;
  if (this.onGround) { this.jumps = 0; this.coyote = 7; }
  else if (this.coyote > 0) this.coyote--;
  if (canAct && this.jumpBuf > 0 && (this.coyote > 0 || this.jumps < this.maxJumps)) {
    this.vy = BQ.Player.JUMPV; this.jumpBuf = 0; this.coyote = 0; this.jumps++;
    g.audio.sfx(this.jumps > 1 ? 'djump' : 'jump'); g.particles.dust(this.x + this.w / 2, this.y + this.h, 5, 0);
    this.diving = false;
  }
  if (!inp.held.jump && this.vy < -1.5 && !frozen) this.vy = -1.5;
  this.vy += BQ.Player.GRAV; if (this.vy > BQ.Player.MAXFALL) this.vy = BQ.Player.MAXFALL;

  // ataque descendente (dive): salto + baixo no ar
  if (canAct && inp.pressed.down && !this.onGround && !this.diving && this.vy > -1) { this.diving = true; this.vy = 4.2; g.audio.sfx('swing'); }

  // ataque G
  if (canAct && inp.pressed.attack && this.attackCd <= 0) {
    this.attackT = 12; this.attackCd = 15;
    this.comboN = (this.comboT > 0 ? this.comboN + 1 : 1) % 3 || 3; this.comboT = 22;
    g.audio.sfx('swing'); this.doAttack();
  }
  if (this.attackT > 0) this.attackT--;

  // apanhar / invocar O
  if (inp.pressed.pick) {
    var got = lv.tryPickup(this);
    if (!got && this.inventory.slots[0]) this.summonAlly();
  }
  // poder X
  if (canAct && inp.pressed.power) {
    var eq = this.inventory.equipped();
    if (eq && this.attackCd <= 0) {
      var def2 = this.inventory.use(); this.attackCd = def2.cd || 20;
      g.powers.cast(def2, this.x + this.w / 2 + this.face * 6, this.y + 4, this.face, 'p');
    }
  }
  // fusão C
  if (inp.pressed.fuse) this.tryFuse();
  // habilidade especial V (Funny Boy)
  if (inp.pressed.special && this.ch.flags.invis && this.invisCd <= 0) {
    this.invisT = this.ch.flags.invis.dur; this.invisCd = this.ch.flags.invis.cd; g.audio.sfx('invis');
  }
  if (inp.pressed.swap) this.inventory.swap();

  // radio automático (DJ Vibes)
  if (this.ch.flags.radio) {
    this.radioT--;
    if (this.radioT <= 0) { this.radioT = this.ch.flags.radio.every; g.powers.cast(BQD.POWERS.sound, this.x + this.w / 2 + this.face * 6, this.y + 4, this.face, 'p'); g.audio.sfx('radio'); }
  }

  // física + colisões
  var hitWallX = BQ.Collision.moveX(lv, this, this.vx);
  if (hitWallX) this.vx = 0;
  var wasGround = this.onGround;
  var r = BQ.Collision.moveY(lv, this, this.vy, inp.held.down && this.onGround);
  if (r === 1) { if (!wasGround && this.vy > 3) g.particles.dust(this.x + this.w / 2, this.y + this.h, 6, 0); this.vy = 0; this.onGround = true; this.diving = false; }
  else if (r === -1) { this.vy = 0.6; }
  else this.onGround = false;

  if (BQ.Collision.spikeAt(lv, this)) this.hurt(1, this.x - 5);
  if (this.y > lv.pxH + 40) this.die();

  // magnetismo de moedas
  if (this.magnetR) lv.magnetCoins(this, this.magnetR);

  this.updateAnim();
};
BQ.Player.prototype.doAttack = function () {
  var g = this.game, lv = g.level, reach = 13, x = this.face > 0 ? this.x + this.w : this.x - reach, dmg = this.diving ? 2 : 1;
  var box = { x: x, y: this.diving ? this.y + this.h - 5 : this.y + 2, w: reach, h: this.diving ? 8 : 10 };
  var hitAny = false;
  for (var i = 0; i < lv.enemies.length; i++) {
    var e = lv.enemies[i]; if (e.state === 'DEAD') continue;
    if (BQ.hit(box, e)) { hitAny = true; e.hurt(dmg, this.x, { knock: 1.4 }); g.particles.burst(e.x + e.w / 2, e.y + e.h / 2, 5, '#fff', 1.6, 14, 2); }
  }
  if (lv.boss && lv.boss.canBeHit() && BQ.hit(box, lv.boss)) { lv.boss.hurt(dmg, this.x, { knock: 1 }); hitAny = true; }
  // martelo em blocos rachados/quebráveis à frente
  var tx = Math.floor((this.face > 0 ? this.x + this.w + 2 : this.x - 2) / 16), ty = Math.floor((this.y + 6) / 16);
  if (lv.tile(tx, ty) === BQD.TILE.CRACKED) lv.breakTile(tx, ty);
  if (hitAny) g.audio.sfx('hit');
};
BQ.Player.prototype.stomp = function (e) {
  this.vy = -3.6; this.game.audio.sfx('stomp'); this.jumps = Math.max(0, this.jumps - 1);
};
BQ.Player.prototype.registerKill = function (e, stomped) {
  var g = this.game;
  this.killChain = Math.min(9, this.killChain + 1); this.killChainT = 80;
  var coins = Math.min(this.killChain, 6) * this.coinMult;
  g.addCoins(coins, e.x + e.w / 2, e.y);
  if (this.killChain >= 4) g.particles.text(e.x + e.w / 2, e.y - 10, 'COMBO x' + this.killChain, '#ffe27a', 10);
  g.checkAchievement('combo10', this.killChain >= 10);
  this.score += 100 * this.killChain;
};
BQ.Player.prototype.updateAnim = function () {
  this.animT++;
  var st;
  if (this.dead) st = 'dead';
  else if (this.hurtT > 0 || this.inv > 40) st = 'hurt';
  else if (this.attackT > 0) st = this.diving ? 'dive' : (this.comboN === 2 ? 'atk1' : this.comboN >= 3 ? 'atk2' : 'atk0');
  else if (!this.onGround) st = this.vy < 0 ? 'jump' : 'fall';
  else if (Math.abs(this.vx) > 0.25) st = 'run';
  else st = 'idle';
  if (st !== this.state) { this.state = st; this.frame = 0; this.animT = 0; }
};
BQ.Player.prototype.currentSprite = function () {
  var set = BQ.Art.chars[this.ch.id], st = this.state, i;
  if (st === 'run') { i = Math.floor(this.animT / 5) % 4; return set['run' + i]; }
  if (st === 'idle') { i = Math.floor(this.animT / 18) % 2; return set['idle' + i]; }
  if (st === 'hurt') return set.hurt;
  if (st === 'jump') return set.jump;
  if (st === 'fall') return set.fall;
  if (st === 'dive') return set.dive;
  if (st === 'dead') return set.dead;
  if (st === 'atk0') return set.atk0; if (st === 'atk1') return set.atk1; if (st === 'atk2') return set.atk2;
  return set.idle0;
};

/* ───────────── Aliado invocado ───────────── */
BQ.Ally = function (game, def, x, y) {
  this.game = game; this.def = def; this.x = x; this.y = y; this.w = 8; this.h = 10; this.vx = 0; this.vy = 0;
  this.hp = 4; this.face = 1; this.cd = 0; this.t = 0; this.dead = false; this.isPlayer = false;
};
BQ.Ally.prototype.hurt = function (dmg) { this.hp -= dmg; this.game.particles.burst(this.x, this.y, 6, '#fff', 1.4, 14, 2); if (this.hp <= 0) { this.dead = true; this.game.audio.sfx('poof'); this.game.particles.smoke(this.x, this.y, 8); } return true; };
BQ.Ally.prototype.update = function () {
  var g = this.game, p = g.player, lv = g.level, dx = p.x - this.x;
  this.t++; this.cd--;
  var followX = p.x - 16 * (p.face || 1);
  this.face = dx > 4 ? 1 : dx < -4 ? -1 : this.face;
  this.vx += BQ.clamp(followX - this.x, -1, 1) * 0.06;
  this.vx *= 0.9;
  this.vy += BQ.Player.GRAV; if (this.vy > 5) this.vy = 5;
  var onG = BQ.Collision.onGround(lv, this);
  if (onG && Math.abs(followX - this.x) > 20) this.vy = -4.2;
  BQ.Collision.moveX(lv, this, this.vx);
  var r = BQ.Collision.moveY(lv, this, this.vy); if (r === 1) this.vy = 0; else if (r === -1) this.vy = 0.5;
  // ataque a inimigos próximos
  if (this.cd <= 0) {
    for (var i = 0; i < lv.enemies.length; i++) {
      var e = lv.enemies[i]; if (e.state === 'DEAD') continue;
      if (Math.abs(e.x - this.x) < 20 && Math.abs(e.y - this.y) < 12) { e.hurt(1, this.x, { knock: 1 }); this.cd = 40; g.particles.burst(e.x, e.y, 4, '#ffd23f', 1.2, 12, 2); break; }
    }
  }
  if (this.y > lv.pxH + 40) this.dead = true;
};
BQ.Ally.prototype.sprite = function () {
  var i = Math.floor(this.t / 8) % 4, icon = this.def.icon;
  return icon;
};

/* ───────────── Inimigos ───────────── */
BQ.Enemy = function (game, kind, x, y) {
  var d = BQD.ENEMIES[kind];
  this.game = game; this.kind = kind; this.def = d; this.x = x; this.y = y; this.w = d.w; this.h = d.h;
  this.vx = -d.speed; this.vy = 0; this.hp = d.hp; this.maxHp = d.hp; this.state = 'PATROL'; this.face = -1;
  this.t = 0; this.hurtT = 0; this.knockT = 0; this.shootCd = BQ.rint(40, 120); this.windup = 0; this.frozeT = 0;
  this.baseY = y; this.flyPhase = Math.random() * 6.28; this.isPlayer = false;
};
BQ.Enemy.prototype.hurt = function (dmg, srcX, opts) {
  if (this.state === 'DEAD') return false;
  this.hp -= dmg; this.hurtT = 10;
  var kn = (opts && opts.knock) || 1;
  this.vx = (this.x < srcX ? -1 : 1) * kn; this.vy = -1.6; this.knockT = 10;
  if (opts && opts.status && opts.status.freeze) this.frozeT = Math.max(this.frozeT, opts.status.freeze * 0.5);
  this.game.particles.burst(this.x + this.w / 2, this.y + this.h / 2, 5, '#fff', 1.4, 12, 2);
  if (this.hp <= 0) this.kill(false);
  else this.game.audio.sfx('hit');
  return true;
};
BQ.Enemy.prototype.kill = function (stomped) {
  if (this.state === 'DEAD') return; this.state = 'DEAD'; this.vy = -3; this.vx = 0;
  var g = this.game; g.audio.sfx(stomped ? 'stomp' : 'hit');
  g.particles.burst(this.x + this.w / 2, this.y + this.h / 2, 10, '#ffd23f', 2.4, 20, 2);
  if (g.player) g.player.registerKill(this, stomped);
  if (Math.random() < this.def.drop) g.level.dropItem(this.x, this.y, BQ.pick(['fire', 'ice', 'glass', 'potion', 'sound', 'energy']));
};
BQ.Enemy.prototype.update = function () {
  if (this.state === 'DEAD') { this.vy += 0.3; this.y += this.vy; this.t++; if (this.y > this.game.level.pxH + 60) this.dead = true; return; }
  var g = this.game, lv = g.level, p = g.player, dx = p ? p.x - this.x : 999;
  this.t++; if (this.hurtT > 0) this.hurtT--;
  var frozen = this.frozeT > 0; if (frozen) this.frozeT--;
  if (this.knockT > 0) { this.knockT--; this.vy += BQ.Player.GRAV; }
  else if (this.def.ai === 'flyer') {
    this.flyPhase += 0.05; var targetY = this.baseY + Math.sin(this.flyPhase) * 10;
    if (Math.abs(dx) < this.def.sight && p) { this.vx = (dx > 0 ? 1 : -1) * this.def.chase * (frozen ? 0.2 : 1); this.face = this.vx > 0 ? 1 : -1; targetY = p.y - 10; }
    else this.vx = Math.sin(this.t / 40) * this.def.speed;
    this.y += (targetY - this.y) * 0.04; this.x += this.vx * (frozen ? 0.2 : 1);
    if (this.x < 4) this.x = 4; if (this.x + this.w > lv.pxW - 4) this.x = lv.pxW - 4 - this.w;
  } else if (this.def.ai === 'erratic') {
    this.flipCd = (this.flipCd === undefined ? BQ.rint(30, 70) : this.flipCd) - 1;
    if (this.flipCd <= 0) { this.face *= Math.random() < 0.7 ? -1 : 1; this.flipCd = BQ.rint(30, 70); }
    this.vx = this.face * this.def.speed * (frozen ? 0.2 : 1);
    var hitWallE = BQ.Collision.moveX(lv, this, this.vx);
    if (hitWallE) { this.face *= -1; this.flipCd = BQ.rint(30, 70); }
    else {
      var aheadE = { x: this.x + (this.vx >= 0 ? this.w + 1 : -2), y: this.y, w: 2, h: this.h };
      if (!BQ.Collision.onGround(lv, aheadE) && this.onGround !== false) { this.face *= -1; this.flipCd = BQ.rint(30, 70); }
    }
    this.vy += BQ.Player.GRAV; if (this.vy > 5) this.vy = 5;
    var rE = BQ.Collision.moveY(lv, this, this.vy); if (rE === 1) { this.vy = 0; this.onGround = true; } else if (rE === -1) this.vy = 0.5; else this.onGround = false;
  } else {
    var chase = p && Math.abs(dx) < this.def.sight && Math.abs(p.y - this.y) < 40;
    var spd = chase ? this.def.chase : this.def.speed;
    this.vx = (chase ? (dx > 0 ? 1 : -1) : this.face) * spd * (frozen ? 0.15 : 1);
    if (this.def.shoot && chase && this.shootCd <= 0 && Math.abs(dx) < this.def.shoot.range) { this.windup = this.def.shoot.windup; this.shootCd = this.def.shoot.cd; this.vx = 0; }
    if (this.windup > 0) { this.windup--; this.vx = 0; if (this.windup === 0) this.fireProjectile(dx); }
    if (this.shootCd > 0) this.shootCd--;
    var hitWall = BQ.Collision.moveX(lv, this, this.vx);
    if (hitWall) { this.face *= -1; }
    else {
      var ahead = { x: this.x + (this.vx >= 0 ? this.w + 1 : -2), y: this.y, w: 2, h: this.h };
      if (!BQ.Collision.onGround(lv, ahead) && this.onGround !== false) { this.face *= -1; }
    }
    this.face = this.vx > 0 ? 1 : this.vx < 0 ? -1 : this.face;
    this.vy += BQ.Player.GRAV; if (this.vy > 5) this.vy = 5;
    var r = BQ.Collision.moveY(lv, this, this.vy); if (r === 1) { this.vy = 0; this.onGround = true; } else if (r === -1) this.vy = 0.5; else this.onGround = false;
  }
  if (this.y > lv.pxH + 60) this.dead = true;
  // colisão com o jogador
  if (p && p.inv <= 0 && !p.dead && BQ.hit(this, p)) {
    var stomp = this.def.stomp && p.vy > 0.6 && p.y + p.h - p.vy <= this.y + 4;
    if (stomp) { this.kill(true); p.stomp(this); }
    else p.hurt(1, this.x);
  }
};
BQ.Enemy.prototype.fireProjectile = function (dx) {
  var g = this.game, type = this.def.shoot.type || 'shard', dir = dx > 0 ? 1 : -1;
  if (type === 'potion') {
    g.audio.sfx('cast');
    g.powers.shoot({ x: this.x + this.w / 2, y: this.y + 4, vx: dir * 2.1, vy: -3.3, gravity: 0.14, r: 4, life: 130, dmg: 1, team: 'e', kind: 'lob',
      land: { zone: 'poison', w: 40, h: 16, life: 150, tick: 26, dmg: 1, status: { poison: 120 } }, def: { id: 'enemy_potion', color: '#9be24a', color2: '#4c8a1a' }, color: '#9be24a' });
  } else {
    g.audio.sfx('shard');
    g.powers.shoot({ x: this.x + this.w / 2, y: this.y + 5, vx: dir * 1.6, vy: -0.4, gravity: 0.05, r: 3, life: 90, dmg: 1, team: 'e', kind: 'shard', color: '#bfe9ff' });
  }
};
BQ.Enemy.prototype.sprite = function () {
  var frames = BQ.Art.enemy[this.kind], i;
  if (this.state === 'DEAD') return frames[0];
  if (this.def.ai === 'flyer') { i = Math.floor(this.t / 8) % 2; return frames[i]; }
  i = Math.floor(this.t / 9) % 2; return frames[this.windup > 0 ? 2 % frames.length : i];
};

/* ───────────── Boss: Demolidor ───────────── */
BQ.Boss = function (game, id, x, y) {
  var d = BQD.BOSSES[id];
  this.game = game; this.id = id; this.def = d; this.x = x; this.y = y; this.w = d.w; this.h = d.h;
  this.hp = d.hp; this.maxHp = d.hp; this.state = 'intro'; this.t = 0; this.phase = 1; this.vx = 0; this.vy = 0;
  this.hurtT = 0; this.beat = 0; this.beatT = 90; this.iframes = 0; this.introT = 130; this.anger = false;
  this.dead = false; this.defeated = false; this.isPlayer = false; this.face = -1;
};
BQ.Boss.prototype.canBeHit = function () { return this.state !== 'intro' && this.state !== 'defeat' && this.state !== 'hidden' && this.iframes <= 0 && !this.defeated; };
BQ.Boss.prototype.hurt = function (dmg, srcX, opts) {
  if (!this.canBeHit()) return false;
  this.hp -= dmg; this.hurtT = 8; this.iframes = 8;
  var g = this.game; g.audio.sfx('hit3'); g.camera.shake(1.6, 8);
  g.particles.burst(this.x + this.w / 2, this.y + this.h / 2, 6, '#fff', 1.6, 16, 2);
  if (this.hp <= this.maxHp * 0.4 && !this.anger) { this.anger = true; }
  if (this.hp <= 0) { this.hp = 0; this.startDefeat(); }
  return true;
};
BQ.Boss.prototype.startDefeat = function () {
  this.state = 'defeat'; this.t = 0; this.game.onBossDefeated(this);
};
BQ.Boss.prototype.update = function () {
  var g = this.game, lv = g.level, p = g.player;
  this.t++; if (this.iframes > 0) this.iframes--; if (this.hurtT > 0) this.hurtT--;
  if (this.state === 'intro') { if (this.t > this.introT) { this.state = 'fight'; this.t = 0; g.audio.music('boss'); } return; }
  if (this.state === 'defeat') { this.vy = -1; this.y += this.vy * 0.2; return; }
  if (this.id === 'perfurador') this.updatePerfurador();
  else if (this.id === 'burner') this.updateBurner();
  else if (this.id === 'grausnegativos') this.updateGrausNegativos();
  else if (this.id === 'krumpie') this.updateKrumpie();
  else this.updateDemolidor();
  if (p && !p.dead && p.inv <= 0 && this.state !== 'hidden' && BQ.hit(this, p)) p.hurt(1, this.x);
};
BQ.Boss.prototype.updateDemolidor = function () {
  var g = this.game, lv = g.level;
  // IA simples do Demolidor: patrulha, ataque de bola de demolição, golpe no chão
  this.beat++;
  var speed = this.anger ? 0.75 : 0.5;
  this.vx = this.face * speed;
  var hit = BQ.Collision.moveX(lv, this, this.vx);
  if (hit || this.x < 20 || this.x + this.w > lv.pxW - 20) this.face *= -1;
  this.vy += BQ.Player.GRAV * 0.6; if (this.vy > 4) this.vy = 4;
  var r = BQ.Collision.moveY(lv, this, this.vy); if (r === 1) this.vy = 0;
  if (this.beat === this.beatT) {
    this.beat = 0; this.beatT = this.anger ? BQ.rint(70, 100) : BQ.rint(100, 140);
    var move = BQ.rint(0, this.anger ? 2 : 1);
    if (move === 0) this.attackBall();
    else if (move === 1) this.attackSlam();
    else this.attackTremor();
  }
};
BQ.Boss.prototype.attackBall = function () {
  var g = this.game, p = g.player, dir = p && p.x < this.x ? -1 : 1;
  g.audio.sfx('roar');
  g.powers.shoot({ x: this.x + this.w / 2, y: this.y + 6, vx: dir * 1.4, vy: -3, gravity: 0.1, r: 6, life: 160, dmg: 1, team: 'e', kind: 'bolt', color: '#5a5a66', bounce: true });
};
BQ.Boss.prototype.attackSlam = function () {
  var g = this.game; g.audio.sfx('quake'); g.camera.shake(4, 20);
  g.powers.nova(this.x + this.w / 2, this.y + this.h, 50, 1, 2.2, { stun: 30 }, 'e', { color: 'rgba(180,180,190,0.5)' });
};
BQ.Boss.prototype.attackTremor = function () {
  var g = this.game, p = g.player; g.audio.sfx('quake'); g.camera.shake(2.5, 30);
  if (p) g.powers.shoot({ x: this.x + this.w / 2, y: this.y + this.h - 4, vx: (p.x < this.x ? -1 : 1) * 1.1, vy: 0, gravity: 0, r: 4, life: 60, dmg: 1, team: 'e', kind: 'shard', color: '#8a8a94' });
};

/* ───────────── Perfurador: desaparece nas paredes e surge aleatoriamente ───────────── */
BQ.Boss.prototype.updatePerfurador = function () {
  var g = this.game, lv = g.level, p = g.player;
  if (this.pstate === undefined) { this.pstate = 'up'; this.pt = 60; this.arenaX0 = 3 * 16; this.arenaX1 = (lv.w - 4) * 16; this.holes = []; this.dashCd = 40; }
  this.pt--;
  if (this.pstate === 'up') {
    this.vy = 0; this.vx = 0;
    if (p && !p.dead && this.iframes <= 0 && BQ.hit(this, p)) p.hurt(1, this.x);
    if (this.pt <= 0) { this.pstate = 'down'; this.pt = 18; g.audio.sfx('quake'); }
  } else if (this.pstate === 'down') {
    this.y += 2.2; g.particles.burst(this.x + this.w / 2, this.y + this.h, 3, '#8a8a94', 1.4, 14, 2);
    if (this.pt <= 0) {
      this.pstate = 'hidden'; this.state = 'hidden'; this.pt = this.anger ? BQ.rint(28, 46) : BQ.rint(40, 65);
      this.y = -60;
      var nx = BQ.rand(this.arenaX0, this.arenaX1 - this.w);
      this.holes.push(nx + this.w / 2);
      this.nextX = nx;
    }
  } else if (this.pstate === 'hidden') {
    if (this.pt <= 0) {
      this.pstate = 'rise'; this.pt = 20; this.x = this.nextX; this.y = 60;
      g.camera.shake(2, 14); g.particles.burst(this.x + this.w / 2, lv.pxH - 20, 14, '#c94a2a', 2.4, 20, 3); g.audio.sfx('boom');
    }
  } else if (this.pstate === 'rise') {
    this.y -= 2.6;
    var floorY = lv.groundY(this.x + this.w / 2, 0) - this.h;
    if (this.y <= floorY) { this.y = floorY; this.pstate = 'up'; this.state = 'fight'; this.pt = this.anger ? BQ.rint(34, 50) : BQ.rint(55, 80); this.dashCd = 20; }
  }
  if (this.pstate === 'up' && this.dashCd !== undefined) {
    this.dashCd--;
    if (this.dashCd <= 0 && p) {
      this.dashCd = 999;
      var dir = p.x < this.x ? -1 : 1; this.face = dir;
      g.audio.sfx('roar');
      g.powers.shoot({ x: this.x + this.w / 2, y: this.y + this.h / 2, vx: dir * (this.anger ? 3.4 : 2.6), vy: 0, gravity: 0, r: 5, life: 40, dmg: 1, team: 'e', kind: 'shard', color: '#dcdfe3', pierce: true });
    }
  }
};

/* ───────────── Burner: feixes, fogo e fumo que reduz a visão ───────────── */
BQ.Boss.prototype.updateBurner = function () {
  var g = this.game, lv = g.level, p = g.player;
  if (this.bt === undefined) { this.bt = 70; this.by0 = this.y; }
  this.y = this.by0 + Math.sin(this.t / 30) * 8;
  this.vx = 0;
  if (p) this.face = p.x < this.x ? -1 : 1;
  this.bt--;
  if (this.bt <= 0) {
    this.bt = this.anger ? BQ.rint(50, 75) : BQ.rint(75, 105);
    var move = BQ.rint(0, this.anger ? 3 : 2);
    if (move === 0) this.attackBeam();
    else if (move === 1) this.attackFireNova();
    else if (move === 2) this.attackSmoke();
    else this.attackBeam();
  }
};
BQ.Boss.prototype.attackBeam = function () {
  var g = this.game, p = g.player, dir = p && p.x < this.x ? -1 : 1;
  g.audio.sfx('beam'); g.camera.shake(1.5, 10);
  g.powers.cast({ kind: 'beam', len: 260, h: 10, dur: this.anger ? 26 : 20, dmg: 1, angles: [0], color: '#ff6a2b', color2: '#ffe27a' }, this.x + this.w / 2, this.y + this.h / 2, dir, 'e');
};
BQ.Boss.prototype.attackFireNova = function () {
  var g = this.game; g.audio.sfx('boom'); g.camera.shake(3, 16);
  g.powers.nova(this.x + this.w / 2, this.y + this.h / 2, 60, 1, 2.4, { burn: 100 }, 'e', { color: 'rgba(255,120,40,0.6)' });
};
BQ.Boss.prototype.attackSmoke = function () {
  var g = this.game; g.audio.sfx('quake');
  g.fogT = Math.max(g.fogT || 0, 210);
  g.particles.smoke(this.x + this.w / 2, this.y, 18, 'rgba(60,50,55,0.6)');
};

/* ───────────── Graus Negativos: gelo a cair do céu e espigões no chão ───────────── */
BQ.Boss.prototype.updateGrausNegativos = function () {
  var g = this.game, lv = g.level;
  this.beat = (this.beat || 0) + 1;
  this.vx = this.face * (this.anger ? 0.6 : 0.42);
  var hit = BQ.Collision.moveX(lv, this, this.vx);
  if (hit || this.x < 24 || this.x + this.w > lv.pxW - 24) this.face *= -1;
  this.vy += BQ.Player.GRAV * 0.6; if (this.vy > 4) this.vy = 4;
  var r = BQ.Collision.moveY(lv, this, this.vy); if (r === 1) this.vy = 0;
  if (this.beat >= (this.beatT || 90)) {
    this.beat = 0; this.beatT = this.anger ? BQ.rint(55, 80) : BQ.rint(85, 120);
    var move = BQ.rint(0, this.anger ? 2 : 1);
    if (move === 0) this.attackIceRain(); else if (move === 1) this.attackIceSpikes(); else this.attackFreezeNova();
  }
};
BQ.Boss.prototype.attackIceRain = function () {
  var g = this.game, lv = g.level; g.audio.sfx('roar');
  for (var i = 0; i < 5; i++) {
    var x = BQ.rand(24, lv.pxW - 24);
    g.powers.shoot({ x: x, y: -10 - i * 14, vx: 0, vy: 2.6, gravity: 0.05, r: 4, life: 160, dmg: 1, team: 'e', kind: 'shard', color: '#bfe9ff', status: { freeze: 60 } });
  }
};
BQ.Boss.prototype.attackIceSpikes = function () {
  var g = this.game, p = g.player; if (!p) return;
  g.audio.sfx('break');
  g.powers.cast({ kind: 'spikes', count: 5, gap: 18, dmg: 1, delay: 5, h: 30, status: { freeze: 80 }, color: '#8fe8ff' }, p.x - 30, p.y, 1, 'e');
};
BQ.Boss.prototype.attackFreezeNova = function () {
  var g = this.game; g.audio.sfx('quake'); g.camera.shake(3, 16);
  g.powers.nova(this.x + this.w / 2, this.y + this.h / 2, 58, 1, 2.2, { freeze: 120 }, 'e', { color: 'rgba(150,220,255,0.6)' });
};

/* ───────────── Krumpie: 3 fases ───────────── */
BQ.Boss.prototype.updateKrumpie = function () {
  var g = this.game, lv = g.level, p = g.player;
  var ratio = this.hp / this.maxHp;
  var newPhase = ratio <= 0.32 ? 3 : ratio <= 0.66 ? 2 : 1;
  if (newPhase !== this.phase) { this.phase = newPhase; this.kbeat = 0; this.kbeatT = 40; if (newPhase === 2) this.destroyArena(); }
  if (this.kstate === 'hidden') {
    this.kt--; this.vx = 0;
    if (this.kt <= 0) { this.kstate = 'up'; this.x = this.knx; this.y = lv.groundY(this.x + this.w / 2, 0) - this.h; g.camera.shake(2, 12); g.particles.burst(this.x + this.w / 2, this.y + this.h, 12, '#7a2fd0', 2, 18, 3); }
    return;
  }
  this.kbeat = (this.kbeat || 0) + 1;
  var speed = 0.4 + this.phase * 0.14;
  this.vx = this.face * speed;
  var hit = BQ.Collision.moveX(lv, this, this.vx);
  if (hit || this.x < 24 || this.x + this.w > lv.pxW - 24) this.face *= -1;
  this.vy += BQ.Player.GRAV * 0.6; if (this.vy > 4) this.vy = 4;
  var r = BQ.Collision.moveY(lv, this, this.vy); if (r === 1) this.vy = 0;
  if (this.kbeat >= (this.kbeatT || 70)) {
    this.kbeat = 0; this.kbeatT = BQ.rint(55, 85) - this.phase * 6;
    this.krumpieAttack();
  }
};
BQ.Boss.prototype.krumpieAttack = function () {
  var g = this.game, p = g.player, lv = g.level;
  if (this.phase === 1) {
    var m = BQ.rint(0, 2);
    if (m === 0) { g.audio.sfx('roar'); g.powers.shoot({ x: this.x + this.w / 2, y: this.y + 4, vx: this.face * 1.6, vy: 0, gravity: 0, r: 5, life: 60, dmg: 1, team: 'e', kind: 'shard', color: '#8a8a94', pierce: true }); }
    else if (m === 1) { g.audio.sfx('quake'); g.camera.shake(3, 16); g.powers.nova(this.x + this.w / 2, this.y + this.h, 46, 1, 2, { stun: 30 }, 'e', { color: 'rgba(150,150,160,0.5)' }); }
    else if (p) { g.audio.sfx('roar'); this.face = p.x < this.x ? -1 : 1; this.vx = this.face * 2.6; }
  } else if (this.phase === 2) {
    var m2 = BQ.rint(0, 2);
    if (m2 === 0) this.attackFreezeNovaK();
    else if (m2 === 1) { var lv2 = lv; for (var i = 0; i < 4; i++) { var x = BQ.rand(24, lv2.pxW - 24); g.powers.shoot({ x: x, y: -10 - i * 14, vx: 0, vy: 2.4, gravity: 0.05, r: 4, life: 160, dmg: 1, team: 'e', kind: 'shard', color: '#bfe9ff', status: { freeze: 60 } }); } g.audio.sfx('roar'); }
    else this.destroyArena();
  } else {
    var m3 = BQ.rint(0, 3);
    if (m3 === 0) { g.audio.sfx('beam'); g.powers.cast({ kind: 'beam', len: 240, h: 10, dur: 22, dmg: 1, angles: [0], color: '#ff6a2b', color2: '#ffe27a' }, this.x + this.w / 2, this.y + this.h / 2, this.face, 'e'); }
    else if (m3 === 1) { g.audio.sfx('boom'); g.powers.nova(this.x + this.w / 2, this.y + this.h / 2, 55, 1, 2.4, { burn: 90 }, 'e', { color: 'rgba(255,120,40,0.6)' }); }
    else if (m3 === 2) this.attackFreezeNovaK();
    else this.teleport();
  }
};
BQ.Boss.prototype.attackFreezeNovaK = function () {
  var g = this.game; g.audio.sfx('quake'); g.camera.shake(3, 14);
  g.powers.nova(this.x + this.w / 2, this.y + this.h / 2, 52, 1, 2, { freeze: 100 }, 'e', { color: 'rgba(150,220,255,0.55)' });
};
BQ.Boss.prototype.teleport = function () {
  var g = this.game, lv = g.level;
  this.kstate = 'hidden'; this.kt = 34; this.vx = 0; this.vy = 0;
  this.knx = BQ.rand(3 * 16, (lv.w - 5) * 16 - this.w);
  g.particles.burst(this.x + this.w / 2, this.y + this.h / 2, 14, '#7a2fd0', 2.2, 20, 3); g.audio.sfx('poof');
  this.y = -80;
};
BQ.Boss.prototype.destroyArena = function () {
  var g = this.game, lv = g.level;
  if (this.arenaBroken) return; this.arenaBroken = true;
  g.audio.sfx('quake'); g.camera.shake(4, 22);
  var midx = Math.floor(lv.w / 2);
  for (var dx = -3; dx <= 3; dx++) { var tx = midx + dx; if (lv.tile(tx, 8) !== undefined) lv.setTile(tx, 8, BQD.TILE.AIR); }
};

BQ.Boss.prototype.sprite = function () {
  var i = this.hurtT > 0 ? 1 : 0;
  if (this.id === 'perfurador') { if (this.anger) i += 2; return BQ.Art.perfurador[i]; }
  if (this.id === 'burner') { if (this.anger) i += 2; return BQ.Art.burner[i]; }
  if (this.id === 'grausnegativos') { if (this.anger) i += 2; return BQ.Art.grausnegativos[i]; }
  if (this.id === 'krumpie') return null;
  if (this.anger) i += 2; return BQ.Art.demolidor[i];
};
'use strict';
/* BlockQuest — LevelSystem: mapa de tiles, blocos "?", moedas, checkpoints, trampolins, segredos */
BQ.Level = function (game, data) {
  this.game = game; this.data = data; this.id = data.id; this.name = data.name;
  this.w = data.w; this.pxW = data.w * 16; this.pxH = 17 * 16; this.tiles = data.tiles.slice();
  this.tileVar = new Uint8Array(this.w * 17);
  for (var i = 0; i < this.tileVar.length; i++) this.tileVar[i] = BQ.rint(0, 3);
  this.blocks = {}; for (var k in data.blocks) this.blocks[k] = { content: data.blocks[k], used: false, bump: 0 };
  this.coins = []; this.enemies = []; this.trampolines = []; this.cones = []; this.lamps = []; this.checkpoints = [];
  this.secrets = []; this.items = []; this.goal = null; this.spawn = { x: 32, y: 200 };
  this.lastCheckpoint = null; this.tone = data.tone; this.theme = data.theme; this.boss = null; this.bossDef = null;
  this.bg = BQ.Art.sceneBG(data.tone);
  this.startTime = 0; this.time = 0; this.enemiesKilled = 0; this.coinsCollected = 0; this.maxCombo = 0;
  this.breaking = []; this.hazards = []; this.lifts = []; this.crystals = [];

  data.ents.forEach(function (e) {
    if (e.t === 'coin') this.coins.push({ x: e.x * 16 + 4, y: e.y * 16 + 2, v: e.v, taken: false, t: BQ.rint(0, 20) });
    else if (e.t === 'en') this.enemies.push(new BQ.Enemy(game, e.k, e.x * 16 + 2, e.y * 16 + 1));
    else if (e.t === 'tramp') this.trampolines.push({ x: e.x * 16, y: e.y * 16, k: e.k, t: 0 });
    else if (e.t === 'cone') this.cones.push({ x: e.x * 16, y: e.y * 16, blink: Math.random() * 6 });
    else if (e.t === 'lamp') this.lamps.push({ x: e.x * 16, y: e.y * 16 });
    else if (e.t === 'check') this.checkpoints.push({ x: e.x * 16, y: e.y * 16, on: false });
    else if (e.t === 'orb') this.items.push({ x: e.x * 16 + 8, y: e.y * 16 + 8, kind: 'orb:' + e.p, floatT: Math.random() * 10, taken: false });
    else if (e.t === 'goal') this.goal = { x: e.x * 16, y: 0 };
    else if (e.t === 'spawn') this.spawn = { x: e.x * 16, y: e.y * 16 };
    else if (e.t === 'boss') { this.bossDef = e.k; this.bossX = e.x * 16; }
    else if (e.t === 'secret') this.secrets.push({ x: e.x * 16, y: e.y * 16, w: e.w * 16, h: e.h * 16, found: false });
    else if (e.t === 'lava') this.hazards.push({ x: e.x0 * 16, y: e.y * 16, w: (e.x1 - e.x0 + 1) * 16, h: 16, t: Math.random() * 10 });
    else if (e.t === 'lift') {
      var isV = e.axis !== 'h';
      var lift = { axis: e.axis, w: e.w * 16, speed: e.speed, dir: 1 };
      if (isV) { lift.x = e.x * 16; lift.y0 = e.a0 * 16; lift.y1 = e.a1 * 16; lift.y = lift.y0; lift.h = 6; }
      else { lift.y = e.x * 16; lift.x0 = e.a0 * 16; lift.x1 = e.a1 * 16; lift.x = lift.x0; lift.h = 6; }
      this.lifts.push(lift);
    }
    else if (e.t === 'crystal') this.crystals.push({ x: e.x * 16 + 8, y: e.y * 16 + 8, t: Math.random() * 10 });
  }, this);
  Object.keys(data.blocks).forEach(function (key) {
    var v = data.blocks[key];
    if (typeof v === 'string' && v.indexOf('orb:') === 0) { /* já tratado via q() -> blocks */ }
  });
  this.coinsTotal = data.coinsTotal;
};

BQ.Level.prototype.tile = function (x, y) { if (x < 0 || x >= this.w || y < 0 || y >= 17) return BQD.TILE.STEEL; return this.tiles[y * this.w + x]; };
BQ.Level.prototype.setTile = function (x, y, v) { if (x >= 0 && x < this.w && y >= 0 && y < 17) this.tiles[y * this.w + x] = v; };
BQ.Level.prototype.groundY = function (x, yHint) {
  var tx = Math.floor(x / 16), ty = Math.max(0, Math.floor(yHint / 16));
  for (var y = ty; y < 17; y++) { if (BQ.Collision.solid(this.tile(tx, y))) return y * 16; }
  return this.pxH;
};

BQ.Level.prototype.hitBlock = function (tx, ty, actor) {
  var key = tx + ',' + ty, b = this.blocks[key], id = this.tile(tx, ty), g = this.game, T = BQD.TILE;
  if (id === T.HIDDEN) {
    if (b && !b.used) { b.used = true; b.bump = 6; this.setTile(tx, ty, T.USED); this.spawnBlockContent(b.content, tx, ty); this.foundSecretBlock(tx, ty); g.audio.sfx('item'); }
    return;
  }
  if (id !== T.QBLOCK && id !== T.BRICK) return;
  if (id === T.BRICK) {
    if (b && b.content) { if (!b.used) { b.used = true; b.bump = 6; this.setTile(tx, ty, T.USED); this.spawnBlockContent(b.content, tx, ty); g.audio.sfx('item'); } return; }
    if (actor.ch && actor.diving) { this.setTile(tx, ty, T.AIR); g.audio.sfx('break'); g.particles.burst(tx * 16 + 8, ty * 16 + 8, 8, '#c2573a', 2, 18, 3); }
    else { b = b || (this.blocks[key] = { bump: 0 }); b.bump = 6; g.audio.sfx('block'); }
    return;
  }
  if (!b) return;
  if (b.used) { b.bump = 4; g.audio.sfx('block'); return; }
  b.used = true; b.bump = 8; this.setTile(tx, ty, T.USED);
  this.spawnBlockContent(b.content, tx, ty); g.audio.sfx('item');
};
BQ.Level.prototype.breakTile = function (tx, ty) {
  if (this.tile(tx, ty) !== BQD.TILE.CRACKED) return;
  this.setTile(tx, ty, BQD.TILE.AIR); this.game.audio.sfx('break');
  this.game.particles.burst(tx * 16 + 8, ty * 16 + 8, 10, '#8d929c', 2.2, 20, 3);
  this.foundSecretBlock(tx, ty);
};
BQ.Level.prototype.foundSecretBlock = function (tx, ty) {
  var px = tx * 16 + 8, py = ty * 16 + 8;
  for (var i = 0; i < this.secrets.length; i++) {
    var s = this.secrets[i]; if (s.found) continue;
    if (px >= s.x - 8 && px <= s.x + s.w + 8 && py >= s.y - 8 && py <= s.y + s.h + 8) {
      s.found = true; this.game.checkAchievement('secret', true); this.game.particles.text(px, py - 10, 'Sala secreta!', '#9ff3ff', 9);
    }
  }
};
BQ.Level.prototype.spawnBlockContent = function (content, tx, ty) {
  var x = tx * 16 + 8, y = ty * 16;
  if (content === 'coin') { this.game.addCoins(1, x, y); return; }
  if (content === 'gold') { this.game.addCoins(5, x, y); return; }
  if (content === '1up') { this.game.player.lives++; this.game.particles.text(x, y - 6, '1UP', '#7dff7d', 10); this.game.audio.sfx('star'); return; }
  if (content === 'heart') { this.items.push({ x: x, y: y - 4, kind: 'item:heart', vy: -1.6, floatT: 0, taken: false, pop: true }); return; }
  if (content && content.indexOf('orb:') === 0) { this.items.push({ x: x, y: y - 4, kind: content, vy: -1.6, floatT: 0, taken: false, pop: true }); return; }
  this.items.push({ x: x, y: y - 4, kind: 'item:' + content, vy: -1.6, floatT: 0, taken: false, pop: true });
};
BQ.Level.prototype.dropItem = function (x, y, powerId) { this.items.push({ x: x, y: y, kind: 'orb:' + powerId, vy: -1.4, floatT: 0, taken: false, pop: true }); };

BQ.Level.prototype.tryPickup = function (p) {
  for (var i = 0; i < this.items.length; i++) {
    var it = this.items[i]; if (it.taken) continue;
    if (Math.abs(it.x - (p.x + p.w / 2)) < 12 && Math.abs(it.y - (p.y + p.h / 2)) < 14) {
      it.taken = true; this.applyItem(p, it.kind); return true;
    }
  }
  return false;
};
BQ.Level.prototype.applyItem = function (p, kind) {
  var g = this.game;
  if (kind.indexOf('orb:') === 0) { p.pickPower(kind.slice(4), false); return; }
  if (kind === 'item:heart') { p.hp = Math.min(p.maxHp, p.hp + 1); g.audio.sfx('item'); g.particles.text(p.x + p.w / 2, p.y - 6, '+❤️', '#ff8a9a', 9); return; }
  if (kind === 'item:helmet') { p.invHelmet = 260; g.audio.sfx('helmet'); g.particles.text(p.x + p.w / 2, p.y - 6, 'INVENCÍVEL', '#ffe27a', 8); p.inv = Math.max(p.inv, 260); return; }
  if (kind === 'item:boot') { p.superBoot = 600; g.audio.sfx('item'); g.particles.text(p.x + p.w / 2, p.y - 6, 'SUPER BOTA', '#8effa0', 8); return; }
  if (kind === 'item:bubble') { p.bubbleLaser = 700; g.audio.sfx('item'); g.particles.text(p.x + p.w / 2, p.y - 6, 'LASER', '#9be2ff', 8); return; }
  if (kind === 'item:turbine') { p.turbo = 400; g.audio.sfx('item'); g.particles.text(p.x + p.w / 2, p.y - 6, 'TURBO', '#ffb35a', 8); return; }
};

BQ.Level.prototype.magnetCoins = function (p, r) {
  for (var i = 0; i < this.coins.length; i++) {
    var c = this.coins[i]; if (c.taken) continue;
    var dx = (p.x + p.w / 2) - c.x, dy = (p.y + p.h / 2) - c.y, d2 = dx * dx + dy * dy;
    if (d2 < r * r) { c.x -= dx * 0.18; c.y -= dy * 0.18; }
  }
};

BQ.Level.prototype.collideEntities = function (p) {
  var g = this;
  var i, c;
  for (i = 0; i < this.coins.length; i++) {
    c = this.coins[i]; if (c.taken) continue;
    if (Math.abs(c.x - (p.x + p.w / 2)) < 9 && Math.abs(c.y - (p.y + p.h / 2)) < 10) { c.taken = true; this.game.addCoins(c.v, c.x, c.y); }
  }
  for (i = 0; i < this.items.length; i++) { c = this.items[i]; if (!c.taken && c.floatT !== undefined && c.pop) {} }
  this.tryPickup(p);
  // trampolins
  for (i = 0; i < this.trampolines.length; i++) {
    var tr = this.trampolines[i], box = { x: tr.x, y: tr.y + 10, w: 16, h: 6 };
    if (p.vy > 0 && BQ.hit(p, box)) { p.vy = -8.4; p.y = tr.y - p.h + 6; tr.t = 10; this.game.audio.sfx('spring'); this.game.particles.burst(tr.x + 8, tr.y + 10, 8, '#ffd23f', 2, 16, 2); }
  }
  // checkpoints
  for (i = 0; i < this.checkpoints.length; i++) {
    var ck = this.checkpoints[i];
    if (!ck.on && Math.abs(ck.x - p.x) < 10) { ck.on = true; this.lastCheckpoint = ck; this.game.audio.sfx('check'); this.game.particles.text(ck.x, ck.y - 8, 'Checkpoint!', '#8effa0', 8); }
  }
  // objetivo
  if (this.goal && !p.won && !p.dead && p.x + p.w > this.goal.x) { p.won = true; p.finishT = 40; this.game.onLevelComplete(); }
  // boss trigger
  if (this.bossDef && !this.boss && p.x > this.bossX - 90) this.spawnBoss();
};
BQ.Level.prototype.spawnBoss = function () {
  this.boss = new BQ.Boss(this.game, this.bossDef, this.bossX, 40); this.game.onBossIntro(this.boss);
};

BQ.Level.prototype.update = function () {
  this.time++;
  var i;
  for (i = 0; i < this.coins.length; i++) { var c = this.coins[i]; c.t++; }
  for (i = 0; i < this.items.length; i++) {
    var it = this.items[i]; if (it.taken) continue;
    if (it.pop) { it.vy += 0.05; it.y += it.vy; if (it.vy >= 0) it.pop = false; }
    it.floatT += 0.08;
  }
  for (i = 0; i < this.trampolines.length; i++) if (this.trampolines[i].t > 0) this.trampolines[i].t--;
  for (var k in this.blocks) { var b = this.blocks[k]; if (b.bump > 0) b.bump--; }
  for (i = 0; i < this.cones.length; i++) this.cones[i].blink += 0.05;
  for (i = 0; i < this.hazards.length; i++) this.hazards[i].t += 0.12;
  for (i = 0; i < this.crystals.length; i++) this.crystals[i].t += 0.06;
  for (i = 0; i < this.lifts.length; i++) {
    var lf = this.lifts[i];
    if (lf.axis === 'h') {
      lf.x += lf.speed * lf.dir;
      if (lf.x <= lf.x0) { lf.x = lf.x0; lf.dir = 1; } else if (lf.x >= lf.x1) { lf.x = lf.x1; lf.dir = -1; }
      lf.dx = lf.speed * lf.dir; lf.dy = 0;
    } else {
      lf.y += lf.speed * lf.dir;
      if (lf.y <= lf.y0) { lf.y = lf.y0; lf.dir = 1; } else if (lf.y >= lf.y1) { lf.y = lf.y1; lf.dir = -1; }
      lf.dx = 0; lf.dy = lf.speed * lf.dir;
    }
  }
  var g = this.game;
  this.enemies = this.enemies.filter(function (e) { e.update(); return !e.dead; });
  if (this.boss) this.boss.update();
  if (g.player) { this.rideLifts(g.player); this.collideEntities(g.player); this.hazardCheck(g.player); }
};

BQ.Level.prototype.rideLifts = function (p) {
  for (var i = 0; i < this.lifts.length; i++) {
    var lf = this.lifts[i];
    var onTop = p.x + p.w > lf.x + 2 && p.x < lf.x + lf.w - 2 && p.y + p.h >= lf.y - 2 && p.y + p.h <= lf.y + 7 && p.vy >= 0;
    if (onTop) { p.y = lf.y - p.h; p.vy = 0; p.onGround = true; p.x += lf.dx; p.y += lf.dy; p.jumps = 0; }
  }
};
BQ.Level.prototype.hazardCheck = function (p) {
  if (p.inv > 0 || p.dead) return;
  for (var i = 0; i < this.hazards.length; i++) {
    var h = this.hazards[i];
    if (p.x + p.w > h.x && p.x < h.x + h.w && p.y + p.h > h.y && p.y < h.y + h.h + 40) {
      p.hurt(1, h.x + h.w / 2); p.vy = -4.6; p.vx = (p.x + p.w / 2 < h.x + h.w / 2 ? -1 : 1) * 1.8;
      this.game.particles.burst(p.x + p.w / 2, h.y, 10, '#ff6a2b', 2.4, 20, 3); this.game.audio.sfx('hurt');
      break;
    }
  }
};

/* ───────────── Desenho ───────────── */
BQ.Level.prototype.drawTiles = function (ctx, camX, y0, y1) {
  var t0 = Math.max(0, Math.floor(camX / 16) - 1), t1 = Math.min(this.w - 1, Math.floor((camX + BQ.W) / 16) + 1);
  var T = BQD.TILE;
  for (var ty = y0; ty <= y1; ty++) {
    for (var tx = t0; tx <= t1; tx++) {
      var id = this.tile(tx, ty); if (id === T.AIR || id === T.FAKE) continue;
      var key = tx + ',' + ty, b = this.blocks[key], bump = b ? b.bump : 0;
      var sx = Math.round(tx * 16 - camX), sy = ty * 16 - (bump > 0 ? Math.min(4, bump) : 0);
      var img = BQ.Art.tiles[id] && BQ.Art.tiles[id][this.tileVar[ty * this.w + tx]];
      if (!img) continue;
      ctx.drawImage(img, sx, sy);
    }
  }
};
BQ.Level.prototype.drawProps = function (ctx, camX) {
  var i;
  for (i = 0; i < this.cones.length; i++) {
    var co = this.cones[i], x = Math.round(co.x - camX), y = co.y;
    if (x < -20 || x > 500) continue;
    ctx.fillStyle = '#e8722a'; ctx.beginPath(); ctx.moveTo(x + 8, y + 2); ctx.lineTo(x + 15, y + 15); ctx.lineTo(x + 1, y + 15); ctx.fill();
    ctx.fillStyle = '#f2f2f2'; ctx.fillRect(x + 3, y + 8, 10, 2);
    if (Math.sin(co.blink) > 0.5) { ctx.fillStyle = '#fff8c0'; ctx.beginPath(); ctx.arc(x + 8, y + 4, 1.6, 0, 6.283); ctx.fill(); }
  }
  for (i = 0; i < this.lamps.length; i++) {
    var lp = this.lamps[i], lx = Math.round(lp.x - camX), ly = lp.y;
    if (lx < -20 || lx > 500) continue;
    ctx.fillStyle = '#3a3a44'; ctx.fillRect(lx + 7, ly - 8, 2, 24); ctx.fillStyle = '#20232b'; ctx.beginPath(); ctx.arc(lx + 8, ly - 10, 4, Math.PI, 0); ctx.fill();
    ctx.globalAlpha = 0.85; ctx.drawImage(BQ.Art.light('rgba(255,220,140,0.9)'), lx - 16, ly - 34, 48, 48); ctx.globalAlpha = 1;
    ctx.fillStyle = '#ffe9a8'; ctx.fillRect(lx + 6, ly - 12, 4, 3);
  }
  for (i = 0; i < this.trampolines.length; i++) {
    var tr = this.trampolines[i], tx = Math.round(tr.x - camX), squish = tr.t > 0 ? tr.t / 3 : 0;
    if (tx < -20 || tx > 500) continue;
    if (tr.k === 'spring') { ctx.fillStyle = '#8a8a96'; for (var s = 0; s < 4; s++) ctx.fillRect(tx + 2, tr.y + 10 - s * 2 + squish, 12, 1); ctx.fillStyle = '#e0e0e6'; ctx.fillRect(tx, tr.y + 12, 16, 4 - squish * 0.3); }
    else if (tr.k === 'bag') { ctx.fillStyle = '#a8946a'; ctx.fillRect(tx + 1, tr.y + 8 + squish, 14, 8 - squish); ctx.fillStyle = '#8a7452'; ctx.fillRect(tx + 1, tr.y + 8 + squish, 14, 2); }
    else { ctx.fillStyle = '#1a1a1e'; ctx.beginPath(); ctx.ellipse(tx + 8, tr.y + 13 + squish * 0.5, 8, 5 - squish * 0.3, 0, 0, 6.283); ctx.fill(); ctx.fillStyle = '#333338'; ctx.beginPath(); ctx.ellipse(tx + 8, tr.y + 13 + squish * 0.5, 4, 2.4, 0, 0, 6.283); ctx.fill(); }
  }
  // segredos: leve brilho quando encontrados (debug visual discreto)
};
BQ.Level.prototype.drawHazardsAndLifts = function (ctx, camX, t) {
  var i;
  for (i = 0; i < this.hazards.length; i++) {
    var h = this.hazards[i], x = Math.round(h.x - camX); if (x < -20 || x > 500) continue;
    var g = ctx.createLinearGradient(0, h.y, 0, h.y + h.h);
    g.addColorStop(0, '#ffd23f'); g.addColorStop(0.4, '#ff6a1f'); g.addColorStop(1, '#7a1a0a');
    ctx.fillStyle = g; ctx.fillRect(x, h.y, h.w, h.h);
    ctx.fillStyle = 'rgba(255,220,120,0.8)';
    for (var k = 0; k < h.w; k += 6) { var wobble = Math.sin(t / 12 + h.t + k) * 2; ctx.fillRect(x + k, h.y + 2 + wobble, 3, 2); }
    if ((this.game.frame + i * 7) % 14 === 0) this.game.particles.spawn(h.x + Math.random() * h.w, h.y + 2, BQ.rand(-0.2, 0.2), BQ.rand(-0.9, -0.4), 26, BQ.rint(2, 4), BQ.pick(['#ff8a2b', '#ffd23f']), -0.01, 2);
  }
  for (i = 0; i < this.lifts.length; i++) {
    var lf = this.lifts[i], lx = Math.round(lf.x - camX); if (lx < -30 || lx > 510) continue;
    ctx.fillStyle = '#4a5261'; ctx.fillRect(lx, lf.y, lf.w, 5); ctx.fillStyle = '#8b96a8'; ctx.fillRect(lx, lf.y, lf.w, 1);
    ctx.fillStyle = '#2b2f38'; for (var c = 0; c < lf.w; c += 6) ctx.fillRect(lx + c, lf.y + 1, 2, 3);
    ctx.fillStyle = '#171a20'; ctx.fillRect(lx, lf.y + 5, lf.w, 1);
  }
  for (i = 0; i < this.crystals.length; i++) {
    var cr = this.crystals[i], cx = Math.round(cr.x - camX); if (cx < -10 || cx > 490) continue;
    var glow = 0.5 + Math.sin(cr.t) * 0.3, cy = Math.round(cr.y);
    ctx.save(); ctx.globalAlpha = glow * 0.6; ctx.drawImage(BQ.Art.light('rgba(140,220,255,1)'), cx - 14, cy - 14, 28, 28); ctx.globalAlpha = 1;
    ctx.fillStyle = '#8fe8ff'; ctx.beginPath(); ctx.moveTo(cx, cy - 8); ctx.lineTo(cx + 5, cy - 1); ctx.lineTo(cx, cy + 8); ctx.lineTo(cx - 5, cy - 1); ctx.fill();
    ctx.fillStyle = '#e8fbff'; ctx.beginPath(); ctx.moveTo(cx, cy - 6); ctx.lineTo(cx + 2, cy - 1); ctx.lineTo(cx, cy + 3); ctx.fill();
    ctx.restore();
  }
};
BQ.Level.prototype.drawItemsAndCoins = function (ctx, camX, t) {
  var i;
  for (i = 0; i < this.coins.length; i++) {
    var c = this.coins[i]; if (c.taken) continue;
    var x = Math.round(c.x - camX); if (x < -10 || x > 490) continue;
    var frames = BQ.Art.coin[c.v >= 20 ? '20' : c.v >= 5 ? '5' : '1'], f = frames[Math.floor((t + c.t) / 6) % frames.length];
    ctx.drawImage(f, x - 7, Math.round(c.y - 7 + Math.sin((t + c.t * 8) / 14) * 1.5));
  }
  for (i = 0; i < this.items.length; i++) {
    var it = this.items[i]; if (it.taken) continue;
    var ix = Math.round(it.x - camX); if (ix < -10 || ix > 490) continue;
    var iy = Math.round(it.y + (it.pop ? 0 : Math.sin(it.floatT) * 2));
    if (it.kind.indexOf('orb:') === 0) {
      var def = BQD.POWERS[it.kind.slice(4)], icon = BQ.Art.getPowerIcon(def);
      ctx.save(); ctx.imageSmoothingEnabled = false; ctx.globalAlpha = 0.35; ctx.drawImage(BQ.Art.light('rgba(255,255,255,1)'), ix - 16, iy - 16, 32, 32); ctx.globalAlpha = 1;
      ctx.drawImage(icon, ix - 8, iy - 8); ctx.restore();
    } else {
      var key = it.kind.slice(5), img = BQ.Art.icon[key];
      if (img) ctx.drawImage(img, ix - 8, iy - 8);
    }
  }
};
BQ.Level.prototype.drawGoal = function (ctx, camX) {
  if (!this.goal) return;
  var x = Math.round(this.goal.x - camX); if (x < -30 || x > 520) return;
  ctx.fillStyle = '#8a8a96'; ctx.fillRect(x, 20, 3, this.pxH - 20);
  var t = this.game.frame;
  ctx.fillStyle = '#5fe0a0'; ctx.beginPath(); ctx.moveTo(x + 3, 24); ctx.lineTo(x + 20 + Math.sin(t / 10) * 2, 30); ctx.lineTo(x + 3, 36); ctx.fill();
};
BQ.Level.prototype.drawSecretHints = function () {};
'use strict';
/* BlockQuest — UI: ecrãs HTML (menus) + HUD e cutscenes em canvas */
BQ.UI = {};
(function (U) {
  var $ = function (id) { return document.getElementById(id); };
  var el = function (tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };

  U.bindDom = function (g) {
    var d = U.dom = {
      root: $('app'), stage: $('stage'), controls: $('controls'), install: $('installBanner'), installBtn: $('installBtn'), installClose: $('installClose'),
      rotate: $('rotateWarn'), toast: $('toast'),
      screens: {
        menu: $('screen-menu'), map: $('screen-map'), chars: $('screen-chars'), powers: $('screen-powers'),
        combos: $('screen-combos'), ach: $('screen-ach'), options: $('screen-options'), pause: $('screen-pause'),
        gameover: $('screen-gameover'), levelclear: $('screen-levelclear'), storycard: $('screen-storycard'),
        modes: $('screen-modes'), levelpick: $('screen-levelpick'), survivalresult: $('screen-survivalresult')
      },
      coinsMenu: $('coinsMenu'), charList: $('charList'), powerGrid: $('powerGrid'), fusionGrid: $('fusionGrid'),
      achList: $('achList'), mapWorlds: $('mapWorlds'), mapNodes: $('mapNodes'), mapTitle: $('mapTitle'),
      goSel: $('customBtnLayer')
    };
    g.canvas.width = BQ.W; g.canvas.height = BQ.H;
    g.input.bindTouch(d.controls);
    U.wireButtons(g);
    U.wireOptions(g);
    window.addEventListener('pointerdown', function once() { g.audio.unlock(); }, { once: true });
    window.addEventListener('keydown', function once() { g.audio.unlock(); }, { once: true });
    U.checkOrientation(); window.addEventListener('resize', U.checkOrientation); window.addEventListener('orientationchange', U.checkOrientation);
    U.setupInstall(g);
  };

  U.checkOrientation = function () {
    var portrait = window.innerHeight > window.innerWidth;
    U.dom.rotate.classList.toggle('show', portrait && window.innerWidth < 900);
  };

  U.setupInstall = function (g) {
    var deferred = null, d = U.dom;
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; if (!localStorage.getItem('bq_install_dismissed')) d.install.classList.add('show'); });
    d.installBtn.addEventListener('click', function () { d.install.classList.remove('show'); if (deferred) { deferred.prompt(); } });
    d.installClose.addEventListener('click', function () { d.install.classList.remove('show'); localStorage.setItem('bq_install_dismissed', '1'); });
    window.addEventListener('appinstalled', function () { d.install.classList.remove('show'); });
  };

  function show(name) { for (var k in U.dom.screens) U.dom.screens[k].classList.toggle('show', k === name); }
  function hideAll() { for (var k in U.dom.screens) U.dom.screens[k].classList.remove('show'); }

  U.click = function (id, fn) { var e = $(id); if (e) e.addEventListener('click', fn); };

  U.wireButtons = function (g) {
    U.click('m-play', function () { g.audio.sfx('select'); U.openMap(g); });
    U.click('m-map', function () { g.audio.sfx('select'); U.openMap(g); });
    U.click('m-chars', function () { g.audio.sfx('select'); U.openChars(g); });
    U.click('m-shop', function () { g.audio.sfx('select'); U.openChars(g); });
    U.click('m-powers', function () { g.audio.sfx('select'); U.openPowers(g); });
    U.click('m-combos', function () { g.audio.sfx('select'); show('combos'); });
    U.click('m-ach', function () { g.audio.sfx('select'); U.openAch(g); });
    U.click('m-modes', function () { g.audio.sfx('select'); U.openModes(g); });
    U.click('m-options', function () { g.audio.sfx('select'); show('options'); });
    document.querySelectorAll('[data-back]').forEach(function (b) { b.addEventListener('click', function () { g.audio.sfx('back'); show('menu'); }); });

    U.click('pause-resume', function () { g.audio.sfx('select'); g.audio.resumeMusic(); g.setState('play'); });
    U.click('pause-restart', function () { g.audio.sfx('select'); g.retryLevel(); });
    U.click('pause-map', function () { g.audio.sfx('back'); g.audio.stopMusic(); U.openMap(g); });
    U.click('pause-options', function () { g.audio.sfx('select'); show('options'); U.dom._returnToPause = true; });
    U.click('go-retry', function () { g.audio.sfx('select'); g.retryLevel(); });
    U.click('go-map', function () { g.audio.sfx('back'); U.openMap(g); });
    U.click('lc-next', function () { g.audio.sfx('select'); var n = g.levelResult && g.levelResult.next; if (n) g.startLevel(n); else U.openMap(g); });
    U.click('lc-map', function () { g.audio.sfx('back'); U.openMap(g); });
    U.click('sc-skip', function () { U.skipStory(g); });
    U.click('options-back', function () { g.audio.sfx('back'); if (U.dom._returnToPause) { U.dom._returnToPause = false; show('pause'); } else show('menu'); });
    U.click('m-newgame', function () {
      if (confirm('Começar um Novo Jogo? O progresso atual será substituído.')) { g.save.newGame(); g.audio.sfx('select'); U.openMap(g); }
    });
    U.click('mode-coinrush', function () { g.audio.sfx('select'); U.openLevelPick(g, 'coinrush'); });
    U.click('mode-timeattack', function () { g.audio.sfx('select'); U.openLevelPick(g, 'timeattack'); });
    U.click('mode-bossrush', function () {
      if (!g.save.data.bosses.krumpie) { g.audio.sfx('nofuse'); return; }
      g.audio.sfx('select'); g.startBossRush();
    });
    U.click('mode-survival', function () {
      if (!g.save.data.bosses.krumpie) { g.audio.sfx('nofuse'); return; }
      g.audio.sfx('select'); g.startSurvival();
    });
    U.click('mode-newgameplus', function () {
      if (!g.save.data.bosses.krumpie) { g.audio.sfx('nofuse'); return; }
      if (confirm('Começar um New Game+? A campanha recomeça, mas mantens moedas, personagens e fusões.')) { g.audio.sfx('select'); g.newGamePlus(); }
    });
    U.click('levelpick-back', function () { g.audio.sfx('back'); show('modes'); });
    U.click('sv-retry', function () { g.audio.sfx('select'); g.startSurvival(); });
    U.click('sv-menu', function () { g.audio.sfx('back'); g.mode = 'story'; g.setState('menu'); });
  };

  U.wireOptions = function (g) {
    var s = g.save.data.settings;
    var bind = function (id, key, isRange) {
      var e = $(id); if (!e) return;
      if (isRange) { e.value = s[key]; e.addEventListener('input', function () { s[key] = parseFloat(e.value); g.audio.applySettings(); g.save.commit(); }); }
      else { e.checked = !!s[key]; e.addEventListener('change', function () { s[key] = e.checked; g.audio.applySettings(); g.save.commit(); g.audio.sfx('click'); }); }
    };
    bind('opt-music', 'music'); bind('opt-sfx', 'sfx'); bind('opt-vibration', 'vibration'); bind('opt-shake', 'shake'); bind('opt-contrast', 'contrast');
    bind('opt-volume', 'volume', true);
    $('opt-contrast').addEventListener('change', function () { document.body.classList.toggle('contrast', $('opt-contrast').checked); });
    if (s.contrast) document.body.classList.add('contrast');
    var q = $('opt-quality'); q.value = s.quality; q.addEventListener('change', function () { s.quality = q.value; g.save.commit(); });
    var scale = $('opt-btnscale'); scale.value = s.btnScale; scale.addEventListener('input', function () { s.btnScale = parseFloat(scale.value); U.applyBtnScale(g); g.save.commit(); });
    U.applyBtnScale(g);
  };
  U.applyBtnScale = function (g) { document.documentElement.style.setProperty('--btn-scale', g.save.data.settings.btnScale); };

  /* ───────────── ecrãs dinâmicos ───────────── */
  U.openMap = function (g) {
    g.mode = 'story';
    var save = g.save.data;
    var wrap = U.dom.mapWorlds; wrap.innerHTML = '';
    BQD.WORLDS.forEach(function (w) {
      var unlocked = save.worlds >= w.id;
      var b = el('button', 'world-tab' + (unlocked ? '' : ' locked') + (U._curWorld === w.id ? ' active' : ''), w.icon + '<span>' + w.short + '</span>' + (unlocked ? '' : '🔒'));
      b.disabled = !unlocked;
      b.addEventListener('click', function () { g.audio.sfx('click'); U.renderWorldMap(g, w); });
      wrap.appendChild(b);
    });
    var cur = null; for (var i = 0; i < BQD.WORLDS.length; i++) if (save.worlds >= BQD.WORLDS[i].id) cur = BQD.WORLDS[i];
    U.renderWorldMap(g, cur || BQD.WORLDS[0]);
    U.refreshCoins(g); show('map');
  };
  U.renderWorldMap = function (g, w) {
    U._curWorld = w.id; var save = g.save.data;
    U.dom.mapTitle.textContent = 'Mundo ' + w.id + ' — ' + w.name;
    var box = U.dom.mapNodes; box.innerHTML = '';
    if (w.soon) { box.appendChild(el('div', 'soon-note', '🔒 Este reino chega numa próxima versão do BlockQuest.\nContinua a jornada no Mundo 1 para desbloquear a história!')); return; }
    var prevDone = true;
    w.nodes.forEach(function (n, idx) {
      var done = !!save.done[n.id], locked = !prevDone;
      var stars = save.stars[n.id] || 0;
      var b = el('div', 'node' + (n.boss ? ' boss' : '') + (locked ? ' locked' : '') + (done ? ' done' : ''));
      b.style.left = n.x + '%'; b.style.top = n.y + '%';
      b.innerHTML = (n.boss ? '💀' : (idx + 1)) + (locked ? '<i>🔒</i>' : '');
      if (!locked) {
        b.addEventListener('click', function () { g.audio.sfx('select'); g.startLevel(n.id); });
        if (done && !n.boss) { var st = el('div', 'stars'); st.textContent = '⭐'.repeat(stars) + '☆'.repeat(3 - stars); b.appendChild(st); }
      }
      box.appendChild(b);
      prevDone = done || (n.boss && save.bosses[n.id.split('-')[0] === '1' ? 'demolidor' : '']);
      prevDone = done;
    });
  };

  U.openChars = function (g) {
    var save = g.save.data, box = U.dom.charList; box.innerHTML = '';
    BQD.CHARACTERS.forEach(function (ch) {
      var owned = save.owned.indexOf(ch.id) >= 0, selected = save.char === ch.id;
      var card = el('div', 'char-card' + (selected ? ' selected' : '') + (owned ? '' : ' locked'));
      var cv = document.createElement('canvas'); cv.width = 16; cv.height = 16; cv.className = 'char-sprite';
      cv.getContext('2d').drawImage(BQ.Art.chars[ch.id].idle0, 0, 0);
      card.appendChild(cv);
      card.appendChild(el('div', 'char-name', ch.name));
      card.appendChild(el('div', 'char-ability', ch.ability));
      card.appendChild(el('div', 'char-desc', ch.desc));
      var btn = el('button', 'char-buy', owned ? (selected ? 'SELECIONADO' : 'SELECIONAR') : ('🪙 ' + ch.price + ' — COMPRAR'));
      if (owned) btn.classList.add('owned'); if (selected) btn.classList.add('is-selected');
      btn.addEventListener('click', function () {
        if (owned) { save.char = ch.id; g.save.commit(); g.audio.sfx('select'); U.openChars(g); }
        else if (save.coins >= ch.price) { save.coins -= ch.price; save.owned.push(ch.id); save.char = ch.id; g.save.commit(); g.audio.sfx('buy'); U.openChars(g); U.refreshCoins(g); }
        else g.audio.sfx('nofuse');
      });
      card.appendChild(btn);
      box.appendChild(card);
    });
    U.refreshCoins(g); show('chars');
  };

  U.openPowers = function (g) {
    var save = g.save.data, pg = U.dom.powerGrid, fg = U.dom.fusionGrid; pg.innerHTML = ''; fg.innerHTML = '';
    Object.keys(BQD.POWERS).forEach(function (k) {
      var p = BQD.POWERS[k], c = el('div', 'power-card');
      var cv = document.createElement('canvas'); cv.width = 16; cv.height = 16; cv.getContext('2d').drawImage(BQ.Art.getPowerIcon(p), 0, 0);
      c.appendChild(cv); c.appendChild(el('div', 'power-name', p.icon + ' ' + p.name)); c.appendChild(el('div', 'power-desc', p.desc));
      pg.appendChild(c);
    });
    Object.keys(BQD.FUSIONS).forEach(function (k) {
      var f = BQD.FUSIONS[k], known = f.known || save.fusions[f.id];
      var c = el('div', 'power-card fusion' + (known ? '' : ' unknown'));
      if (known) {
        var cv = document.createElement('canvas'); cv.width = 16; cv.height = 16; cv.getContext('2d').drawImage(BQ.Art.getPowerIcon(f), 0, 0);
        c.appendChild(cv); c.appendChild(el('div', 'power-name', f.icon + ' ' + f.name)); c.appendChild(el('div', 'power-desc', f.desc));
      } else { c.appendChild(el('div', 'power-name', '❓ ???')); c.appendChild(el('div', 'power-desc', 'Descobre esta fusão combinando dois poderes.')); }
      fg.appendChild(c);
    });
    show('powers');
  };

  U.openAch = function (g) {
    var save = g.save.data, box = U.dom.achList; box.innerHTML = '';
    BQD.ACHIEVEMENTS.forEach(function (a) {
      var got = !!save.ach[a.id], c = el('div', 'ach-row' + (got ? ' got' : ''));
      c.appendChild(el('div', 'ach-icon', got ? a.icon : '🔒')); var t = el('div', 'ach-text'); t.appendChild(el('div', 'ach-name', a.name)); t.appendChild(el('div', 'ach-desc', a.desc)); c.appendChild(t);
      box.appendChild(c);
    });
    show('ach');
  };

  U.refreshCoins = function (g) { U.dom.coinsMenu.textContent = '🪙 ' + String(g.save.data.coins).padStart(4, '0'); };

  U.openModes = function (g) {
    var unlocked = !!g.save.data.bosses.krumpie;
    document.querySelectorAll('#screen-modes .locked-mode').forEach(function (el) { el.classList.toggle('locked-mode', !unlocked); });
    show('modes');
  };

  U.openLevelPick = function (g, purpose) {
    U._pickPurpose = purpose;
    var save = g.save.data, list = U.dom.screens.levelpick.querySelector('#levelpickList'); list.innerHTML = '';
    document.getElementById('levelpick-title').textContent = purpose === 'coinrush' ? 'Coin Rush — Escolher Fase' : 'Time Attack — Escolher Fase';
    var any = false;
    BQD.WORLDS.forEach(function (w) {
      if (w.soon) return;
      w.levels.forEach(function (id) {
        if (id.indexOf('-B') >= 0) return; // sem fases de boss
        if (!save.done[id]) return;
        any = true;
        var key = (purpose === 'coinrush' ? 'cr_' : 'ta_') + id, best = save.records[key];
        var row = document.createElement('div'); row.className = 'pick-row';
        var label = BQD.LEVELS[id] ? BQD.LEVELS[id].name : id;
        var recTxt = best === undefined ? 'sem recorde' : (purpose === 'coinrush' ? ('🪙 ' + best) : BQ.fmtTime(best));
        row.innerHTML = '<div><div class="pn">' + w.short + ' — ' + label + '</div><div class="pr">' + recTxt + '</div></div>';
        var btn = document.createElement('button'); btn.className = 'btn small'; btn.textContent = 'JOGAR';
        btn.addEventListener('click', function () {
          g.audio.sfx('select');
          if (purpose === 'coinrush') g.startCoinRush(id); else g.startTimeAttack(id);
        });
        row.appendChild(btn); list.appendChild(row);
      });
    });
    if (!any) list.innerHTML = '<div class="soon-note">Ainda não concluíste nenhuma fase. Joga a campanha no Mapa primeiro!</div>';
    show('levelpick');
  };

  U.fillSurvivalResult = function (g) {
    var r = g.survivalResult; if (!r) return;
    document.getElementById('sv-time').textContent = BQ.fmtTime(r.time);
    document.getElementById('sv-best').textContent = BQ.fmtTime(r.best);
    document.getElementById('sv-coins').textContent = r.coins;
  };

  /* ───────────── mudança de estado do jogo ───────────── */
  U.onState = function (g, s, arg) {
    var d = U.dom;
    if (s === 'play' || s === 'boss_intro' || s === 'deathwait') { hideAll(); d.controls.classList.add('show'); document.body.classList.add('in-game'); return; }
    d.controls.classList.remove('show'); document.body.classList.remove('in-game');
    if (s === 'menu') { show('menu'); U.refreshCoins(g); g.audio.music('menu'); g.player = null; g.level = null; }
    else if (s === 'pause') { show('pause'); }
    else if (s === 'gameover') { show('gameover'); $('go-coins').textContent = '🪙 ' + (g.player ? g.player.coins : 0); }
    else if (s === 'levelclear') { U.fillLevelClear(g); show('levelclear'); }
    else if (s === 'survivalresult') { U.fillSurvivalResult(g); show('survivalresult'); }
    else if (s === 'introcut') { hideAll(); U.startStory(g, BQD.STORY.intro, true); }
    else if (s === 'story') { hideAll(); U.startStory(g, BQD.STORY[arg.key], false); }
  };

  U.fillLevelClear = function (g) {
    var r = g.levelResult; if (!r) return;
    $('lc-title').textContent = r.isBest ? '🏆 NOVO RECORDE!' : 'FASE CONCLUÍDA!';
    $('lc-time').textContent = BQ.fmtTime(r.time);
    $('lc-coins').textContent = r.coins;
    $('lc-kills').textContent = r.kills;
    $('lc-combo').textContent = 'x' + r.combo;
    $('lc-stars').textContent = '⭐'.repeat(r.stars) + '☆'.repeat(3 - r.stars);
    $('lc-next').style.display = r.next ? '' : 'none';
    U.refreshCoins(g);
  };
})(BQ.UI);
'use strict';
/* BlockQuest — UI parte 2: cutscenes em canvas, HUD, banners */
(function (U) {
  U.startStory = function (g, script, isIntro) {
    g.story = script; g.storyIdx = 0; g.storyT = 0; g.storyIsIntro = isIntro; g._lastLine = null;
    g.audio.music('menu');
    U.showStoryCard();
  };
  U.showStoryCard = function () { document.getElementById('screen-storycard').classList.add('show'); };
  U.hideStoryCard = function () { document.getElementById('screen-storycard').classList.remove('show'); };
  U.skipStory = function (g) {
    if (!g.story) return;
    var scene = g.story[g.storyIdx];
    if (scene && scene.final) { U.finishStory(g); return; }
    g.storyIdx++; g.storyT = 0;
    if (g.storyIdx >= g.story.length) { U.finishStory(g); }
  };
  U.finishStory = function (g) {
    U.hideStoryCard();
    if (g.storyIsIntro) { g.save.data.seenIntro = true; g.save.commit(); g.setState('menu'); }
    else {
      var key = g._arg && g._arg.key;
      if (g._pendingLevel && key && key.indexOf('end') === -1) { var lvl = g._pendingLevel; g._pendingLevel = null; g.startLevel(lvl); }
      else { g.setState('menu'); }
    }
    g.story = null;
  };

  U.updateStory = function (g) {
    if (!g.story) return;
    var scene = g.story[g.storyIdx]; if (!scene) return;
    g.storyT++;
    var box = document.getElementById('sc-text');
    if (g._lastLine !== scene.text) { box.textContent = scene.text; g._lastLine = scene.text; }
    document.getElementById('sc-skip').textContent = scene.final ? (g.storyIsIntro ? 'COMEÇAR A AVENTURA' : 'CONTINUAR ▶') : 'SALTAR ▶';
    if (!scene.final && g.storyT > scene.dur) { g.storyIdx++; g.storyT = 0; if (g.storyIdx >= g.story.length) U.finishStory(g); }
  };

  U.update = function (g) {
    if (g.state === 'introcut' || g.state === 'story') U.updateStory(g);
    if (g.toastT > 0) {
      var t = document.getElementById('toast');
      if (g.toast !== t._msg) { t.textContent = g.toast; t._msg = g.toast; t.classList.add('show'); }
      if (g.toastT === 1) t.classList.remove('show');
    }
    if (g.state === 'play' && g.player && g.player.discFlashT > 40) {
      // "NOVA FUSÃO DESCOBERTA!" tratado no HUD draw
    }
  };

  U.draw = function (g, ctx) {
    if (g.state === 'introcut' || g.state === 'story') { U.drawStory(g, ctx); return; }
    if (g.state === 'boss_intro') U.drawBossBanner(g, ctx);
  };

  U.drawStory = function (g, ctx) {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, BQ.W, BQ.H);
    var scene = g.story[g.storyIdx]; if (!scene) return;
    var fn = BQ.Art.scenes[scene.scene]; if (fn) fn(ctx, g.storyT + g.storyIdx * 13);
    var fadeIn = Math.min(1, g.storyT / 18);
    if (scene.scene !== 'black') { ctx.globalAlpha = 1 - fadeIn; ctx.fillStyle = '#000'; ctx.fillRect(0, 0, BQ.W, BQ.H); ctx.globalAlpha = 1; }
    if (!scene.final && scene.dur < 99999) {
      var remain = scene.dur - g.storyT, fadeOut = remain < 18 ? 1 - remain / 18 : 0;
      if (fadeOut > 0) { ctx.globalAlpha = fadeOut; ctx.fillStyle = '#000'; ctx.fillRect(0, 0, BQ.W, BQ.H); ctx.globalAlpha = 1; }
    }
  };

  U.drawBossBannerInPlay = function (g, ctx) {
    var t = g.bossBannerT, total = 90, elapsed = total - t, a = elapsed < 12 ? elapsed / 12 : t < 12 ? t / 12 : 1;
    ctx.globalAlpha = a; ctx.fillStyle = 'rgba(10,6,14,0.72)'; ctx.fillRect(0, 108, BQ.W, 56);
    BQ.txt(ctx, 'BOSS', BQ.W / 2, 132, 16, '#ff5a5a', 'center');
    BQ.txt(ctx, g.bossBannerName || '', BQ.W / 2, 154, 20, '#fff', 'center');
    ctx.globalAlpha = 1;
  };
  U.drawBossBanner = function (g, ctx) {
    var p = g.stateT / 70, a = p < 0.15 ? p / 0.15 : p > 0.85 ? (1 - p) / 0.15 : 1;
    ctx.globalAlpha = a; ctx.fillStyle = 'rgba(10,6,14,0.72)'; ctx.fillRect(0, 108, BQ.W, 56);
    BQ.txt(ctx, 'BOSS', BQ.W / 2, 132, 16, '#ff5a5a', 'center');
    BQ.txt(ctx, g._arg ? g._arg.name : '', BQ.W / 2, 154, 20, '#fff', 'center');
    ctx.globalAlpha = 1;
  };

  /* ───────────── HUD ───────────── */
  U.drawHud = function (g, ctx) {
    if (g.state !== 'play' && g.state !== 'deathwait' && g.state !== 'boss_intro') return;
    var p = g.player, lv = g.level;
    // corações
    var i;
    for (i = 0; i < p.maxHp; i++) { var img = i < p.hp ? BQ.Art.icon.heartHud : BQ.Art.icon.heartEmpty; ctx.drawImage(img, 6 + i * 15, 6, 14, 14); }
    // moedas
    ctx.drawImage(BQ.Art.coin['1'][0], 6, 24, 14, 14);
    BQ.txt(ctx, String(p.coins).padStart(4, '0'), 24, 35, 11, '#ffe27a');
    // vidas
    BQ.txt(ctx, '×' + p.lives, 6, 58, 11, '#fff');
    // combo
    if (p.killChain >= 2) { ctx.save(); ctx.globalAlpha = Math.min(1, p.killChainT / 20); BQ.txt(ctx, 'COMBO x' + p.killChain, BQ.W / 2, 20, 12, '#ffe27a', 'center'); ctx.restore(); }
    // tempo
    BQ.txt(ctx, BQ.fmtTime(lv.time), BQ.W - 8, 16, 10, '#dfe6ee', 'right');
    // fragmentos (bússola simples: nenhum nesta versão de nível único)
    // inventário de poderes
    U.drawSlot(ctx, BQ.W - 60, BQ.H - 30, p.inventory.slots[0], true);
    U.drawSlot(ctx, BQ.W - 32, BQ.H - 30, p.inventory.slots[1], false);
    // boss hp
    if (lv.boss && lv.boss.state !== 'intro') {
      var bw = 200, bx = (BQ.W - bw) / 2, by = 15, r = Math.max(0, lv.boss.hp / lv.boss.maxHp);
      ctx.fillStyle = 'rgba(10,10,14,0.6)'; ctx.fillRect(bx - 2, by - 2, bw + 4, 12);
      ctx.fillStyle = '#3a1010'; ctx.fillRect(bx, by, bw, 8);
      ctx.fillStyle = r > 0.3 ? '#e0473f' : '#ff8a3f'; ctx.fillRect(bx, by, bw * r, 8);
      BQ.txt(ctx, lv.boss.def.name, BQ.W / 2, by - 4, 9, '#fff', 'center');
    }
    // efeitos de estado
    if (p.frozeT > 0) { ctx.save(); ctx.globalAlpha = 0.12; ctx.fillStyle = '#8fe8ff'; ctx.fillRect(0, 0, BQ.W, BQ.H); ctx.restore(); }
    if (g.fogT > 0) { ctx.save(); ctx.globalAlpha = Math.min(0.55, (g.fogT / 210) * 0.55); ctx.fillStyle = '#3a3238'; ctx.fillRect(0, 0, BQ.W, BQ.H); ctx.restore(); }
    if (p.dead) { ctx.save(); ctx.globalAlpha = Math.min(0.75, g.stateT / 40); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, BQ.W, BQ.H); ctx.globalAlpha = 1; if (g.stateT > 20) BQ.txt(ctx, 'AI...', BQ.W / 2, BQ.H / 2, 18, '#ff8a8a', 'center'); ctx.restore(); }
    if (p.discFlashT > 0) {
      var f = p.discoveredFusion, aa = Math.min(1, p.discFlashT / 20);
      ctx.save(); ctx.globalAlpha = Math.min(1, (130 - p.discFlashT) / 14) * (p.discFlashT < 20 ? p.discFlashT / 20 : 1);
      ctx.fillStyle = 'rgba(10,6,20,0.55)'; ctx.fillRect(60, 90, 360, 60);
      BQ.txt(ctx, 'NOVA FUSÃO DESCOBERTA!', BQ.W / 2, 112, 12, '#ffe27a', 'center');
      BQ.txt(ctx, f.icon + ' ' + f.name, BQ.W / 2, 134, 16, '#fff', 'center');
      ctx.restore();
    }
    if (g.player.won) { ctx.save(); BQ.txt(ctx, 'FASE CONCLUÍDA!', BQ.W / 2, BQ.H / 2, 20, '#8effa0', 'center'); ctx.restore(); }
  };
  U.drawSlot = function (ctx, x, y, slot, primary) {
    ctx.fillStyle = 'rgba(10,10,16,0.55)'; ctx.strokeStyle = primary ? '#ffe27a' : 'rgba(255,255,255,0.4)'; ctx.lineWidth = 1.5;
    ctx.fillRect(x, y, 24, 24); ctx.strokeRect(x + 0.5, y + 0.5, 23, 23);
    if (slot) {
      var img = BQ.Art.getPowerIcon(slot.def); ctx.drawImage(img, x + 4, y + 3, 16, 16);
      BQ.txt(ctx, String(slot.ammo), x + 20, y + 22, 8, '#fff');
    }
  };
})(BQ.UI);
'use strict';
/* BlockQuest — Game: máquina de estados principal, HUD e ligação entre sistemas */
BQ.Game = function (canvas) {
  this.canvas = canvas; this.ctx = canvas.getContext('2d'); this.ctx.imageSmoothingEnabled = false;
  this.save = new BQ.Save(); this.audio = new BQ.Audio(this.save); this.input = new BQ.Input();
  this.particles = new BQ.Particles(this); this.powers = new BQ.PowerSystem(this); this.camera = new BQ.Camera(this);
  this.frame = 0; this.state = 'boot'; this.stateT = 0; this.level = null; this.player = null; this.allies = []; this.fogT = 0; this.mode = 'story';
  this.pendingWorld = null; this.pendingLevel = null; this.flash = 0; this.toast = null; this.toastT = 0;
  this.pauseSel = 0; this.gameOverSel = 0; this.mapSel = 0; this.menuSel = 0;
  this.story = null; this.storyIdx = 0; this.storyT = 0; this.storySkip = 0;
  this.bossPending = null; this.levelResult = null;
  BQ.Art.init();
  BQ.UI.bindDom(this);
  this.setState(this.save.data.seenIntro ? 'menu' : 'introcut');
};

BQ.Game.prototype.setState = function (s, arg) {
  this.state = s; this.stateT = 0; this._arg = arg;
  BQ.UI.onState(this, s, arg);
};

BQ.Game.prototype.addCoins = function (n, x, y) {
  var mult = this.player ? this.player.coinMult : 1, total = n * (n <= 1 ? mult : mult);
  this.save.addCoins(Math.round(n * (this.player ? this.player.coinMult : 1)));
  if (this.player) this.player.coins += n;
  this.audio.sfx(n >= 20 ? 'coin20' : n >= 5 ? 'coin5' : 'coin');
  if (x !== undefined) this.particles.text(x, y - 6, '+' + n, '#ffe27a', 8);
  this.checkAchievement('rich', this.save.data.coins >= 1000);
  this.save.commit();
};

BQ.Game.prototype.checkAchievement = function (id, cond) {
  if (!cond || this.save.data.ach[id]) return;
  this.save.data.ach[id] = true; this.save.commit();
  var def = null; for (var i = 0; i < BQD.ACHIEVEMENTS.length; i++) if (BQD.ACHIEVEMENTS[i].id === id) def = BQD.ACHIEVEMENTS[i];
  if (def) this.showToast(def.icon + ' Conquista: ' + def.name);
};
BQ.Game.prototype.showToast = function (msg) { this.toast = msg; this.toastT = 200; this.audio.sfx('star'); };

/* ───────────── fluxo de níveis ───────────── */
BQ.Game.prototype.startLevel = function (id) {
  this.mode = 'story';
  var data = BQD.LEVELS[id]; if (!data) return;
  var w = null; for (var wi = 0; wi < BQD.WORLDS.length; wi++) if (BQD.WORLDS[wi].levels.indexOf(id) >= 0) w = BQD.WORLDS[wi];
  if (w && w.storyKey && w.levels[0] === id && !this.save.data.story[w.storyKey]) {
    this.save.data.story[w.storyKey] = true; this.save.commit();
    this._pendingLevel = id; this.setState('story', { key: w.storyKey }); return;
  }
  this.level = new BQ.Level(this, data);
  var ch = null; for (var i = 0; i < BQD.CHARACTERS.length; i++) if (BQD.CHARACTERS[i].id === this.save.data.char) ch = BQD.CHARACTERS[i];
  this.player = new BQ.Player(this, ch, this.level.spawn.x, this.level.spawn.y);
  this.allies = []; this.particles.clear(); this.powers.clear();
  this.camera.setLevel(this.level.pxW); this.camera.snap(this.player);
  this.levelResult = null;
  this.setState('play');
  this.audio.music(data.music);
};
BQ.Game.prototype.spawnAlly = function (def, x, y) { this.allies.push(new BQ.Ally(this, def, x, y)); };

BQ.Game.prototype.onLevelComplete = function () {
  var g = this, lv = this.level, p = this.player;
  if (this.mode === 'timeattack') {
    var key = 'ta_' + lv.id, best = this.save.data.records[key];
    var isBest = best === undefined || lv.time < best;
    if (isBest) { this.save.data.records[key] = lv.time; this.save.commit(); }
    setTimeout(function () { g.audio.jingle('win'); }, 30);
    this.levelResult = { time: lv.time, coins: p.coins, kills: this.countKills(), combo: p.killChain, stars: isBest ? 3 : 2, next: null, best: this.save.data.records[key], isBest: isBest };
    setTimeout(function () { g.setState('levelclear'); }, 900);
    return;
  }
  if (this.mode === 'coinrush') {
    var ckey = 'cr_' + lv.id, cbest = this.save.data.records[ckey];
    var isBestC = cbest === undefined || p.coins > cbest;
    if (isBestC) { this.save.data.records[ckey] = p.coins; this.save.commit(); }
    setTimeout(function () { g.audio.jingle('win'); }, 30);
    this.levelResult = { time: lv.time, coins: p.coins, kills: this.countKills(), combo: p.killChain, stars: isBestC ? 3 : 2, next: null, best: this.save.data.records[ckey], isBest: isBestC };
    setTimeout(function () { g.setState('levelclear'); }, 900);
    return;
  }
  this.save.data.done[lv.id] = true;
  var stars = 1; if (p.noDamage) stars++; if (lv.time < lv.par * 60 * 1.3) stars = Math.min(3, stars + 1);
  this.save.data.stars[lv.id] = Math.max(this.save.data.stars[lv.id] || 0, stars);
  this.save.commit();
  this.checkAchievement('first', true);
  this.checkAchievement('clean', p.noDamage);
  setTimeout(function () { g.audio.jingle('win'); }, 30);
  this.levelResult = { time: lv.time, coins: p.coins, kills: lv.enemiesKilled + this.countKills(), combo: p.killChain, stars: stars, next: this.nextLevelId(lv.id) };
  setTimeout(function () { g.setState('levelclear'); }, 900);
};
BQ.Game.prototype.countKills = function () { return this.player ? Math.round(this.player.score / 100) : 0; };
BQ.Game.prototype.nextLevelId = function (id) {
  var w = this.currentWorld(); if (!w) return null;
  var idx = w.levels.indexOf(id); if (idx < 0 || idx >= w.levels.length - 1) return null; return w.levels[idx + 1];
};
BQ.Game.prototype.currentWorld = function () {
  var id = this.level ? this.level.id : null; if (!id) return null;
  for (var i = 0; i < BQD.WORLDS.length; i++) if (BQD.WORLDS[i].levels.indexOf(id) >= 0) return BQD.WORLDS[i];
  return null;
};
BQ.Game.prototype.onBossIntro = function (boss) { this.audio.sfx('boss'); this.camera.shake(3, 30); this.bossBannerT = 90; this.bossBannerName = boss.def.name; };
BQ.Game.prototype.onBossDefeated = function (boss) {
  var g = this;
  if (this.mode === 'bossrush') {
    this.audio.stopMusic();
    setTimeout(function () { g.audio.jingle('frag'); }, 200);
    setTimeout(function () {
      g.bossRushIdx++;
      if (g.bossRushIdx < g.bossRushQueue.length) {
        var nextId = g.bossRushQueue[g.bossRushIdx];
        g._startModeLevel(nextId);
        g.player.hp = g.player.maxHp;
      } else {
        g.mode = 'story'; g.showToast('🏆 Boss Rush concluído!'); g.audio.jingle('win'); g.setState('menu');
      }
    }, 1600);
    return;
  }
  this.save.data.bosses[boss.id] = true;
  if (boss.def.fragment) { this.save.data.frags[boss.def.fragment] = true; var fd = BQD.FRAGMENTS[boss.def.fragment]; if (fd) BQ.Art.fragColor = fd.color; }
  this.save.commit(); this.checkAchievement('boss1', true);
  var isFinal = boss.id === 'krumpie';
  this.audio.stopMusic();
  setTimeout(function () { g.audio.jingle(isFinal ? 'win' : 'frag'); }, 300);
  setTimeout(function () {
    if (isFinal) {
      g.checkAchievement('saved', true);
      g.save.data.campaignDone = true; g.save.commit();
      g.setState('story', { key: 'ending' });
      return;
    }
    var w = null; for (var i = 0; i < BQD.WORLDS.length; i++) if (BQD.WORLDS[i].id === boss.def.world) w = BQD.WORLDS[i];
    var wi = w ? BQD.WORLDS.indexOf(w) : -1;
    if (wi >= 0 && BQD.WORLDS[wi + 1] && !BQD.WORLDS[wi + 1].soon) { g.save.data.worlds = Math.max(g.save.data.worlds, BQD.WORLDS[wi + 1].id); g.save.commit(); }
    if (w && w.endKey && BQD.STORY[w.endKey]) g.setState('story', { key: w.endKey }); else g.setState('menu');
  }, 2200);
};

/* ───────────── Modos de jogo extra ───────────── */
BQ.Game.prototype.startBossRush = function () {
  this.mode = 'bossrush';
  this.bossRushQueue = ['1-B', '2-B', '3-B', '4-B', '5-B'].slice();
  this.bossRushIdx = 0;
  this._startModeLevel(this.bossRushQueue[0]);
};
BQ.Game.prototype.startTimeAttack = function (id) { this.mode = 'timeattack'; this._startModeLevel(id); };
BQ.Game.prototype.startCoinRush = function (id) { this.mode = 'coinrush'; this._startModeLevel(id); };
BQ.Game.prototype.startSurvival = function () {
  this.mode = 'survival';
  var data = BQD.LEVELS['1-B']; this.level = new BQ.Level(this, data);
  this.level.boss = null; this.level.bossDef = null; this.level.goal = null;
  var ch = null; for (var i = 0; i < BQD.CHARACTERS.length; i++) if (BQD.CHARACTERS[i].id === this.save.data.char) ch = BQD.CHARACTERS[i];
  this.player = new BQ.Player(this, ch, this.level.spawn.x, this.level.spawn.y);
  this.allies = []; this.particles.clear(); this.powers.clear();
  this.camera.setLevel(this.level.pxW); this.camera.snap(this.player);
  this.survivalT = 0; this.survivalCd = 90;
  this.setState('play'); this.audio.music('boss');
};
BQ.Game.prototype._startModeLevel = function (id) {
  var data = BQD.LEVELS[id]; if (!data) return;
  this.level = new BQ.Level(this, data);
  var ch = null; for (var i = 0; i < BQD.CHARACTERS.length; i++) if (BQD.CHARACTERS[i].id === this.save.data.char) ch = BQD.CHARACTERS[i];
  this.player = new BQ.Player(this, ch, this.level.spawn.x, this.level.spawn.y);
  this.allies = []; this.particles.clear(); this.powers.clear();
  this.camera.setLevel(this.level.pxW); this.camera.snap(this.player);
  this.levelResult = null;
  this.setState('play'); this.audio.music(data.music);
};
BQ.Game.prototype.newGamePlus = function () {
  var d = this.save.data;
  d.done = {}; d.story = {}; d.bosses = {}; d.frags = {}; d.worlds = 1; d.campaignDone = false;
  d.newGamePlus = (d.newGamePlus || 0) + 1;
  this.save.commit();
  this.setState('menu');
};
BQ.Game.prototype.survivalSpawn = function () {
  var lv = this.level, kinds = ['zombie', 'zombie_glass', 'crow', 'fire_demon', 'witch', 'ice_beast', 'guard'];
  var k = BQ.pick(kinds), x = Math.random() < 0.5 ? 20 : lv.pxW - 30;
  lv.enemies.push(new BQ.Enemy(this, k, x, 190));
};

BQ.Game.prototype.gameOver = function () {
  var g = this;
  if (this.mode === 'survival') {
    var t = this.survivalT || 0, key = 'survival_best', best = this.save.data.records[key] || 0;
    var isBest = t > best; if (isBest) { this.save.data.records[key] = t; this.save.commit(); }
    this.survivalResult = { time: t, best: Math.max(t, best), coins: this.player ? this.player.coins : 0 };
    setTimeout(function () { g.audio.jingle('lose'); }, 20);
    this.setState('survivalresult');
    return;
  }
  setTimeout(function () { g.audio.jingle('lose'); }, 20);
  this.setState('gameover');
};
BQ.Game.prototype.retryLevel = function () { this.startLevel(this.level.id); };
BQ.Game.prototype.respawnAtCheckpoint = function () {
  var lv = this.level, p = this.player, ck = lv.lastCheckpoint;
  p.lives--; this.save.commit();
  if (p.lives < 0) { this.gameOver(); return; }
  if (ck) p.respawnAt(ck.x, ck.y - p.h); else p.respawnAt(lv.spawn.x, lv.spawn.y);
  p.dead = false; p.hp = p.maxHp; this.setState('play'); this.audio.music(lv.data.music); this.audio.resumeMusic();
};

/* ───────────── loop ───────────── */
BQ.Game.prototype.tick = function () {
  this.input.poll();
  this.frame++;
  if (this.toastT > 0) this.toastT--;
  var s = this.state;
  if (s === 'play') this.updatePlay();
  else if (s === 'boss_intro') { this.stateT++; if (this.stateT > 70) this.setState('play'); }
  else if (s === 'deathwait') { this.stateT++; if (this.player) { this.player.update(); } if (this.stateT > 90) this.respawnAtCheckpoint(); }
  this.particles.update();
  BQ.UI.update(this);
  this.input.clear();
  this.draw();
};

BQ.Game.prototype.updatePlay = function () {
  var lv = this.level, p = this.player;
  if (this.bossBannerT > 0) this.bossBannerT--;
  if (this.fogT > 0) this.fogT--;
  if (this.mode === 'survival' && !p.dead) {
    this.survivalT = (this.survivalT || 0) + 1;
    this.survivalCd--;
    if (this.survivalCd <= 0) { this.survivalSpawn(); this.survivalCd = Math.max(30, 90 - Math.floor(this.survivalT / 300)); }
  }
  if (this.input.pressed.pause && !p.dead) { this.audio.pauseMusic(); this.setState('pause'); return; }
  p.update();
  lv.update();
  for (var i = 0; i < this.allies.length; i++) this.allies[i].update();
  this.allies = this.allies.filter(function (a) { return !a.dead; });
  this.powers.update();
  this.camera.update(p);
  if (p.dead && this.stateT === 0) { this.setState('deathwait'); }
};

BQ.Game.prototype.draw = function () {
  var ctx = this.ctx; ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, BQ.W, BQ.H);
  var s = this.state;
  if (s === 'play' || s === 'boss_intro' || s === 'deathwait' || s === 'pause') this.drawGame();
  BQ.UI.draw(this, ctx);
  if (s === 'play' && this.bossBannerT > 0) BQ.UI.drawBossBannerInPlay(this, ctx);
};

BQ.Game.prototype.drawGame = function () {
  var ctx = this.ctx, lv = this.level, cam = this.camera, camX = Math.round(cam.x + cam.ox);
  ctx.save(); ctx.translate(0, cam.oy);
  BQ.Art.drawBG(ctx, lv.bg, camX, this.frame, this.save.data.settings.quality);
  lv.drawTiles(ctx, camX, 0, 16);
  lv.drawProps(ctx, camX);
  lv.drawHazardsAndLifts(ctx, camX, this.frame);
  this.powers.draw(ctx, camX);
  lv.drawItemsAndCoins(ctx, camX, this.frame);
  lv.drawGoal(ctx, camX);
  // inimigos
  for (var i = 0; i < lv.enemies.length; i++) {
    var e = lv.enemies[i], ex = Math.round(e.x - camX);
    if (ex < -20 || ex > 500) continue;
    var img = e.sprite(); var ey = Math.round(e.y - (img.height - e.h - 2));
    ctx.save(); if (e.frozeT > 0) ctx.filter = 'saturate(0.3) brightness(1.2)';
    if (e.face > 0) { ctx.translate(ex + img.width, ey); ctx.scale(-1, 1); ctx.drawImage(img, 0, 0); } else ctx.drawImage(img, ex, ey);
    ctx.restore();
  }
  // aliados
  for (i = 0; i < this.allies.length; i++) {
    var a = this.allies[i], ax = Math.round(a.x - camX);
    ctx.save(); ctx.font = '11px sans-serif'; ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(ax, a.y + a.h + 1, 6, 2, 0, 0, 6.283); ctx.fill();
    ctx.fillText(a.def.icon, ax, a.y + 8); ctx.restore();
  }
  // boss
  if (lv.boss) this.drawBoss(ctx, lv.boss, camX);
  // jogador
  this.drawPlayer(ctx, camX);
  Art_drawNear(ctx, lv.bg, camX);
  this.particles.draw(ctx, camX);
  ctx.restore();
  if (this.camera.shakeT > 0) {} // shake já aplicado via ox/oy
  BQ.UI.drawHud(this, ctx);
};
function Art_drawNear(ctx, bg, camX) { BQ.Art.drawNear(ctx, bg, camX); }

BQ.Game.prototype.drawPlayer = function (ctx, camX) {
  var p = this.player, x = Math.round(p.x - camX), img = p.currentSprite(), y = Math.round(p.y - (img.height - p.h - 1));
  if (p.finishT > 0) y -= 0;
  var blink = p.inv > 0 && (this.frame & 4) && !p.dead;
  var invis = p.invisT > 0;
  ctx.save();
  if (invis) ctx.globalAlpha = 0.32;
  if (!blink) {
    if (p.face < 0) { ctx.translate(x + img.width, y); ctx.scale(-1, 1); ctx.drawImage(img, 0, 0); }
    else ctx.drawImage(img, x, y);
  }
  ctx.restore();
  if (p.shield) { ctx.save(); ctx.globalAlpha = 0.5 + Math.sin(this.frame / 8) * 0.15; ctx.strokeStyle = '#7dd0ff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x + p.w / 2, y + img.height / 2, 11, 0, 6.283); ctx.stroke(); ctx.restore(); }
};
BQ.Game.prototype.drawBoss = function (ctx, boss, camX) {
  var x = Math.round(boss.x - camX);
  if (boss.id === 'krumpie') {
    var a = boss.state === 'intro' ? Math.min(1, boss.t / 40) : 1;
    ctx.globalAlpha = a;
    ctx.save(); ctx.globalAlpha = a * 0.55; ctx.drawImage(BQ.Art.light('rgba(150,90,220,1)'), x + boss.w / 2 - 46, Math.round(boss.y + boss.h) - 100, 92, 92); ctx.restore();
    BQ.Art.krumpie(ctx, x + boss.w / 2, Math.round(boss.y + boss.h), (boss.w / 26) * 1.15, this.frame, { arms: boss.phase >= 2 });
    ctx.globalAlpha = 1;
    return;
  }
  var img = boss.sprite(), y = Math.round(boss.y + boss.h - img.height);
  if (boss.state === 'intro') { var p = Math.min(1, boss.t / 40); ctx.globalAlpha = p; }
  ctx.save();
  if (boss.face > 0) { ctx.translate(x + img.width, y); ctx.scale(-1, 1); ctx.drawImage(img, 0, 0); } else ctx.drawImage(img, x, y);
  ctx.restore(); ctx.globalAlpha = 1;
};

/* ───────────── loop principal (requestAnimationFrame com passo fixo) ───────────── */
BQ.Game.prototype.start = function () {
  var self = this, acc = 0, last = performance.now(), STEP = 1000 / 60;
  function frame(now) {
    requestAnimationFrame(frame);
    var dt = now - last; last = now; if (dt > 250) dt = 250; acc += dt;
    var n = 0;
    while (acc >= STEP && n < 5) { self.tick(); acc -= STEP; n++; }
  }
  requestAnimationFrame(frame);
};
'use strict';
/* BlockQuest — arranque: abertura Go Games (espaço, estrela a cair, logotipo) e depois o jogo */
function BQ_boot() {
  if ('serviceWorker' in navigator) { window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); }); }

  var boot = document.getElementById('bootScreen'), starsCv = document.getElementById('bootStars'), logo = document.getElementById('bootLogo');
  var stage = document.getElementById('stage');
  var ctx = starsCv.getContext('2d'), w, h, stars = [], t = 0;

  function resize() { w = starsCv.width = window.innerWidth; h = starsCv.height = window.innerHeight; }
  resize(); window.addEventListener('resize', resize);
  for (var i = 0; i < 140; i++) stars.push({ x: Math.random() * 2000, y: Math.random() * 1200, r: Math.random() * 1.6 + 0.3, tw: Math.random() * 6.28 });

  function frame() {
    t++;
    ctx.fillStyle = '#03040a'; ctx.fillRect(0, 0, w, h);
    ctx.save();
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i], px = (s.x % w + w) % w, py = (s.y % h + h) % h, a = 0.4 + Math.sin(t / 20 + s.tw) * 0.4;
      ctx.globalAlpha = Math.max(0.1, a); ctx.fillStyle = '#dfe8ff'; ctx.beginPath(); ctx.arc(px, py, s.r, 0, 6.283); ctx.fill();
    }
    ctx.restore();
    // estrela cadente que "cai" e dá origem ao logo
    if (t < 70) {
      var p = Math.min(1, t / 60), x = w * 0.5 + (0.5 - p) * w * 0.5, y = h * 0.15 + p * h * 0.28;
      ctx.save(); ctx.globalAlpha = 1;
      var grad = ctx.createLinearGradient(x - 80, y - 40, x, y);
      grad.addColorStop(0, 'rgba(255,255,255,0)'); grad.addColorStop(1, 'rgba(255,255,255,0.9)');
      ctx.strokeStyle = grad; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x - 80, y - 40); ctx.lineTo(x, y); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, 3.2, 0, 6.283); ctx.fill();
      var glow = ctx.createRadialGradient(x, y, 0, x, y, 26); glow.addColorStop(0, 'rgba(200,220,255,0.7)'); glow.addColorStop(1, 'rgba(200,220,255,0)');
      ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(x, y, 26, 0, 6.283); ctx.fill();
      ctx.restore();
    }
    if (t === 66) { logo.classList.add('show'); flashOnce(); }
    if (t < 190) requestAnimationFrame(frame); else finish();
  }
  function flashOnce() {
    ctx.save(); ctx.globalAlpha = 0.55; ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); ctx.restore();
  }
  requestAnimationFrame(frame);

  function finish() {
    boot.classList.add('fade');
    setTimeout(function () {
      boot.remove(); stage.style.display = 'block';
      try {
        var canvas = document.getElementById('game');
        window.BQGame = new BQ.Game(canvas);
        window.BQGame.start();
      } catch (err) {
        var m = document.createElement('div');
        m.style.cssText = 'position:fixed;inset:0;z-index:999999;background:#03040a;color:#fff;display:flex;align-items:center;justify-content:center;padding:24px;text-align:center;font:600 15px system-ui;';
        m.textContent = 'Não foi possível iniciar o jogo. Tenta recarregar a página.';
        document.body.appendChild(m);
      }
    }, 420);
  }
  // permitir saltar a abertura com um toque
  boot.addEventListener('pointerdown', function () { if (t < 150) t = 150; });
}

if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', BQ_boot);
} else {
  BQ_boot();
}
