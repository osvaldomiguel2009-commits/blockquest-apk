# BlockQuest: Reino Esmeralda — versão 1 (Go Games)

Plataforma 2D em HTML5 Canvas + JavaScript puro, PWA instalável, sem bibliotecas externas.

## O que esta versão já tem
- Abertura Go Games (estrelas + estrela cadente + logótipo).
- Cutscene de introdução completa (texto do prompt original) e cutscene de abertura do Mundo 1.
- Menu principal, Mapa (Mundo 1 jogável; Mundos 2–5 aparecem como "🔒 em breve"), Personagens/Loja
  (6 personagens com preços e habilidades), Poderes & Fusões (6 elementos + 15 combinações), Combos/Como Jogar,
  Conquistas (10), Opções (música, efeitos, volume, vibração, screen shake, alto contraste, qualidade,
  tamanho dos botões).
- Mundo 1 — Zona Urbana completo: níveis 1‑1, 1‑2, 1‑3 e o boss **Demolidor**, com fragmento urbano.
- Sistemas: movimento + salto/duplo salto, combo de ataque G→G→G, ataque descendente, inventário de 2 poderes,
  fusão (C), invocar aliado, moedas com combo, checkpoints, vidas/game over, trampolins, cones, power‑ups
  (capacete, bota, bolha, turbina), blocos "?"/tijolo/escondidos, paredes falsas e uma sala secreta por nível,
  câmara suave, partículas, áudio 100% sintetizado (música e efeitos, sem ficheiros de som).
- PWA: manifest, ícone (gerado a preto/esmeralda com coroa), Service Worker com cache offline, aviso de instalação,
  aviso de "roda o dispositivo" em portrait, controlos táteis multi-toque + teclado + Gamepad API.

## O que falta (próximas versões, como combinámos)
- Versão 2: Mundo 2 (Minas) e Mundo 3 (Infernum Ground).
- Versão 3: Mundo 4 (Ice Cream Ground), Mundo 5 (Castelo Esmeralda + Krumpie em 3 fases),
  Boss Rush, Time Attack, Survival, Coin Rush, New Game+.

## Como testar
Os Service Workers só funcionam em `http(s)://`, nunca abrindo o `index.html` diretamente em `file://`.
Formas simples de testar:
- Publica a pasta num serviço estático (GitHub Pages, Netlify, Vercel, Firebase Hosting, etc.) e abre o link no telemóvel.
- Ou localmente: `cd BlockQuest && python3 -m http.server 8080` e abre `http://localhost:8080` (ou o IP do PC) no telemóvel, na mesma rede.
Depois de abrir uma vez com rede, o jogo fica instalável e funciona offline.

## Estrutura
```
BlockQuest/
  index.html, style.css, manifest.webmanifest, sw.js
  assets/ui/            (logótipo Go Games, ícones da app)
  data/                 (poderes, fusões, personagens, inimigos, boss, níveis, história)
  js/                   (motor: áudio, input, arte procedural, física, entidades, UI, jogo)
```
