# BlockQuest: Reino Esmeralda — versão 1 (Go Games)

Plataforma 2D em HTML5 Canvas + JavaScript puro, PWA instalável, sem bibliotecas externas.

## O que esta versão já tem
- Abertura Go Games (estrelas + estrela cadente + logótipo).
- Cutscene de introdução completa e cutscenes de abertura/fecho dos 5 Mundos, incluindo o final da campanha
  (fragmentos reunidos, Bloco Mestre reconstruído, Reino Esmeralda salvo, com todos os 6 personagens).
- Menu principal, Mapa (**os 5 Mundos jogáveis do início ao fim**), Personagens/Loja, Poderes & Fusões,
  Combos/Como Jogar, Conquistas (10), **Modos de Jogo** (Coin Rush, Time Attack, Boss Rush, Survival, New Game+),
  Opções.
- **Mundo 1 — Zona Urbana**: níveis 1‑1 a 1‑3 + boss **Demolidor** (fragmento urbano).
- **Mundo 2 — Minas Subterrâneas**: níveis 2‑1 a 2‑3 + boss **Perfurador** (fragmento mineral). Demónios de
  Fogo, cristais, lava, elevadores/plataformas móveis; o Perfurador desaparece na parede e ataca em investidas.
- **Mundo 3 — Infernum Ground**: níveis 3‑1 a 3‑3 + boss **Burner** (fragmento infernal). Bruxas com ataques à
  distância; o Burner usa feixes, explosões de fogo e nuvens de fumo que reduzem a visão.
- **Mundo 4 — Ice Cream Ground**: níveis 4‑1 a 4‑3 + boss **Graus Negativos** (fragmento glacial). Animais
  Mortos-vivos erráticos e rápidos, chão escorregadio, gelo a cair do céu, espigões de gelo.
- **Mundo 5 — Castelo Esmeralda**: níveis 5‑1 a 5‑3 + boss final **Krumpie em 3 fases** (vigas/investidas físicas
  → tempestades de gelo que destroem plataformas → fogo, teleporte e combinação de tudo).
- **Modos extra**: Coin Rush e Time Attack (disponíveis para qualquer fase concluída, com recordes guardados);
  Boss Rush, Survival e New Game+ desbloqueiam ao derrotar Krumpie.
- Sistemas: movimento + salto/duplo salto, combos, inventário de 2 poderes, fusão, invocar aliado, moedas com
  combo, checkpoints, vidas/game over, trampolins, power‑ups, blocos "?"/tijolo/escondidos, paredes falsas e
  salas secretas, lava e plataformas móveis, câmara suave, partículas, áudio 100% sintetizado com faixas
  próprias por mundo e por boss.
- PWA: manifest, ícone, Service Worker com cache offline (v3), aviso de instalação, aviso de "roda o
  dispositivo" em portrait, controlos táteis multi-toque + teclado + Gamepad API.

## Estado do projeto
A campanha e os sistemas descritos no prompt original estão todos implementados e testados de ponta a ponta
(incluindo os 3 bosses finais, o final da campanha e os 5 modos de jogo). Áreas que ficaram deliberadamente mais
simples, por serem secundárias ao objetivo principal (um jogo completo e jogável): a câmara em arenas de boss
mais largas segue o jogador em vez do boss; alguns detalhes visuais dos mundos partilham a mesma base de tiles
com paletas e cenários próprios em vez de texturas 100% exclusivas por mundo.

## Como testar
Os Service Workers só funcionam em `http(s)://`, nunca abrindo o `index.html` diretamente em `file://`.
Formas simples de testar:
- Publica a pasta num serviço estático (GitHub Pages, Netlify, Vercel, Firebase Hosting, etc.) e abre o link no telemóvel.
- Ou localmente: `cd BlockQuest && python3 -m http.server 8080` e abre `http://localhost:8080` (ou o IP do PC) no telemóvel, na mesma rede.
Depois de abrir uma vez com rede, o jogo fica instalável e funciona offline.

## Estrutura
```
BlockQuest/
  index.html, style.css, manifest.webmanifest, sw.js
  assets/ui/            (logótipo Go Games, ícones da app)
  data/                 (poderes, fusões, personagens, inimigos, boss, níveis, história)
  js/                   (motor: áudio, input, arte procedural, física, entidades, UI, jogo)
```
